# CatalogueIQ Evaluation Report

**Report ID:** CATALOGUEIQ-EVAL-001  
**Version:** 1.0  
**Evaluation date:** 11 September 2026  
**Project:** CatalogueIQ  
**Marketplace:** ShopSmart India, fictional  
**Test set:** `evaluation/test_set.json`  
**Baseline results:** `evaluation/baseline_results.json`  
**Improved results:** `evaluation/improved_results.json`

> **Important evaluation notice:** The baseline and improved metric values in this report are deterministic, illustrative synthetic results created for pipeline development. They are not the output of a completed live RAGAS run. Replace them with actual evaluation results before making final performance claims.

---

## 1. Executive Summary

The evaluation compares a simple vector-only baseline with the enhanced CatalogueIQ retrieval-augmented generation pipeline across 20 questions covering product facts, policy eligibility, seller guidance, recommendations, and multi-hop support cases.

The illustrative composite score improves from **0.8047** to **0.9400**, an absolute gain of **0.1353** and a relative improvement of **16.81%**. The strongest improvements occur in comparative recommendations and multi-hop questions, where query expansion, filtering, reciprocal-rank fusion, and source diversification address weaknesses in the vector-only baseline.

The enhanced pipeline meets all configured illustrative targets. Citation validity reaches **1.0000** because unsupported citations are rejected. The trade-off is higher average latency, increasing from **756.85 ms** to **895.30 ms**.

---

## 2. Evaluation Objectives

The evaluation is designed to measure whether CatalogueIQ can:

1. Retrieve evidence relevant to the user's question.
2. Produce answers supported by retrieved context.
3. Apply hard constraints before recommending products.
4. Keep product facts, policies, and customer-review opinions distinct.
5. Cite only evidence that was retrieved.
6. Support Shopper, Seller, and Support Agent personas.
7. Handle multi-source and multi-hop questions.
8. Preserve conversational preferences without treating prior generated answers as authoritative evidence.

---

## 3. Test-Set Composition

The test set contains **20** questions.

| Query type | Questions |
|---|---:|
| Product factual lookup | 4 |
| Policy eligibility | 4 |
| Seller policy lookup | 3 |
| Comparative recommendation | 5 |
| Multi-hop reasoning | 4 |

### Persona distribution

- Shopper: 12 questions
- Seller: 3 questions
- Support Agent: 5 questions

The questions include exact product-ID lookups, return eligibility, seller image requirements, category attributes, filtered product comparisons, warranty scenarios, counterfeit concerns, and escalation procedures.

---

## 4. Compared Pipeline Configurations

### 4.1 Baseline

The baseline uses:

- Vector-only retrieval
- `all-MiniLM-L6-v2` embeddings
- 384-dimensional vectors
- Cosine distance
- Top 5 retrieval
- 800-character chunks with 120-character overlap
- No query expansion
- No metadata pre-filtering
- No deterministic post-filtering
- No reranking or reciprocal-rank fusion
- No source diversification

### 4.2 Improved Pipeline

The enhanced pipeline adds:

- Up to four query variants
- E-commerce synonym expansion
- Structured constraint extraction
- LanceDB metadata pre-filtering
- Deterministic post-filtering for ANC, battery life, size, brand exclusions, stock, and seller verification
- Reciprocal Rank Fusion with `rrf_k = 60`
- Three-times candidate expansion before final filtering
- Source diversification for policy and multi-hop questions
- Persona-specific grounded prompts
- Citation validation
- Five-turn session memory
- Strict separation of memory from retrieved evidence

---

## 5. Overall Results

| Metric | Baseline | Improved | Absolute change | Relative change |
|---|---:|---:|---:|---:|
| Faithfulness | 0.8030 | 0.9375 | +0.1345 | +16.75% |
| Answer relevancy | 0.8325 | 0.9280 | +0.0955 | +11.47% |
| Context precision | 0.7285 | 0.8945 | +0.1660 | +22.79% |
| Citation validity | 0.8550 | 1.0000 | +0.1450 | +16.96% |
| Context-recall proxy | 0.5425 | 0.8555 | +0.3130 | +57.70% |
| Composite score | 0.8047 | 0.9400 | +0.1353 | +16.81% |

### Latency

| Measure | Baseline | Improved | Change |
|---|---:|---:|---:|
| Average latency | 756.85 ms | 895.30 ms | +138.45 ms (+18.29%) |

The enhanced pipeline sacrifices some speed to execute multiple query variants, retrieve more candidates, validate hard constraints, fuse rankings, and diversify source evidence.

---

## 6. Results by Query Type

| Query type | Questions | Baseline composite | Improved composite | Improvement |
|---|---:|---:|---:|---:|
| `comparative_recommendation` | 5 | 0.7025 | 0.9245 | +0.2220 |
| `multi_hop` | 4 | 0.7231 | 0.9231 | +0.2000 |
| `policy_eligibility` | 4 | 0.8875 | 0.9531 | +0.0656 |
| `product_factual_lookup` | 4 | 0.8719 | 0.9519 | +0.0800 |
| `seller_policy_lookup` | 3 | 0.8842 | 0.9550 | +0.0708 |

### Interpretation

#### Product factual lookup

Exact product identifiers provide strong retrieval anchors, so the baseline already performs well. The enhanced pipeline still improves accuracy through exact metadata constraints and citation checks.

#### Policy eligibility

The improved pipeline retrieves complementary policy and FAQ evidence, which strengthens context precision and reduces unsupported eligibility decisions.

#### Seller policy lookup

Source-aware routing gives priority to the seller onboarding guide and category guides. This helps preserve exact dimensions, attribute requirements, and prohibited listing practices.

#### Comparative recommendation

This is the most important improvement area. Semantic similarity alone cannot guarantee that a product meets budget, stock, ANC, battery, rating, size, or seller constraints. The enhanced pipeline filters these requirements before presenting recommendations.

#### Multi-hop reasoning

Multi-hop questions require evidence from more than one source, such as return policy, buyer FAQ, warranty guidance, and escalation procedures. Source diversification and expanded queries improve coverage.

---

## 7. Results by Persona

| Persona | Questions | Baseline composite | Improved composite | Improvement |
|---|---:|---:|---:|---:|
| `seller` | 3 | 0.8842 | 0.9550 | +0.0708 |
| `shopper` | 12 | 0.8050 | 0.9410 | +0.1360 |
| `support_agent` | 5 | 0.7565 | 0.9285 | +0.1720 |

The Shopper persona benefits most from strict recommendation filters. The Seller persona benefits from exact category and onboarding guidance. The Support Agent persona benefits from multi-source retrieval and explicit separation of confirmed facts from pending verification.

---

## 8. Threshold Assessment

| Metric | Target | Improved result | Status |
|---|---:|---:|---|
| Faithfulness | 0.8500 | 0.9375 | Met |
| Answer relevancy | 0.8500 | 0.9280 | Met |
| Context precision | 0.8000 | 0.8945 | Met |
| Citation validity | 1.0000 | 1.0000 | Met |
| Composite score | 0.8500 | 0.9400 | Met |

All configured illustrative targets are met by the enhanced result set.

---

## 9. Key Improvements and Their Effects

### 9.1 Query expansion

The enhanced retriever expands terms such as `earphones`, `earbuds`, and `TWS` while preserving hard constraints. This improves recall without dropping budget, feature, or exclusion requirements.

### 9.2 Metadata pre-filtering

Typed LanceDB filters remove obviously ineligible records before semantic ranking. Examples include category, subcategory, price, rating, stock availability, brand, and seller verification.

### 9.3 Deterministic post-filtering

Nested specifications such as ANC, battery life, and Fashion size are checked after retrieval. A product that fails a mandatory condition is not recommended merely because its embedding is similar to the query.

### 9.4 Reciprocal Rank Fusion

Results found consistently across the original query and its variants receive stronger fused rankings. This makes retrieval less dependent on one wording of the user's intent.

### 9.5 Source diversification

Policy and multi-hop searches retrieve evidence from different document types. This reduces the risk that many similar chunks from one large document crowd out complementary evidence.

### 9.6 Citation validation

Every generated citation is compared with citations available from retrieved evidence. Unsupported or invented citation markers cause the answer to fail grounding validation.

### 9.7 Conversation memory

Session memory retains user-stated preferences across five turns, including budget, category, ANC, battery life, size, and brand exclusions. Previous assistant claims are not treated as authoritative evidence, and fresh retrieval is required for each turn.

---

## 10. Error Analysis

The baseline's main weaknesses are:

- Semantically similar products may violate hard constraints.
- Exact model or product-ID questions may be diluted by broad vector matches.
- Policy answers may retrieve related but incomplete sections.
- Multi-hop questions may lack evidence from all required source types.
- Review themes may be retrieved without their associated product facts.
- Citations may be missing or may not correspond to retrieved evidence.

Residual risks in the enhanced design include:

- Query expansion can increase latency and retrieval cost.
- Regex-based constraint extraction may miss unusual phrasings.
- Product specifications stored only in free text may be harder to filter reliably.
- A small evaluation set may not represent all catalogue categories and conversational patterns.
- Model-based RAGAS metrics can vary with evaluator model, prompt, and version.

---

## 11. Limitations of This Report

1. The metric values are synthetic and illustrative.
2. The evaluation set contains only 20 questions.
3. The context-recall value is an illustrative proxy, not a fully annotated RAGAS context-recall score.
4. Latency values are illustrative and do not represent a controlled production benchmark.
5. No statistical confidence intervals are calculated.
6. No adversarial prompt-injection, multilingual, malformed-input, or load-testing results are included.
7. Results must be regenerated after changes to source documents, chunking, embeddings, retriever configuration, or prompts.

---

## 12. Recommended Live Evaluation Procedure

Before final submission, run an actual evaluation as follows:

1. Ingest the complete knowledge base with `scripts/ingest.py`.
2. Execute every question in `evaluation/test_set.json` through the baseline configuration.
3. Save the actual generated answer and retrieved contexts for each question.
4. Run RAGAS faithfulness, answer relevancy, and context precision.
5. Run deterministic citation validation and hard-constraint checks.
6. Repeat the process using the enhanced pipeline.
7. Compare per-question and aggregate scores.
8. Manually review low-scoring and high-risk answers.
9. Record evaluator model, package versions, seed, date, and runtime environment.
10. Replace the illustrative JSON files and this report's values with live results.

Expected runtime record structure:

```json
{
  "id": "CQ-001",
  "user_input": "What is the price, rating, warranty period, and availability of product P0001?",
  "retrieved_contexts": ["..."],
  "response": "...",
  "reference": "...",
  "faithfulness": 0.0,
  "answer_relevancy": 0.0,
  "context_precision": 0.0,
  "citation_validity": 0.0,
  "latency_ms": 0
}
```

---

## 13. Acceptance Criteria

The enhanced pipeline should be accepted only when:

- All required source files ingest successfully.
- Chunk IDs are unique and no empty chunks are stored.
- Product constraints are applied before recommendation.
- Unsupported citations are rejected.
- Faithfulness is at least `0.85`.
- Answer relevancy is at least `0.85`.
- Context precision is at least `0.80`.
- Citation validity is `1.00`.
- Composite score is at least `0.85`.
- High-risk policy and multi-hop answers pass manual review.

---

## 14. Conclusion

The illustrative comparison indicates that the enhanced CatalogueIQ architecture is materially stronger than a vector-only baseline. The composite score rises by **0.1353**, with especially meaningful gains in comparative recommendations and multi-hop support scenarios. The improvements are consistent with the design changes: query expansion improves recall, metadata and post-filtering enforce hard constraints, reciprocal-rank fusion stabilizes rankings, source diversification broadens evidence coverage, and citation validation reduces unsupported claims.

However, these figures must not be reported as measured production performance. The final project should execute a real RAGAS evaluation, preserve the actual answers and retrieved contexts, and update `baseline_results.json`, `improved_results.json`, and this report with live outputs.

---

## 15. Document Control

| Version | Date | Change |
|---|---|---|
| 1.0 | 11 September 2026 | Initial CatalogueIQ evaluation report based on illustrative baseline and improved result sets |

**End of CatalogueIQ Evaluation Report**
