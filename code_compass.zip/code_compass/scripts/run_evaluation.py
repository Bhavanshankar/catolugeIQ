#!/usr/bin/env python3
"""Evaluate the CatalogueIQ RAG pipeline.

The script runs an evaluation dataset through ``CatalogueRAGChain`` and writes
per-case and aggregate metrics. It supports two evaluation layers:

1. Deterministic checks available without an evaluator LLM:
   retrieval hit rate, reciprocal rank, citation validity, citation coverage,
   constraint compliance, answer availability, and latency.
2. Optional RAGAS metrics when ``ragas`` and judge dependencies are installed:
   faithfulness, answer relevancy, context precision, and context recall.

Evaluation input is JSON or JSONL. Each case may contain::

    {
      "id": "product-001",
      "question": "Which earbuds under 3000 support ANC?",
      "persona": "shopper",
      "reference_answer": "...",
      "reference_product_ids": ["P0101"],
      "reference_sources": ["product_catalog.csv"],
      "reference_contexts": ["optional gold context"],
      "tags": ["comparison", "electronics"]
    }

Run from the project root after ingestion::

    python scripts/run_evaluation.py --dataset data/evaluation/eval_cases.jsonl
    python scripts/run_evaluation.py --dataset data/evaluation/eval_cases.json --ragas
"""

from __future__ import annotations

import argparse
import json
import math
import os
import statistics
import sys
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from catalogueiq.citations import citation_coverage, validate_citations
from catalogueiq.embeddings import EmbeddingConfig, create_embedding_provider
from catalogueiq.filters import evaluate_metadata
from catalogueiq.lancedb_store import LanceDBConfig, LanceDBStore
from catalogueiq.memory import ConversationMemory
from catalogueiq.rag_chain import (
    CatalogueRAGChain,
    OpenAIChatProvider,
    RAGConfig,
)
from catalogueiq.retriever import CatalogueRetriever, RetrieverConfig

DEFAULT_DATASET = PROJECT_ROOT / "data" / "evaluation" / "eval_cases.jsonl"
DEFAULT_OUTPUT = PROJECT_ROOT / "data" / "processed" / "evaluation_report.json"
DEFAULT_LANCEDB_URI = PROJECT_ROOT / "storage" / "lancedb"
DEFAULT_TABLE = "knowledge_chunks"
REQUIRED_RAGAS_KEYS = (
    "faithfulness",
    "answer_relevancy",
    "context_precision",
    "context_recall",
)


@dataclass(slots=True)
class EvaluationCase:
    id: str
    question: str
    persona: str = "shopper"
    reference_answer: str | None = None
    reference_product_ids: list[str] = field(default_factory=list)
    reference_sources: list[str] = field(default_factory=list)
    reference_contexts: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any], index: int) -> "EvaluationCase":
        question = str(value.get("question", "")).strip()
        if not question:
            raise ValueError(f"evaluation case {index} has no question")
        return cls(
            id=str(value.get("id") or f"case-{index:04d}"),
            question=question,
            persona=str(value.get("persona") or "shopper"),
            reference_answer=_optional_text(
                value.get("reference_answer", value.get("ground_truth"))
            ),
            reference_product_ids=_string_list(value.get("reference_product_ids")),
            reference_sources=_string_list(value.get("reference_sources")),
            reference_contexts=_string_list(value.get("reference_contexts")),
            tags=_string_list(value.get("tags")),
            metadata=dict(value.get("metadata") or {}),
        )


@dataclass(slots=True)
class CaseResult:
    id: str
    question: str
    persona: str
    query_type: str
    answer: str
    retrieved_ids: list[str]
    retrieved_product_ids: list[str]
    retrieved_sources: list[str]
    contexts: list[str]
    citations: list[str]
    latency_seconds: float
    metrics: dict[str, float | None]
    ragas_metrics: dict[str, float | None]
    retrieval_trace: dict[str, Any]
    error: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class EvaluationReport:
    status: str
    created_at_epoch: float
    dataset: str
    case_count: int
    successful_cases: int
    failed_cases: int
    aggregate_metrics: dict[str, float | None]
    aggregate_ragas_metrics: dict[str, float | None]
    thresholds: dict[str, float]
    threshold_results: dict[str, bool]
    quality_gate_passed: bool
    configuration: dict[str, Any]
    cases: list[CaseResult]

    def as_dict(self) -> dict[str, Any]:
        output = asdict(self)
        output["cases"] = [case.as_dict() for case in self.cases]
        return output


def load_evaluation_cases(path: str | Path) -> list[EvaluationCase]:
    """Load evaluation cases from JSON or JSONL."""
    source = Path(path)
    if not source.is_file():
        raise FileNotFoundError(f"Evaluation dataset does not exist: {source}")
    if source.suffix.lower() == ".jsonl":
        values = []
        for line_number, line in enumerate(
            source.read_text(encoding="utf-8").splitlines(), start=1
        ):
            if not line.strip():
                continue
            try:
                values.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSONL at line {line_number}: {exc}") from exc
    else:
        payload = json.loads(source.read_text(encoding="utf-8"))
        values = payload.get("cases", []) if isinstance(payload, dict) else payload
    if not isinstance(values, list) or not values:
        raise ValueError("Evaluation dataset must contain at least one case")
    return [EvaluationCase.from_mapping(value, index) for index, value in enumerate(values, 1)]


def build_rag_chain(
    *,
    lancedb_uri: str | Path,
    table_name: str,
    embedding_provider_name: str,
    embedding_model: str,
    embedding_dimensions: int | None,
    chat_model: str,
    search_type: str,
    max_variants: int,
    candidate_multiplier: int,
    known_brands: Sequence[str],
) -> CatalogueRAGChain:
    """Build a stateless chain for evaluation."""
    embedding_provider = None
    if search_type in {"vector", "hybrid"}:
        embedding_provider = create_embedding_provider(
            EmbeddingConfig(
                provider=embedding_provider_name,
                model=embedding_model,
                dimensions=embedding_dimensions,
                normalize=True,
                cache_enabled=False,
                show_progress=False,
            )
        )
    store = LanceDBStore(
        LanceDBConfig(
            uri=str(lancedb_uri),
            table_name=table_name,
            distance_type="cosine",
        )
    )
    if not store.table_exists():
        raise FileNotFoundError(
            f"LanceDB table {table_name!r} does not exist. Run scripts/ingest.py."
        )
    retriever = CatalogueRetriever(
        store,
        embedding_provider,
        config=RetrieverConfig(
            search_type=search_type,
            max_query_variants=max_variants,
            candidate_multiplier=candidate_multiplier,
            source_diversity=True,
            strict_product_constraints=True,
            fallback_without_filters=False,
        ),
        known_brands=known_brands,
    )
    return CatalogueRAGChain(
        retriever,
        OpenAIChatProvider(model_name=chat_model),
        config=RAGConfig(
            temperature=0.0,
            max_tokens=700,
            require_citations=True,
            minimum_results=1,
            use_memory=False,
            include_conversation_history=False,
        ),
    )


def evaluate_case(
    case: EvaluationCase,
    chain: CatalogueRAGChain,
) -> CaseResult:
    """Evaluate one question and return deterministic metrics."""
    started = time.perf_counter()
    try:
        response = chain.ask(case.question, persona=case.persona)
        latency = time.perf_counter() - started
        retrieval = response.retrieval
        results = retrieval.results if retrieval else []
        product_ids = _unique(
            str(item.metadata.get("product_id"))
            for item in results
            if item.metadata.get("product_id")
        )
        sources = _unique(
            str(item.metadata.get("source"))
            for item in results
            if item.metadata.get("source")
        )
        retrieved_ids = [item.id for item in results]
        contexts = [item.text for item in results]
        citation_report = validate_citations(
            response.answer,
            results,
            require_at_least_one=bool(results),
        )
        coverage = citation_coverage(response.answer)
        metrics = {
            "answer_available": float(bool(response.answer.strip())),
            "retrieval_hit": retrieval_hit(case, product_ids, sources),
            "reciprocal_rank": reciprocal_rank(case, results),
            "citation_validity": float(citation_report.passed),
            "citation_coverage": float(coverage["coverage"]),
            "constraint_compliance": constraint_compliance(response),
            "latency_seconds": latency,
        }
        return CaseResult(
            id=case.id,
            question=case.question,
            persona=case.persona,
            query_type=response.query_type,
            answer=response.answer,
            retrieved_ids=retrieved_ids,
            retrieved_product_ids=product_ids,
            retrieved_sources=sources,
            contexts=contexts,
            citations=response.citations,
            latency_seconds=round(latency, 6),
            metrics=metrics,
            ragas_metrics={key: None for key in REQUIRED_RAGAS_KEYS},
            retrieval_trace=(retrieval.trace.as_dict() if retrieval else {}),
        )
    except Exception as exc:
        latency = time.perf_counter() - started
        return CaseResult(
            id=case.id,
            question=case.question,
            persona=case.persona,
            query_type="unknown",
            answer="",
            retrieved_ids=[],
            retrieved_product_ids=[],
            retrieved_sources=[],
            contexts=[],
            citations=[],
            latency_seconds=round(latency, 6),
            metrics={
                "answer_available": 0.0,
                "retrieval_hit": 0.0,
                "reciprocal_rank": 0.0,
                "citation_validity": 0.0,
                "citation_coverage": 0.0,
                "constraint_compliance": 0.0,
                "latency_seconds": latency,
            },
            ragas_metrics={key: None for key in REQUIRED_RAGAS_KEYS},
            retrieval_trace={},
            error=str(exc),
        )


def run_ragas_evaluation(
    cases: Sequence[EvaluationCase],
    results: Sequence[CaseResult],
    *,
    judge_model: str,
    show_progress: bool = True,
) -> list[dict[str, float | None]]:
    """Run four RAGAS metrics and return one metric dictionary per case.

    This function accepts modern RAGAS result objects and verifies that every
    returned metric is either ``None`` or a finite float between 0 and 1.
    """
    try:
        from datasets import Dataset
        from langchain_openai import ChatOpenAI, OpenAIEmbeddings
        from ragas import evaluate
        from ragas.metrics import (
            answer_relevancy,
            context_precision,
            context_recall,
            faithfulness,
        )
    except ImportError as exc:
        raise RuntimeError(
            "RAGAS evaluation requires: pip install ragas datasets "
            "langchain-openai"
        ) from exc

    records = {
        "question": [case.question for case in cases],
        "answer": [result.answer for result in results],
        "contexts": [result.contexts for result in results],
        "ground_truth": [case.reference_answer or "" for case in cases],
    }
    dataset = Dataset.from_dict(records)
    evaluation = evaluate(
        dataset=dataset,
        metrics=[faithfulness, answer_relevancy, context_precision, context_recall],
        llm=ChatOpenAI(model=judge_model, temperature=0),
        embeddings=OpenAIEmbeddings(model="text-embedding-3-small"),
        raise_exceptions=False,
        show_progress=show_progress,
    )
    frame = evaluation.to_pandas()
    output: list[dict[str, float | None]] = []
    for _, row in frame.iterrows():
        values: dict[str, float | None] = {}
        for key in REQUIRED_RAGAS_KEYS:
            value = row.get(key)
            if value is None or (isinstance(value, float) and math.isnan(value)):
                values[key] = None
            else:
                number = float(value)
                if not math.isfinite(number) or not 0.0 <= number <= 1.0:
                    raise RuntimeError(f"Invalid RAGAS value for {key}: {value}")
                values[key] = number
        output.append(values)
    if len(output) != len(cases):
        raise RuntimeError(
            f"RAGAS returned {len(output)} rows for {len(cases)} evaluation cases"
        )
    return output


def run_evaluation(
    dataset_path: str | Path,
    chain: CatalogueRAGChain,
    *,
    use_ragas: bool = False,
    judge_model: str = "gpt-4.1-mini",
    show_progress: bool = True,
    thresholds: Mapping[str, float] | None = None,
    configuration: Mapping[str, Any] | None = None,
) -> EvaluationReport:
    """Execute the evaluation suite and calculate aggregate quality gates."""
    cases = load_evaluation_cases(dataset_path)
    results: list[CaseResult] = []
    for index, case in enumerate(cases, start=1):
        if show_progress:
            print(f"Evaluating {index}/{len(cases)}: {case.id}", file=sys.stderr)
        results.append(evaluate_case(case, chain))

    if use_ragas:
        successful_indexes = [index for index, result in enumerate(results) if not result.error]
        successful_cases = [cases[index] for index in successful_indexes]
        successful_results = [results[index] for index in successful_indexes]
        if successful_cases:
            ragas_rows = run_ragas_evaluation(
                successful_cases,
                successful_results,
                judge_model=judge_model,
                show_progress=show_progress,
            )
            for index, values in zip(successful_indexes, ragas_rows):
                results[index].ragas_metrics = values

    aggregate = aggregate_metrics([result.metrics for result in results])
    aggregate_ragas = aggregate_metrics(
        [result.ragas_metrics for result in results], keys=REQUIRED_RAGAS_KEYS
    )
    final_thresholds = dict(
        thresholds
        or {
            "retrieval_hit": 0.80,
            "citation_validity": 0.95,
            "citation_coverage": 0.80,
            "constraint_compliance": 0.90,
        }
    )
    combined = {**aggregate, **aggregate_ragas}
    threshold_results = {
        key: combined.get(key) is not None and float(combined[key]) >= threshold
        for key, threshold in final_thresholds.items()
    }
    failed = sum(bool(result.error) for result in results)
    return EvaluationReport(
        status="success" if failed == 0 else "completed_with_errors",
        created_at_epoch=round(time.time(), 3),
        dataset=str(dataset_path),
        case_count=len(results),
        successful_cases=len(results) - failed,
        failed_cases=failed,
        aggregate_metrics=aggregate,
        aggregate_ragas_metrics=aggregate_ragas,
        thresholds=final_thresholds,
        threshold_results=threshold_results,
        quality_gate_passed=failed == 0 and all(threshold_results.values()),
        configuration=dict(configuration or {}),
        cases=results,
    )


def retrieval_hit(
    case: EvaluationCase,
    product_ids: Sequence[str],
    sources: Sequence[str],
) -> float:
    """Return 1 when at least one expected product or source was retrieved."""
    expected_products = set(case.reference_product_ids)
    expected_sources = set(case.reference_sources)
    if not expected_products and not expected_sources:
        return 1.0
    product_hit = bool(expected_products.intersection(product_ids)) if expected_products else False
    source_hit = bool(expected_sources.intersection(sources)) if expected_sources else False
    return float(product_hit or source_hit)


def reciprocal_rank(case: EvaluationCase, results: Sequence[Any]) -> float:
    """Calculate reciprocal rank of the first expected product or source."""
    expected_products = set(case.reference_product_ids)
    expected_sources = set(case.reference_sources)
    if not expected_products and not expected_sources:
        return 1.0
    for rank, result in enumerate(results, start=1):
        metadata = result.metadata
        if (
            metadata.get("product_id") in expected_products
            or metadata.get("source") in expected_sources
        ):
            return 1.0 / rank
    return 0.0


def constraint_compliance(response: Any) -> float:
    """Check final catalogue results against extracted mandatory constraints."""
    retrieval = response.retrieval
    if not retrieval or not retrieval.results:
        return 0.0
    constraints = retrieval.expanded_query.constraints
    catalogue = [
        result
        for result in retrieval.results
        if result.metadata.get("source_type") == "catalogue"
    ]
    if not catalogue:
        return 1.0
    decisions = [
        evaluate_metadata(
            {**result.metadata, "text": result.text},
            constraints,
            strict_missing=True,
        )
        for result in catalogue
    ]
    return sum(decision.accepted for decision in decisions) / len(decisions)


def aggregate_metrics(
    rows: Sequence[Mapping[str, float | None]],
    *,
    keys: Sequence[str] | None = None,
) -> dict[str, float | None]:
    """Average finite, non-null metric values."""
    selected_keys = list(keys or _unique(key for row in rows for key in row))
    output: dict[str, float | None] = {}
    for key in selected_keys:
        values = [
            float(row[key])
            for row in rows
            if row.get(key) is not None and math.isfinite(float(row[key]))
        ]
        output[key] = round(statistics.fmean(values), 6) if values else None
    return output


def write_report(report: EvaluationReport, path: str | Path) -> Path:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + ".tmp")
    temporary.write_text(
        json.dumps(report.as_dict(), indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    temporary.replace(output)
    return output


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Evaluate the CatalogueIQ RAG pipeline.")
    parser.add_argument("--dataset", type=Path, default=DEFAULT_DATASET)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--lancedb-uri", type=Path, default=DEFAULT_LANCEDB_URI)
    parser.add_argument("--table-name", default=DEFAULT_TABLE)
    parser.add_argument(
        "--embedding-provider",
        choices=("sentence_transformers", "openai"),
        default="sentence_transformers",
    )
    parser.add_argument("--embedding-model", default=None)
    parser.add_argument("--embedding-dimensions", type=int, default=None)
    parser.add_argument("--chat-model", default="gpt-4.1-mini")
    parser.add_argument("--judge-model", default="gpt-4.1-mini")
    parser.add_argument(
        "--search-type", choices=("vector", "fts", "hybrid"), default="vector"
    )
    parser.add_argument("--max-variants", type=int, default=4)
    parser.add_argument("--candidate-multiplier", type=int, default=3)
    parser.add_argument("--known-brand", action="append", default=[])
    parser.add_argument("--ragas", action="store_true")
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--fail-on-gate", action="store_true")
    parser.add_argument(
        "--threshold",
        action="append",
        default=[],
        metavar="METRIC=VALUE",
        help="Override a quality threshold. Repeatable.",
    )
    return parser


def parse_thresholds(values: Sequence[str]) -> dict[str, float] | None:
    if not values:
        return None
    thresholds: dict[str, float] = {}
    for value in values:
        if "=" not in value:
            raise ValueError(f"Invalid threshold {value!r}; expected METRIC=VALUE")
        key, raw = value.split("=", 1)
        number = float(raw)
        if not 0 <= number <= 1:
            raise ValueError("threshold values must be between 0 and 1")
        thresholds[key.strip()] = number
    return thresholds


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    embedding_model = args.embedding_model or (
        "text-embedding-3-small"
        if args.embedding_provider == "openai"
        else "all-MiniLM-L6-v2"
    )
    configuration = {
        "lancedb_uri": str(args.lancedb_uri),
        "table_name": args.table_name,
        "embedding_provider": args.embedding_provider,
        "embedding_model": embedding_model,
        "chat_model": args.chat_model,
        "judge_model": args.judge_model if args.ragas else None,
        "search_type": args.search_type,
        "max_variants": args.max_variants,
        "candidate_multiplier": args.candidate_multiplier,
        "ragas_enabled": args.ragas,
    }
    try:
        thresholds = parse_thresholds(args.threshold)
        chain = build_rag_chain(
            lancedb_uri=args.lancedb_uri,
            table_name=args.table_name,
            embedding_provider_name=args.embedding_provider,
            embedding_model=embedding_model,
            embedding_dimensions=args.embedding_dimensions,
            chat_model=args.chat_model,
            search_type=args.search_type,
            max_variants=args.max_variants,
            candidate_multiplier=args.candidate_multiplier,
            known_brands=args.known_brand,
        )
        report = run_evaluation(
            args.dataset,
            chain,
            use_ragas=args.ragas,
            judge_model=args.judge_model,
            show_progress=not args.quiet,
            thresholds=thresholds,
            configuration=configuration,
        )
        write_report(report, args.output)
    except Exception as exc:
        print(f"CatalogueIQ evaluation failed: {exc}", file=sys.stderr)
        return 1

    if args.json:
        print(json.dumps(report.as_dict(), indent=2, ensure_ascii=False))
    else:
        print("CatalogueIQ evaluation completed.")
        print(f"Cases: {report.case_count}")
        print(f"Successful: {report.successful_cases}")
        print(f"Failed: {report.failed_cases}")
        print("Aggregate metrics:")
        for key, value in report.aggregate_metrics.items():
            print(f"  {key}: {_display_metric(value)}")
        if args.ragas:
            print("RAGAS metrics:")
            for key, value in report.aggregate_ragas_metrics.items():
                print(f"  {key}: {_display_metric(value)}")
        print(f"Quality gate: {'PASS' if report.quality_gate_passed else 'FAIL'}")
        print(f"Report: {args.output}")
    if args.fail_on_gate and not report.quality_gate_passed:
        return 2
    return 0


def _display_metric(value: float | None) -> str:
    return "N/A" if value is None else f"{value:.4f}"


def _optional_text(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _string_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, Iterable):
        return [str(item) for item in value]
    return [str(value)]


def _unique(values: Iterable[str]) -> list[str]:
    output: list[str] = []
    seen: set[str] = set()
    for value in values:
        if value and value not in seen:
            seen.add(value)
            output.append(value)
    return output


if __name__ == "__main__":
    raise SystemExit(main())
