#!/usr/bin/env python3
"""Ingest the CatalogueIQ knowledge base into LanceDB.

Pipeline:

1. Discover and load CSV, Markdown, and HTML files from ``data/raw``.
2. Apply source-aware chunking.
3. Validate generated chunks.
4. Generate embeddings with Sentence Transformers or OpenAI.
5. Store the embedded chunks in LanceDB.
6. Optionally create a full-text index and optimize the table.
7. Write a machine-readable ingestion report.

Run from the CatalogueIQ project root::

    python scripts/ingest.py
    python scripts/ingest.py --mode overwrite --create-fts
    python scripts/ingest.py --provider openai --model text-embedding-3-small
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Sequence

# Allow execution as ``python scripts/ingest.py`` without installing the package.
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from catalogueiq.chunking import chunk_documents, validate_chunks
from catalogueiq.embeddings import EmbeddingConfig, embed_chunks_from_config
from catalogueiq.lancedb_store import LanceDBConfig, LanceDBStore
from catalogueiq.loaders import discover_files, load_documents

DEFAULT_RAW_DIR = PROJECT_ROOT / "data" / "raw"
DEFAULT_REPORT_PATH = PROJECT_ROOT / "data" / "processed" / "ingestion_report.json"
DEFAULT_LANCEDB_URI = PROJECT_ROOT / "storage" / "lancedb"
DEFAULT_CACHE_PATH = PROJECT_ROOT / "storage" / "embedding_cache.sqlite3"
DEFAULT_TABLE_NAME = "knowledge_chunks"


@dataclass(slots=True)
class IngestionReport:
    """Serializable report for one ingestion run."""

    status: str
    started_at_epoch: float
    completed_at_epoch: float
    duration_seconds: float
    raw_directory: str
    discovered_files: list[str]
    documents_loaded: int
    chunks_generated: int
    chunks_by_source: dict[str, int]
    chunks_by_type: dict[str, int]
    embedding_provider: str
    embedding_model: str
    embedding_dimensions: int | None
    embedding_statistics: dict[str, int]
    lancedb_uri: str
    lancedb_table: str
    write_mode: str
    rows_written: int
    table_row_count: int
    fts_index_created: bool
    optimized: bool
    chunk_validation: dict[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def ingest(
    *,
    raw_dir: str | Path = DEFAULT_RAW_DIR,
    report_path: str | Path = DEFAULT_REPORT_PATH,
    lancedb_uri: str | Path = DEFAULT_LANCEDB_URI,
    table_name: str = DEFAULT_TABLE_NAME,
    provider: str = "sentence_transformers",
    model: str = "all-MiniLM-L6-v2",
    dimensions: int | None = None,
    batch_size: int = 64,
    normalize_embeddings: bool = True,
    cache_enabled: bool = True,
    cache_path: str | Path = DEFAULT_CACHE_PATH,
    chunk_size: int = 800,
    chunk_overlap: int = 120,
    mode: str = "overwrite",
    create_fts: bool = True,
    optimize: bool = False,
    device: str | None = None,
    show_progress: bool = True,
) -> IngestionReport:
    """Run the complete CatalogueIQ ingestion pipeline."""
    started = time.time()
    raw_path = Path(raw_dir)
    if not raw_path.is_dir():
        raise FileNotFoundError(f"Raw data directory does not exist: {raw_path}")
    if mode not in {"overwrite", "append", "upsert"}:
        raise ValueError("mode must be overwrite, append, or upsert")
    if chunk_size <= 0 or chunk_overlap < 0 or chunk_overlap >= chunk_size:
        raise ValueError("chunk_size must be positive and overlap must be smaller")

    source_files = discover_files(raw_path, recursive=False, include_json=False)
    if not source_files:
        raise FileNotFoundError(f"No supported source files found in: {raw_path}")

    documents = load_documents(source_files, strict=True)
    if not documents:
        raise RuntimeError("No documents were produced by the source loaders")

    chunks = chunk_documents(
        documents,
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )
    validation = validate_chunks(chunks)
    if not validation["valid"]:
        raise RuntimeError(
            "Chunk validation failed: " + json.dumps(validation, ensure_ascii=False)
        )

    embedding_config = EmbeddingConfig(
        provider=provider,
        model=model,
        dimensions=dimensions,
        batch_size=batch_size,
        normalize=normalize_embeddings,
        cache_enabled=cache_enabled,
        cache_path=str(cache_path),
        device=device,
        show_progress=show_progress,
    )
    embedded_chunks, embedding_statistics = embed_chunks_from_config(
        chunks,
        embedding_config,
    )
    if len(embedded_chunks) != len(chunks):
        raise RuntimeError(
            f"Embedding output mismatch: {len(embedded_chunks)} for {len(chunks)} chunks"
        )

    store = LanceDBStore(
        LanceDBConfig(
            uri=str(lancedb_uri),
            table_name=table_name,
            distance_type="cosine",
        )
    )
    if mode == "overwrite":
        rows_written = store.create_or_replace(embedded_chunks)
    elif mode == "append":
        rows_written = store.append(embedded_chunks)
    else:
        rows_written = store.upsert(embedded_chunks)

    fts_created = False
    if create_fts:
        store.create_fts_index(replace=True)
        fts_created = True

    optimized_table = False
    if optimize:
        store.optimize()
        optimized_table = True

    table_rows = store.count()
    completed = time.time()
    chunk_sources = Counter(str(chunk.metadata.get("source", "unknown")) for chunk in chunks)
    chunk_types = Counter(str(chunk.metadata.get("chunk_type", "unknown")) for chunk in chunks)
    embedding_dimensions = (
        len(embedded_chunks[0].vector) if embedded_chunks else dimensions
    )

    report = IngestionReport(
        status="success",
        started_at_epoch=round(started, 3),
        completed_at_epoch=round(completed, 3),
        duration_seconds=round(completed - started, 3),
        raw_directory=str(raw_path),
        discovered_files=[path.name for path in source_files],
        documents_loaded=len(documents),
        chunks_generated=len(chunks),
        chunks_by_source=dict(sorted(chunk_sources.items())),
        chunks_by_type=dict(sorted(chunk_types.items())),
        embedding_provider=provider,
        embedding_model=model,
        embedding_dimensions=embedding_dimensions,
        embedding_statistics=embedding_statistics,
        lancedb_uri=str(lancedb_uri),
        lancedb_table=table_name,
        write_mode=mode,
        rows_written=rows_written,
        table_row_count=table_rows,
        fts_index_created=fts_created,
        optimized=optimized_table,
        chunk_validation=validation,
    )
    write_report(report, report_path)
    return report


def write_report(report: IngestionReport, path: str | Path) -> Path:
    """Write the ingestion report atomically."""
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + ".tmp")
    temporary.write_text(
        json.dumps(report.as_dict(), indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    temporary.replace(output)
    return output


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Load, chunk, embed, and index CatalogueIQ data in LanceDB."
    )
    parser.add_argument("--raw-dir", type=Path, default=DEFAULT_RAW_DIR)
    parser.add_argument("--report-path", type=Path, default=DEFAULT_REPORT_PATH)
    parser.add_argument("--lancedb-uri", type=Path, default=DEFAULT_LANCEDB_URI)
    parser.add_argument("--table-name", default=DEFAULT_TABLE_NAME)
    parser.add_argument(
        "--provider",
        choices=("sentence_transformers", "openai"),
        default="sentence_transformers",
    )
    parser.add_argument("--model", default=None)
    parser.add_argument("--dimensions", type=int, default=None)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--chunk-size", type=int, default=800)
    parser.add_argument("--chunk-overlap", type=int, default=120)
    parser.add_argument(
        "--mode", choices=("overwrite", "append", "upsert"), default="overwrite"
    )
    parser.add_argument("--cache-path", type=Path, default=DEFAULT_CACHE_PATH)
    parser.add_argument("--no-cache", action="store_true")
    parser.add_argument("--no-normalize", action="store_true")
    parser.add_argument("--no-fts", action="store_true")
    parser.add_argument("--optimize", action="store_true")
    parser.add_argument("--device", default=None, help="cpu, cuda, mps, or provider default")
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument("--json", action="store_true")
    return parser


def _default_model(provider: str) -> str:
    if provider == "openai":
        return "text-embedding-3-small"
    return "all-MiniLM-L6-v2"


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    model = args.model or _default_model(args.provider)
    try:
        report = ingest(
            raw_dir=args.raw_dir,
            report_path=args.report_path,
            lancedb_uri=args.lancedb_uri,
            table_name=args.table_name,
            provider=args.provider,
            model=model,
            dimensions=args.dimensions,
            batch_size=args.batch_size,
            normalize_embeddings=not args.no_normalize,
            cache_enabled=not args.no_cache,
            cache_path=args.cache_path,
            chunk_size=args.chunk_size,
            chunk_overlap=args.chunk_overlap,
            mode=args.mode,
            create_fts=not args.no_fts,
            optimize=args.optimize,
            device=args.device,
            show_progress=not args.quiet,
        )
    except Exception as exc:
        print(f"CatalogueIQ ingestion failed: {exc}", file=sys.stderr)
        return 1

    if args.json:
        print(json.dumps(report.as_dict(), indent=2, ensure_ascii=False))
    else:
        print("CatalogueIQ ingestion completed successfully.")
        print(f"Files discovered: {len(report.discovered_files)}")
        print(f"Documents loaded: {report.documents_loaded}")
        print(f"Chunks generated: {report.chunks_generated}")
        print(f"Rows written: {report.rows_written}")
        print(f"LanceDB table rows: {report.table_row_count}")
        print(
            "Embedding cache: "
            f"{report.embedding_statistics.get('cache_hits', 0)} hits, "
            f"{report.embedding_statistics.get('embedded', 0)} new"
        )
        print(f"Report: {args.report_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
