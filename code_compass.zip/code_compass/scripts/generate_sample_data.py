#!/usr/bin/env python3
"""Generate deterministic synthetic ShopSmart India data for CatalogueIQ.

The script creates the structured sample files used by the CatalogueIQ RAG
project:

* ``product_catalog.csv`` with products across five categories.
* ``product_review_summaries.csv`` for the highest-rated products.

The generated company, brands, sellers, products, reviews, and operational
values are fictional. Existing files are not overwritten unless ``--force`` is
supplied.

Examples::

    python scripts/generate_sample_data.py
    python scripts/generate_sample_data.py --products 500 --reviews 100 --force
    python scripts/generate_sample_data.py --output-dir data/raw --seed 42
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import random
import sys
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Sequence

DEFAULT_OUTPUT_DIR = Path("data/raw")
DEFAULT_PRODUCT_COUNT = 500
DEFAULT_REVIEW_COUNT = 100
DEFAULT_SEED = 42
CATEGORIES = ("Electronics", "Fashion", "Home & Kitchen", "Beauty", "Books")

BRANDS: dict[str, tuple[str, ...]] = {
    "Electronics": (
        "Auralite", "NovaTech", "PulseOne", "VoltEdge", "SonicBay",
        "PixelNest", "Orbitron", "ZenByte",
    ),
    "Fashion": (
        "UrbanWeave", "IndiThread", "ModeCraft", "VivaStyle", "CottonCove",
        "TrendLoom", "AuraWear", "StreetRoot",
    ),
    "Home & Kitchen": (
        "HomeHarbor", "CookNest", "PureLiving", "KitchenBloom", "CasaCraft",
        "DailyEase", "BrightHome", "EcoHaven",
    ),
    "Beauty": (
        "GlowMint", "PurePetal", "SkinSage", "AuraLeaf", "VelvetBloom",
        "NatureMuse", "RadiantRoot", "CareCanvas",
    ),
    "Books": (
        "BlueQuill Press", "Maple House", "Insight Ink", "PageSpring",
        "Riverstone Books", "ScholarLeaf", "StoryArc", "Knowledge Nest",
    ),
}

SUBCATEGORIES: dict[str, tuple[str, ...]] = {
    "Electronics": (
        "Wireless Earbuds", "Smartwatch", "Bluetooth Speaker", "Power Bank",
        "Keyboard", "Mouse", "Smartphone", "Tablet",
    ),
    "Fashion": (
        "T-Shirt", "Jeans", "Kurta", "Dress", "Sneakers", "Jacket",
        "Handbag", "Watch",
    ),
    "Home & Kitchen": (
        "Mixer Grinder", "Cookware Set", "Water Bottle", "Bedsheet",
        "Storage Box", "Electric Kettle", "Table Lamp", "Air Fryer",
    ),
    "Beauty": (
        "Face Wash", "Moisturizer", "Sunscreen", "Shampoo", "Lipstick",
        "Serum", "Body Lotion", "Perfume",
    ),
    "Books": (
        "Fiction", "Business", "Technology", "Biography", "Self Help",
        "History", "Children", "Exam Preparation",
    ),
}

PRICE_RANGES = {
    "Electronics": (499, 49_999),
    "Fashion": (299, 4_999),
    "Home & Kitchen": (199, 12_999),
    "Beauty": (149, 2_999),
    "Books": (99, 1_999),
}

RETURN_WINDOWS = {
    "Electronics": 7,
    "Fashion": 30,
    "Home & Kitchen": 10,
    "Beauty": 7,
    "Books": 10,
}

COLOURS = (
    "Black", "White", "Blue", "Green", "Red", "Grey", "Beige", "Pink",
    "Navy", "Silver",
)

POSITIVE_THEMES: dict[str, tuple[str, ...]] = {
    "Electronics": (
        "strong battery life", "easy Bluetooth pairing", "clear sound quality",
        "responsive controls", "good value for money", "reliable daily performance",
    ),
    "Fashion": (
        "comfortable fit", "soft material", "good stitching", "accurate colour",
        "stylish design", "good value for money",
    ),
    "Home & Kitchen": (
        "easy to use", "sturdy build", "simple to clean", "space-saving design",
        "useful for daily tasks", "good value for money",
    ),
    "Beauty": (
        "lightweight texture", "pleasant fragrance", "easy application",
        "suitable for regular use", "good packaging", "good value for money",
    ),
    "Books": (
        "engaging writing", "clear explanations", "good print quality",
        "useful examples", "well-structured chapters", "good value for money",
    ),
}

NEGATIVE_THEMES: dict[str, tuple[str, ...]] = {
    "Electronics": (
        "charging could be faster", "controls need improvement",
        "performance varies at long range", "case feels slightly bulky",
        "instructions are brief",
    ),
    "Fashion": (
        "size may vary by body type", "material is thinner than expected",
        "colour may differ slightly", "limited size availability",
        "requires careful washing",
    ),
    "Home & Kitchen": (
        "power cord could be longer", "capacity may feel small",
        "finish scratches easily", "instructions need more detail",
        "slightly bulky for compact spaces",
    ),
    "Beauty": (
        "fragrance may not suit everyone", "quantity feels limited",
        "results vary by skin type", "packaging could be stronger",
        "may require patch testing",
    ),
    "Books": (
        "font size may feel small", "some sections are repetitive",
        "examples could be more detailed", "paper quality is average",
        "advanced readers may want more depth",
    ),
}

PRODUCT_FIELDS = (
    "product_id", "name", "brand", "category", "subcategory", "price_inr",
    "mrp_inr", "rating", "review_count", "seller_id", "seller_verified",
    "stock_quantity", "availability", "specifications_json", "warranty_months",
    "returnable", "return_window_days", "source",
)

REVIEW_FIELDS = (
    "review_summary_id", "product_id", "product_name", "brand", "category",
    "subcategory", "average_rating", "total_reviews", "positive_sentiment_pct",
    "neutral_sentiment_pct", "negative_sentiment_pct", "top_positive_theme_1",
    "top_positive_theme_2", "top_positive_theme_3", "top_negative_theme_1",
    "top_negative_theme_2", "review_summary", "recommendation_score", "source",
)


@dataclass(frozen=True, slots=True)
class GenerationSummary:
    """Summary returned after successful generation."""

    output_dir: str
    product_file: str
    review_file: str
    product_count: int
    review_count: int
    category_counts: dict[str, int]
    seed: int
    product_sha256: str
    review_sha256: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "output_dir": self.output_dir,
            "product_file": self.product_file,
            "review_file": self.review_file,
            "product_count": self.product_count,
            "review_count": self.review_count,
            "category_counts": dict(self.category_counts),
            "seed": self.seed,
            "product_sha256": self.product_sha256,
            "review_sha256": self.review_sha256,
        }


def generate_product_catalog(count: int, rng: random.Random) -> list[dict[str, Any]]:
    """Generate balanced fictional product records."""
    if count < len(CATEGORIES):
        raise ValueError(f"product count must be at least {len(CATEGORIES)}")

    rows: list[dict[str, Any]] = []
    for index in range(1, count + 1):
        category = CATEGORIES[(index - 1) % len(CATEGORIES)]
        subcategory = rng.choice(SUBCATEGORIES[category])
        brand = rng.choice(BRANDS[category])
        low, high = PRICE_RANGES[category]
        price = max(low, int(round(rng.randint(low, high) / 10) * 10 - 1))
        mrp = max(price, int(round(price * rng.uniform(1.05, 1.45))))
        rating = round(rng.uniform(3.4, 4.9), 1)
        stock = rng.randint(0, 350)
        verified = rng.random() < 0.82
        returnable = not (
            category == "Beauty"
            and subcategory in {"Lipstick", "Perfume"}
            and rng.random() < 0.55
        )
        warranty = (
            rng.choice((0, 6, 12, 18, 24))
            if category in {"Electronics", "Home & Kitchen"}
            else 0
        )
        product_id = f"P{index:04d}"
        name = f"{brand} {subcategory} {100 + index}"
        specifications = _specifications(category, subcategory, rng)

        rows.append(
            {
                "product_id": product_id,
                "name": name,
                "brand": brand,
                "category": category,
                "subcategory": subcategory,
                "price_inr": price,
                "mrp_inr": mrp,
                "rating": rating,
                "review_count": rng.randint(20, 12_000),
                "seller_id": f"S{rng.randint(1001, 1060)}",
                "seller_verified": str(verified).lower(),
                "stock_quantity": stock,
                "availability": "In Stock" if stock > 0 else "Out of Stock",
                "specifications_json": json.dumps(
                    specifications, ensure_ascii=False, separators=(",", ":")
                ),
                "warranty_months": warranty,
                "returnable": str(returnable).lower(),
                "return_window_days": RETURN_WINDOWS[category] if returnable else 0,
                "source": "ShopSmart India synthetic catalogue",
            }
        )
    return rows


def generate_review_summaries(
    products: Sequence[dict[str, Any]],
    count: int,
    rng: random.Random,
) -> list[dict[str, Any]]:
    """Generate review summaries for high-rated products across categories."""
    if count < 1:
        raise ValueError("review count must be greater than zero")
    if count > len(products):
        raise ValueError("review count cannot exceed product count")

    selected = _balanced_top_products(products, count)
    rows: list[dict[str, Any]] = []
    for index, product in enumerate(selected, start=1):
        category = str(product["category"])
        positives = rng.sample(POSITIVE_THEMES[category], 3)
        negatives = rng.sample(NEGATIVE_THEMES[category], 2)
        positive_pct = min(
            94,
            max(62, int(52 + float(product["rating"]) * 8 + rng.randint(-4, 4))),
        )
        neutral_pct = min(rng.randint(4, 12), 99 - positive_pct)
        negative_pct = 100 - positive_pct - neutral_pct
        recommendation_score = round(
            (float(product["rating"]) / 5) * 0.7 + (positive_pct / 100) * 0.3,
            3,
        )
        sentiment = (
            "highly positive"
            if positive_pct >= 85
            else "positive"
            if positive_pct >= 72
            else "mixed-positive"
        )
        summary = (
            f"Customers commonly appreciate {positives[0]}, {positives[1]}, "
            f"and {positives[2]}. Reported limitations include {negatives[0]} "
            f"and {negatives[1]}. Overall sentiment is {sentiment}."
        )
        rows.append(
            {
                "review_summary_id": f"RS{index:04d}",
                "product_id": product["product_id"],
                "product_name": product["name"],
                "brand": product["brand"],
                "category": category,
                "subcategory": product["subcategory"],
                "average_rating": product["rating"],
                "total_reviews": product["review_count"],
                "positive_sentiment_pct": positive_pct,
                "neutral_sentiment_pct": neutral_pct,
                "negative_sentiment_pct": negative_pct,
                "top_positive_theme_1": positives[0],
                "top_positive_theme_2": positives[1],
                "top_positive_theme_3": positives[2],
                "top_negative_theme_1": negatives[0],
                "top_negative_theme_2": negatives[1],
                "review_summary": summary,
                "recommendation_score": recommendation_score,
                "source": "ShopSmart India synthetic review aggregation",
            }
        )
    return rows


def generate_sample_data(
    output_dir: str | Path = DEFAULT_OUTPUT_DIR,
    *,
    product_count: int = DEFAULT_PRODUCT_COUNT,
    review_count: int = DEFAULT_REVIEW_COUNT,
    seed: int = DEFAULT_SEED,
    force: bool = False,
) -> GenerationSummary:
    """Generate and validate both structured CatalogueIQ datasets."""
    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    product_path = destination / "product_catalog.csv"
    review_path = destination / "product_review_summaries.csv"
    _check_output_paths((product_path, review_path), force=force)

    product_rng = random.Random(seed)
    review_rng = random.Random(seed + 1)
    products = generate_product_catalog(product_count, product_rng)
    reviews = generate_review_summaries(products, review_count, review_rng)
    validate_datasets(products, reviews)

    _write_csv(product_path, PRODUCT_FIELDS, products)
    _write_csv(review_path, REVIEW_FIELDS, reviews)

    return GenerationSummary(
        output_dir=str(destination),
        product_file=str(product_path),
        review_file=str(review_path),
        product_count=len(products),
        review_count=len(reviews),
        category_counts=dict(sorted(Counter(row["category"] for row in products).items())),
        seed=seed,
        product_sha256=_sha256_file(product_path),
        review_sha256=_sha256_file(review_path),
    )


def validate_datasets(
    products: Sequence[dict[str, Any]],
    reviews: Sequence[dict[str, Any]],
) -> None:
    """Validate IDs, categories, prices, ratings, joins, and sentiments."""
    if not products:
        raise ValueError("product dataset is empty")
    product_ids = [str(row["product_id"]) for row in products]
    if len(product_ids) != len(set(product_ids)):
        raise ValueError("product IDs are not unique")
    if set(row["category"] for row in products) != set(CATEGORIES):
        raise ValueError("product dataset does not cover all required categories")
    for row in products:
        if float(row["price_inr"]) <= 0:
            raise ValueError(f"invalid price for {row['product_id']}")
        if float(row["mrp_inr"]) < float(row["price_inr"]):
            raise ValueError(f"MRP is below price for {row['product_id']}")
        if not 0 <= float(row["rating"]) <= 5:
            raise ValueError(f"invalid rating for {row['product_id']}")
        try:
            specifications = json.loads(str(row["specifications_json"]))
        except json.JSONDecodeError as exc:
            raise ValueError(f"invalid specifications JSON for {row['product_id']}") from exc
        if not isinstance(specifications, dict):
            raise ValueError(f"specifications must be an object for {row['product_id']}")

    valid_ids = set(product_ids)
    review_ids = [str(row["review_summary_id"]) for row in reviews]
    if len(review_ids) != len(set(review_ids)):
        raise ValueError("review summary IDs are not unique")
    for row in reviews:
        if row["product_id"] not in valid_ids:
            raise ValueError(f"orphan review summary: {row['review_summary_id']}")
        total = sum(
            int(row[key])
            for key in (
                "positive_sentiment_pct",
                "neutral_sentiment_pct",
                "negative_sentiment_pct",
            )
        )
        if total != 100:
            raise ValueError(f"sentiment does not total 100: {row['review_summary_id']}")


def _specifications(
    category: str,
    subcategory: str,
    rng: random.Random,
) -> dict[str, Any]:
    specifications: dict[str, Any] = {"colour": rng.choice(COLOURS)}
    if subcategory == "Wireless Earbuds":
        specifications.update(
            {
                "battery_life_hours": rng.choice((18, 20, 24, 30, 36, 42, 50)),
                "anc": rng.choice((True, False)),
                "bluetooth": rng.choice(("5.1", "5.2", "5.3")),
                "water_resistance": rng.choice(("IPX4", "IPX5", "IPX7")),
            }
        )
    elif subcategory == "Smartwatch":
        specifications.update(
            {
                "display_inches": rng.choice((1.39, 1.43, 1.69, 1.78)),
                "battery_days": rng.choice((5, 7, 10, 14)),
                "gps": rng.choice((True, False)),
            }
        )
    elif subcategory == "Power Bank":
        specifications.update(
            {
                "capacity_mah": rng.choice((10_000, 20_000, 30_000)),
                "fast_charging_w": rng.choice((18, 20, 22.5, 30)),
            }
        )
    elif category == "Fashion":
        specifications.update(
            {
                "material": rng.choice(("Cotton", "Linen", "Denim", "Polyester Blend", "Viscose")),
                "size": rng.choice(("S", "M", "L", "XL", "XXL")),
                "fit": rng.choice(("Regular", "Slim", "Relaxed")),
            }
        )
    elif category == "Home & Kitchen":
        specifications.update(
            {
                "material": rng.choice(("Stainless Steel", "Plastic", "Glass", "Aluminium", "Cotton")),
                "capacity": rng.choice(("500 ml", "1 L", "1.5 L", "2 L", "5 L")),
            }
        )
    elif category == "Beauty":
        specifications.update(
            {
                "skin_hair_type": rng.choice(("All", "Dry", "Oily", "Combination", "Sensitive")),
                "quantity": rng.choice(("30 ml", "50 ml", "100 ml", "200 ml")),
            }
        )
    elif category == "Books":
        specifications.update(
            {
                "language": rng.choice(("English", "Hindi", "Tamil")),
                "format": rng.choice(("Paperback", "Hardcover")),
                "pages": rng.randint(120, 720),
            }
        )
    else:
        specifications.update(
            {
                "connectivity": rng.choice(("USB", "Bluetooth", "Wi-Fi")),
                "model_year": rng.choice((2024, 2025, 2026)),
            }
        )
    return specifications


def _balanced_top_products(
    products: Sequence[dict[str, Any]], count: int
) -> list[dict[str, Any]]:
    groups = {
        category: sorted(
            (row for row in products if row["category"] == category),
            key=lambda row: (float(row["rating"]), int(row["review_count"])),
            reverse=True,
        )
        for category in CATEGORIES
    }
    selected: list[dict[str, Any]] = []
    indexes = {category: 0 for category in CATEGORIES}
    while len(selected) < count:
        added = False
        for category in CATEGORIES:
            index = indexes[category]
            if index < len(groups[category]) and len(selected) < count:
                selected.append(groups[category][index])
                indexes[category] += 1
                added = True
        if not added:
            break
    if len(selected) != count:
        raise ValueError("unable to select requested number of review products")
    return selected


def _write_csv(
    path: Path,
    fields: Sequence[str],
    rows: Sequence[dict[str, Any]],
) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(fields), extrasaction="raise")
        writer.writeheader()
        writer.writerows(rows)


def _check_output_paths(paths: Iterable[Path], *, force: bool) -> None:
    existing = [str(path) for path in paths if path.exists()]
    if existing and not force:
        raise FileExistsError(
            "Refusing to overwrite existing files. Use --force: " + ", ".join(existing)
        )


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Generate synthetic CatalogueIQ product and review datasets."
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help="Destination directory. Default: data/raw",
    )
    parser.add_argument(
        "--products",
        type=int,
        default=DEFAULT_PRODUCT_COUNT,
        help=f"Number of products. Default: {DEFAULT_PRODUCT_COUNT}",
    )
    parser.add_argument(
        "--reviews",
        type=int,
        default=DEFAULT_REVIEW_COUNT,
        help=f"Number of review summaries. Default: {DEFAULT_REVIEW_COUNT}",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=DEFAULT_SEED,
        help=f"Random seed for deterministic output. Default: {DEFAULT_SEED}",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing generated CSV files.",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print the generation summary as JSON.",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        summary = generate_sample_data(
            args.output_dir,
            product_count=args.products,
            review_count=args.reviews,
            seed=args.seed,
            force=args.force,
        )
    except (ValueError, OSError, csv.Error) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    if args.json:
        print(json.dumps(summary.as_dict(), indent=2, ensure_ascii=False))
    else:
        print("CatalogueIQ sample data generated successfully.")
        print(f"Product catalogue: {summary.product_file} ({summary.product_count} rows)")
        print(f"Review summaries: {summary.review_file} ({summary.review_count} rows)")
        print(f"Categories: {summary.category_counts}")
        print(f"Seed: {summary.seed}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
