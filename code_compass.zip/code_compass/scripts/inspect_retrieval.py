#!/usr/bin/env python3
"""Inspect CatalogueIQ retrieval results from LanceDB.

This command-line utility helps developers test retrieval before connecting the
LLM. It prints query expansion, extracted constraints, LanceDB pre-filters,
ranked evidence, citations, and the retrieval trace.

Examples::

    python scripts/inspect_retrieval.py --query "best earbuds under 2000"
    python scripts/inspect_retrieval.py --query "Can I return a sale item?" --persona shopper
    python scripts/inspect_retrieval.py --query "Electronics image requirements" --search-type fts
    python scripts/inspect_retrieval.py --query "best TWS with ANC" --json
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Any, Mapping, Sequence

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from catalogueiq.embeddings import EmbeddingConfig, create_embedding_provider
from catalogueiq.lancedb_store import LanceDBConfig, LanceDBStore
from catalogueiq.retriever import CatalogueRetriever, RetrieverConfig

DEFAULT_LANCEDB_URI = PROJECT_ROOT / "storage" / "lancedb"
DEFAULT_TABLE_NAME = "knowledge_chunks"
DEFAULT_EMBEDDING_MODEL = "all-MiniLM-L6-v2"


def inspect_retrieval(
    query: str,
    *,
    lancedb_uri: str | Path = DEFAULT_LANCEDB_URI,
    table_name: str = DEFAULT_TABLE_NAME,
    search_type: str = "vector",
    provider: str = "sentence_transformers",
    model: str | None = None,
    dimensions: int | None = None,
    normalize_embeddings: bool = True,
    persona: str | None = None,
    limit: int | None = None,
    max_variants: int = 4,
    candidate_multiplier: int = 3,
    device: str | None = None,
    known_brands: Sequence[str] = (),
) -> dict[str, Any]:
    """Run retrieval and return a JSON-serializable inspection report."""
    if not query or not query.strip():
        raise ValueError("query must be a non-empty string")
    if search_type not in {"vector", "fts", "hybrid"}:
        raise ValueError("search_type must be vector, fts, or hybrid")

    embedding_provider = None
    selected_model = model or (
        "text-embedding-3-small" if provider == "openai" else DEFAULT_EMBEDDING_MODEL
    )
    if search_type in {"vector", "hybrid"}:
        embedding_provider = create_embedding_provider(
            EmbeddingConfig(
                provider=provider,
                model=selected_model,
                dimensions=dimensions,
                normalize=normalize_embeddings,
                cache_enabled=False,
                device=device,
                show_progress=False,
            )
        )

    store = LanceDBStore(
        LanceDBConfig(
            uri=str(lancedb_uri),
            table_name=table_name,
            distance_type="cosine",
        )
    )
    if not store.table_exists():
        raise FileNotFoundError(
            f"LanceDB table {table_name!r} does not exist at {lancedb_uri}. "
            "Run: python scripts/ingest.py"
        )

    retriever = CatalogueRetriever(
        store=store,
        embedding_provider=embedding_provider,
        config=RetrieverConfig(
            search_type=search_type,
            max_query_variants=max_variants,
            candidate_multiplier=candidate_multiplier,
            source_diversity=True,
            strict_product_constraints=True,
            fallback_without_filters=False,
        ),
        known_brands=known_brands,
    )
    response = retriever.retrieve(
        query.strip(),
        persona=persona,
        limit=limit,
        search_type=search_type,
    )

    result_rows = []
    for rank, result in enumerate(response.results, start=1):
        metadata = result.metadata
        result_rows.append(
            {
                "rank": rank,
                "id": result.id,
                "citation": result.citation(),
                "source": metadata.get("source"),
                "source_type": metadata.get("source_type"),
                "section": metadata.get("section"),
                "product_id": metadata.get("product_id"),
                "product_name": metadata.get("product_name") or _extract_line(result.text, "Name"),
                "brand": metadata.get("brand"),
                "category": metadata.get("category"),
                "subcategory": metadata.get("subcategory"),
                "price_inr": metadata.get("price_inr"),
                "rating": metadata.get("rating"),
                "distance": result.distance,
                "score": result.score,
                "relevance_score": result.relevance_score,
                "text": result.text,
            }
        )

    return {
        "query": query.strip(),
        "search_type": search_type,
        "embedding_provider": provider if embedding_provider else None,
        "embedding_model": selected_model if embedding_provider else None,
        "lancedb_uri": str(lancedb_uri),
        "table_name": table_name,
        "table_row_count": store.count(),
        "expanded_query": response.expanded_query.as_dict(),
        "filter_plan": response.filter_plan.as_dict(),
        "result_count": len(result_rows),
        "result_source_types": dict(
            sorted(Counter(str(row["source_type"]) for row in result_rows).items())
        ),
        "results": result_rows,
        "citations": response.citations,
        "context": response.context(max_characters=12000),
        "trace": response.trace.as_dict(),
    }


def print_report(report: Mapping[str, Any], *, show_full_text: bool = False) -> None:
    """Print a readable retrieval inspection report."""
    expanded = report["expanded_query"]
    plan = report["filter_plan"]
    trace = report["trace"]

    print("=" * 80)
    print("CATALOGUEIQ RETRIEVAL INSPECTION")
    print("=" * 80)
    print(f"Query: {report['query']}")
    print(f"Search type: {report['search_type']}")
    print(f"Persona: {expanded['persona']}")
    print(f"Query type: {expanded['query_type']}")
    print(f"LanceDB table: {report['table_name']} ({report['table_row_count']} rows)")
    if report.get("embedding_model"):
        print(
            f"Embedding: {report['embedding_provider']} / "
            f"{report['embedding_model']}"
        )

    print("\nQUERY VARIANTS")
    for index, variant in enumerate(expanded["all_queries"], start=1):
        print(f"  {index}. {variant}")

    print("\nEXTRACTED CONSTRAINTS")
    constraints = expanded.get("constraints", {})
    if constraints:
        for key, value in constraints.items():
            print(f"  {key}: {value}")
    else:
        print("  None")

    print("\nFILTER PLAN")
    print(f"  LanceDB pre-filter: {plan.get('pre_filter_sql') or 'None'}")
    print(f"  Retrieval limit: {plan['retrieval_limit']}")
    print(f"  Candidate limit: {plan['candidate_limit']}")
    print(
        "  Preferred sources: "
        + (", ".join(plan["preferred_source_types"]) or "Any")
    )
    for note in plan.get("notes", []):
        print(f"  Note: {note}")

    print(f"\nRESULTS ({report['result_count']})")
    if not report["results"]:
        print("  No eligible results found.")
    for row in report["results"]:
        print("-" * 80)
        label = row.get("product_name") or row.get("section") or row.get("source")
        print(f"#{row['rank']} {label or row['id']}")
        print(f"Citation: {row['citation']}")
        details = []
        for key, display in (
            ("product_id", "Product ID"),
            ("brand", "Brand"),
            ("category", "Category"),
            ("subcategory", "Subcategory"),
            ("price_inr", "Price INR"),
            ("rating", "Rating"),
            ("distance", "Distance"),
            ("score", "Score"),
            ("relevance_score", "RRF score"),
        ):
            if row.get(key) not in (None, ""):
                value = row[key]
                if isinstance(value, float):
                    value = f"{value:.6f}"
                details.append(f"{display}: {value}")
        if details:
            print(" | ".join(details))
        text = row["text"] if show_full_text else _truncate(row["text"], 600)
        print("Text:")
        print(_indent(text, "  "))

    print("\nTRACE")
    for key in (
        "searches_executed",
        "raw_result_count",
        "fused_result_count",
        "accepted_result_count",
        "rejected_result_count",
        "fallback_used",
    ):
        print(f"  {key}: {trace.get(key)}")
    if trace.get("errors"):
        print("  Errors:")
        for error in trace["errors"]:
            print(f"    - {error}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Inspect CatalogueIQ retrieval results before LLM generation."
    )
    parser.add_argument("--query", "-q", required=True, help="User query to inspect")
    parser.add_argument(
        "--search-type",
        choices=("vector", "fts", "hybrid"),
        default="vector",
    )
    parser.add_argument(
        "--persona",
        choices=("shopper", "seller", "support_agent"),
        default=None,
    )
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--max-variants", type=int, default=4)
    parser.add_argument("--candidate-multiplier", type=int, default=3)
    parser.add_argument("--lancedb-uri", type=Path, default=DEFAULT_LANCEDB_URI)
    parser.add_argument("--table-name", default=DEFAULT_TABLE_NAME)
    parser.add_argument(
        "--provider",
        choices=("sentence_transformers", "openai"),
        default="sentence_transformers",
    )
    parser.add_argument("--model", default=None)
    parser.add_argument("--dimensions", type=int, default=None)
    parser.add_argument("--device", default=None)
    parser.add_argument("--no-normalize", action="store_true")
    parser.add_argument(
        "--known-brand",
        action="append",
        default=[],
        help="Known brand for inclusion and exclusion detection. Repeatable.",
    )
    parser.add_argument("--full-text", action="store_true")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--output", type=Path, default=None)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        report = inspect_retrieval(
            args.query,
            lancedb_uri=args.lancedb_uri,
            table_name=args.table_name,
            search_type=args.search_type,
            provider=args.provider,
            model=args.model,
            dimensions=args.dimensions,
            normalize_embeddings=not args.no_normalize,
            persona=args.persona,
            limit=args.limit,
            max_variants=args.max_variants,
            candidate_multiplier=args.candidate_multiplier,
            device=args.device,
            known_brands=args.known_brand,
        )
    except Exception as exc:
        print(f"Retrieval inspection failed: {exc}", file=sys.stderr)
        return 1

    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(
            json.dumps(report, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print_report(report, show_full_text=args.full_text)
        if args.output:
            print(f"\nJSON report written to: {args.output}")
    return 0


def _extract_line(text: str, label: str) -> str | None:
    prefix = label.casefold() + ":"
    for line in text.splitlines():
        if line.strip().casefold().startswith(prefix):
            return line.split(":", 1)[1].strip()
    return None


def _truncate(text: str, limit: int) -> str:
    cleaned = text.strip()
    if len(cleaned) <= limit:
        return cleaned
    return cleaned[: limit - 3].rstrip() + "..."


def _indent(text: str, prefix: str) -> str:
    return "\n".join(prefix + line for line in text.splitlines())


if __name__ == "__main__":
    raise SystemExit(main())
