"""Unit tests for :mod:`catalogueiq.query_expansion`.

The tests validate query normalization, e-commerce synonym expansion,
constraint extraction, persona detection, query classification, deterministic
rewrites, optional callback expansion, and duplicate removal.

Run from the project root with::

    pytest tests/test_query_expansion.py -v
"""

from __future__ import annotations

import pytest

from catalogueiq.query_expansion import (
    DEFAULT_SYNONYMS,
    ExpandedQuery,
    QueryConstraints,
    QueryExpansionError,
    classify_query,
    detect_persona,
    expand_queries,
    expand_query,
    extract_constraints,
    normalize_query,
)


def test_normalize_query_trims_and_collapses_whitespace() -> None:
    assert normalize_query("  best   earbuds   today  ") == "best earbuds today"


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("earbuds under Rs 2000", "earbuds under ₹2000"),
        ("earbuds below Rs. 2,000", "earbuds below ₹2,000"),
        ("earbuds under INR 3000", "earbuds under ₹3000"),
        ("earbuds below ₹ 2500", "earbuds below ₹2500"),
    ],
)
def test_normalize_query_normalizes_indian_currency(raw: str, expected: str) -> None:
    assert normalize_query(raw) == expected


@pytest.mark.parametrize("value", ["", "   ", None, 123])
def test_normalize_query_rejects_invalid_input(value) -> None:
    with pytest.raises(QueryExpansionError, match="non-empty string"):
        normalize_query(value)  # type: ignore[arg-type]


def test_extract_electronics_constraints() -> None:
    constraints = extract_constraints(
        "best earphones under Rs 2000 with ANC and at least 20 hours battery"
    )

    assert constraints.category == "Electronics"
    assert constraints.subcategory == "Wireless Earbuds"
    assert constraints.max_price == 2000
    assert constraints.min_battery_hours == 20
    assert constraints.anc_required is True


def test_extract_k_notation_budget() -> None:
    constraints = extract_constraints("smartwatch below ₹3k")

    assert constraints.category == "Electronics"
    assert constraints.subcategory == "Smartwatch"
    assert constraints.max_price == 3000


def test_return_window_is_not_misclassified_as_price() -> None:
    constraints = extract_constraints(
        "Can I return a Fashion item within 30 days?"
    )

    assert constraints.category == "Fashion"
    assert constraints.return_window_days == 30
    assert constraints.max_price is None


def test_extract_minimum_price_with_currency() -> None:
    constraints = extract_constraints("smartwatch above ₹2000")

    assert constraints.min_price == 2000


def test_extract_rating_from_rating_phrase() -> None:
    constraints = extract_constraints("earbuds rating at least 4.3")

    assert constraints.min_rating == pytest.approx(4.3)


def test_extract_rating_from_star_phrase() -> None:
    constraints = extract_constraints("show 4.5 star headphones")

    assert constraints.min_rating == pytest.approx(4.5)


def test_invalid_rating_is_not_extracted() -> None:
    constraints = extract_constraints("show products rated 7 stars")

    assert constraints.min_rating is None


@pytest.mark.parametrize(
    ("query", "expected"),
    [
        ("battery life at least 24 hours", 24.0),
        ("30 hrs battery", 30.0),
        ("battery life of 42 hours", 42.0),
    ],
)
def test_extract_battery_life(query: str, expected: float) -> None:
    assert extract_constraints(query).min_battery_hours == expected


@pytest.mark.parametrize(
    ("query", "expected"),
    [
        ("women's kurti in size M", "M"),
        ("sneakers size uk 6", "6"),
        ("jacket size XXL", "XXL"),
        ("shoe size UK 7.5", "7.5"),
    ],
)
def test_extract_size(query: str, expected: str) -> None:
    assert extract_constraints(query).size == expected


def test_extract_anc_false() -> None:
    constraints = extract_constraints("wireless earbuds without ANC")

    assert constraints.anc_required is False


def test_extract_verified_seller_and_stock() -> None:
    constraints = extract_constraints(
        "earbuds from verified sellers that are in stock"
    )

    assert constraints.verified_seller_required is True
    assert constraints.in_stock_required is True


def test_extract_known_brand() -> None:
    constraints = extract_constraints(
        "Show Auralite earbuds",
        known_brands=["Auralite", "NovaTech"],
    )

    assert constraints.brand == "Auralite"


def test_extract_excluded_brand_and_do_not_select_it() -> None:
    constraints = extract_constraints(
        "Exclude boAt and show wireless earbuds below ₹3000",
        known_brands=["boAt", "Auralite"],
    )

    assert constraints.excluded_brands == ["Boat"]
    assert constraints.brand is None
    assert constraints.max_price == 3000


def test_query_constraints_as_dict_omits_missing_values() -> None:
    constraints = QueryConstraints(
        category="Electronics",
        max_price=3000,
        excluded_brands=["Boat"],
    )

    assert constraints.as_dict() == {
        "category": "Electronics",
        "max_price": 3000,
        "excluded_brands": ["Boat"],
    }


@pytest.mark.parametrize(
    ("query", "expected"),
    [
        ("What are the image requirements for a listing?", "seller"),
        ("How do I complete seller onboarding?", "seller"),
        ("The refund is delayed, how should I escalate?", "support_agent"),
        ("Show me wireless earbuds", "shopper"),
    ],
)
def test_detect_persona_from_query(query: str, expected: str) -> None:
    assert detect_persona(query) == expected


@pytest.mark.parametrize(
    ("requested", "expected"),
    [
        ("shopper", "shopper"),
        ("seller", "seller"),
        ("support", "support_agent"),
        ("Support Agent", "support_agent"),
    ],
)
def test_detect_persona_honors_supported_override(
    requested: str,
    expected: str,
) -> None:
    assert detect_persona("generic query", requested) == expected


def test_detect_persona_rejects_invalid_override() -> None:
    with pytest.raises(QueryExpansionError, match="unsupported persona"):
        detect_persona("query", "administrator")


@pytest.mark.parametrize(
    ("query", "expected"),
    [
        ("What is the battery life of P0101?", "product_factual_lookup"),
        ("Can I return this Fashion item?", "policy_eligibility"),
        (
            "Which earbuds under ₹3000 have ANC?",
            "comparative_recommendation",
        ),
        (
            "What are the image requirements for an Electronics listing?",
            "seller_policy_lookup",
        ),
        (
            "The product stopped working after the return window. What are my warranty options?",
            "multi_hop",
        ),
    ],
)
def test_classify_query(query: str, expected: str) -> None:
    assert classify_query(query) == expected


def test_expand_query_produces_original_and_multiple_variants() -> None:
    expanded = expand_query("best earphones under ₹2000 with ANC")

    assert expanded.original == "best earphones under ₹2000 with ANC"
    assert len(expanded.variants) == 4
    assert expanded.all_queries[0] == expanded.original
    assert any("earbuds" in variant for variant in expanded.variants)
    assert any("TWS" in variant for variant in expanded.variants)
    assert expanded.detected_terms == ["earphones", "anc"]
    assert expanded.query_type == "comparative_recommendation"
    assert expanded.persona == "shopper"


def test_expand_query_preserves_budget_and_battery_constraints() -> None:
    expanded = expand_query(
        "best earphones under ₹2000 with ANC and at least 20 hours battery"
    )

    for variant in expanded.variants:
        assert "₹2000" in variant
        assert "20 hours" in variant
        assert "ANC" in variant or "active noise cancellation" in variant


def test_expand_query_uses_retrieval_rewrites_without_synonym() -> None:
    expanded = expand_query("The product stopped working after the return window. What are my warranty options?")

    assert len(expanded.variants) >= 2
    assert any("return window warranty seller responsibility" in item for item in expanded.variants)
    assert expanded.query_type == "multi_hop"


def test_expand_query_removes_duplicates_case_insensitively() -> None:
    expanded = expand_query(
        "show earbuds",
        synonyms={"earbuds": ("TWS", "tws", "TWS")},
    )

    assert len(expanded.all_queries) == len(
        {query.casefold() for query in expanded.all_queries}
    )


def test_expand_query_respects_max_variants() -> None:
    expanded = expand_query(
        "best earbuds under ₹3000",
        max_variants=2,
    )

    assert len(expanded.variants) == 2
    assert len(expanded.all_queries) == 3


def test_expand_query_rejects_too_few_max_variants() -> None:
    with pytest.raises(QueryExpansionError, match="at least 2"):
        expand_query("show earbuds", max_variants=1)


def test_expand_query_accepts_custom_synonyms() -> None:
    expanded = expand_query(
        "show notebook computers",
        synonyms={"notebook computers": ("laptops", "portable computers")},
    )

    assert expanded.variants[0] == "show laptops"
    assert expanded.variants[1] == "show portable computers"


def test_expand_query_adds_callback_variants() -> None:
    def callback(query: str, constraints: QueryConstraints) -> list[str]:
        assert query == "show earbuds under ₹3000"
        assert constraints.max_price == 3000
        return ["custom catalogue retrieval under ₹3000"]

    expanded = expand_query(
        "show earbuds under ₹3000",
        max_variants=6,
        rewrite_callback=callback,
    )

    assert "custom catalogue retrieval under ₹3000" in expanded.variants


def test_expand_query_wraps_callback_failure() -> None:
    def callback(query: str, constraints: QueryConstraints) -> list[str]:
        raise RuntimeError("offline")

    with pytest.raises(QueryExpansionError, match="rewrite callback failed"):
        expand_query("show earbuds", rewrite_callback=callback)


def test_expanded_query_as_dict() -> None:
    expanded = ExpandedQuery(
        original="show earbuds",
        variants=["show TWS", "show wireless earphones"],
        constraints=QueryConstraints(category="Electronics"),
        persona="shopper",
        query_type="product_factual_lookup",
        detected_terms=["earbuds"],
    )

    payload = expanded.as_dict()

    assert payload["original"] == "show earbuds"
    assert payload["all_queries"] == [
        "show earbuds",
        "show TWS",
        "show wireless earphones",
    ]
    assert payload["constraints"] == {"category": "Electronics"}
    assert payload["detected_terms"] == ["earbuds"]


def test_expand_queries_processes_multiple_queries() -> None:
    expanded = expand_queries(
        ["show earbuds", "Can I return a Fashion item?"],
        max_variants=2,
    )

    assert len(expanded) == 2
    assert expanded[0].constraints.category == "Electronics"
    assert expanded[1].constraints.category == "Fashion"
    assert expanded[1].query_type == "policy_eligibility"


def test_default_synonym_dictionary_contains_core_catalogue_terms() -> None:
    for term in (
        "earphones",
        "tws",
        "noise cancellation",
        "power bank",
        "kurti",
        "trainers",
        "refund",
    ):
        assert term in DEFAULT_SYNONYMS


def test_query_expansion_is_deterministic() -> None:
    query = "best wireless earphones under ₹3000 with ANC"

    first = expand_query(query).as_dict()
    second = expand_query(query).as_dict()

    assert first == second
