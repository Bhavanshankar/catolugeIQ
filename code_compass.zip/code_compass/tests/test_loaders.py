"""Unit tests for :mod:`catalogueiq.loaders`.

The tests use temporary files and do not depend on the full CatalogueIQ sample
dataset. Run them from the project root with::

    pytest tests/test_loaders.py -v
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from catalogueiq.loaders import (
    Document,
    LoaderError,
    discover_files,
    group_by_source_type,
    load_csv,
    load_documents,
    load_file,
    load_html,
    load_json,
    load_markdown,
)


@pytest.fixture()
def product_csv(tmp_path: Path) -> Path:
    path = tmp_path / "product_catalog.csv"
    path.write_text(
        "product_id,name,category,price_inr,rating,seller_verified,stock_quantity,specifications_json\n"
        'P0001,Auralite Earbuds,Electronics,1999,4.4,true,25,"{""anc"": true, ""battery_life_hours"": 30}"\n'
        'P0002,UrbanWeave Kurta,Fashion,1299,4.2,false,0,"{""size"": ""M"", ""material"": ""Cotton""}"\n',
        encoding="utf-8-sig",
    )
    return path


@pytest.fixture()
def review_csv(tmp_path: Path) -> Path:
    path = tmp_path / "product_review_summaries.csv"
    path.write_text(
        "review_summary_id,product_id,category,average_rating,review_summary\n"
        "RS0001,P0001,Electronics,4.4,Customers appreciate the battery life.\n",
        encoding="utf-8-sig",
    )
    return path


@pytest.fixture()
def policy_markdown(tmp_path: Path) -> Path:
    path = tmp_path / "returns_refunds_policy.md"
    path.write_text(
        "# ShopSmart India Returns Policy\n\n"
        "**Document ID:** SSI-POL-RR-001  \n\n"
        "## Electronics\n\nEligible Electronics products have a seven-day return window.\n",
        encoding="utf-8",
    )
    return path


@pytest.fixture()
def seller_markdown(tmp_path: Path) -> Path:
    path = tmp_path / "seller_onboarding.md"
    path.write_text(
        "# Seller Onboarding\n\n**Document ID:** SSI-SELLER-ONB-001  \n\n"
        "## Images\n\nUse a clear primary image.\n",
        encoding="utf-8",
    )
    return path


@pytest.fixture()
def category_markdown(tmp_path: Path) -> Path:
    path = tmp_path / "category_electronics.md"
    path.write_text(
        "# Electronics Category Guide\n\n"
        "**Document ID:** SSI-CAT-ELEC-001  \n\n"
        "## Wireless Earbuds\n\nStore ANC as a Boolean value.\n",
        encoding="utf-8",
    )
    return path


@pytest.fixture()
def buyer_faq(tmp_path: Path) -> Path:
    path = tmp_path / "buyer_faq.html"
    path.write_text(
        """<!doctype html>
<html><head><style>.hidden { display:none; }</style><script>ignored()</script></head>
<body>
<section class="faq-section" id="returns">
  <details class="faq-item" id="faq-01" data-category="Returns">
    <summary><span class="faq-number">01</span> How do I return an item?</summary>
    <div class="answer">
      <p>Open My Orders and choose Return or Replace.</p>
      <p class="citation">[Source: buyer_faq.html | Section: Returns | FAQ: 01]</p>
    </div>
  </details>
  <details class="faq-item" id="faq-02" data-category="Refunds">
    <summary><span class="faq-number">02</span> How long does a refund take?</summary>
    <div class="answer"><p>The timeline depends on the payment method.</p></div>
  </details>
</section>
</body></html>""",
        encoding="utf-8",
    )
    return path


def test_document_source_and_as_dict() -> None:
    document = Document("Example", {"source": "example.md", "category": "Books"})

    assert document.source == "example.md"
    assert document.as_dict() == {
        "text": "Example",
        "metadata": {"source": "example.md", "category": "Books"},
    }


def test_document_source_defaults_to_unknown() -> None:
    assert Document("Example").source == "unknown"


def test_load_product_csv_creates_one_document_per_row(product_csv: Path) -> None:
    documents = load_csv(product_csv)

    assert len(documents) == 2
    first = documents[0]
    assert first.metadata["source"] == "product_catalog.csv"
    assert first.metadata["source_type"] == "catalogue"
    assert first.metadata["chunk_type"] == "product"
    assert first.metadata["row_number"] == 2
    assert first.metadata["product_id"] == "P0001"
    assert first.metadata["price_inr"] == 1999
    assert isinstance(first.metadata["price_inr"], int)
    assert first.metadata["rating"] == pytest.approx(4.4)
    assert first.metadata["seller_verified"] is True
    assert first.metadata["specifications_json"] == {
        "anc": True,
        "battery_life_hours": 30,
    }
    assert "Product Id: P0001" in first.text
    assert "Price Inr: 1999" in first.text
    assert len(first.metadata["content_hash"]) == 64


def test_load_review_csv_detects_review_summary(review_csv: Path) -> None:
    document = load_csv(review_csv)[0]

    assert document.metadata["source_type"] == "review_summary"
    assert document.metadata["chunk_type"] == "review"
    assert document.metadata["review_summary_id"] == "RS0001"
    assert document.metadata["product_id"] == "P0001"


def test_csv_identifier_with_leading_zero_remains_string(tmp_path: Path) -> None:
    path = tmp_path / "codes.csv"
    path.write_text("code,value\n0012,12\n", encoding="utf-8")

    document = load_csv(path)[0]

    assert document.metadata["code"] == "0012"
    assert document.metadata["value"] == 12


def test_empty_csv_header_raises_loader_error(tmp_path: Path) -> None:
    path = tmp_path / "empty.csv"
    path.write_text("", encoding="utf-8")

    with pytest.raises(LoaderError, match="CSV has no header"):
        load_csv(path)


def test_load_policy_markdown_extracts_title_and_document_id(
    policy_markdown: Path,
) -> None:
    documents = load_markdown(policy_markdown)

    assert len(documents) == 1
    document = documents[0]
    assert document.metadata["source_type"] == "policy"
    assert document.metadata["chunk_type"] == "policy"
    assert document.metadata["title"] == "ShopSmart India Returns Policy"
    assert document.metadata["document_id"] == "SSI-POL-RR-001"
    assert "## Electronics" in document.text
    assert len(document.metadata["content_hash"]) == 64


def test_load_seller_markdown_detects_seller_guide(seller_markdown: Path) -> None:
    document = load_markdown(seller_markdown)[0]

    assert document.metadata["source_type"] == "seller_guide"
    assert document.metadata["document_id"] == "SSI-SELLER-ONB-001"


def test_load_category_markdown_sets_category(category_markdown: Path) -> None:
    document = load_markdown(category_markdown)[0]

    assert document.metadata["source_type"] == "category_guide"
    assert document.metadata["category"] == "Electronics"
    assert document.metadata["document_id"] == "SSI-CAT-ELEC-001"


def test_empty_markdown_returns_no_documents(tmp_path: Path) -> None:
    path = tmp_path / "empty.md"
    path.write_text("   \n", encoding="utf-8")

    assert load_markdown(path) == []


def test_load_buyer_faq_creates_one_document_per_faq(buyer_faq: Path) -> None:
    documents = load_html(buyer_faq)

    assert len(documents) == 2
    first = documents[0]
    assert first.metadata["source_type"] == "faq"
    assert first.metadata["chunk_type"] == "faq"
    assert first.metadata["faq_id"] == "01"
    assert first.metadata["section"] == "Returns"
    assert first.metadata["question"] == "How do I return an item?"
    assert first.text.startswith("Question: How do I return an item?")
    assert "Answer: Open My Orders and choose Return or Replace." in first.text
    assert "[Source:" not in first.text
    assert "ignored()" not in first.text


def test_generic_html_falls_back_to_clean_text(tmp_path: Path) -> None:
    path = tmp_path / "page.html"
    path.write_text(
        "<html><head><style>hidden</style></head><body><h1>Title</h1>"
        "<p>First paragraph.</p><script>ignored()</script></body></html>",
        encoding="utf-8",
    )

    documents = load_html(path)

    assert len(documents) == 1
    assert documents[0].metadata["source_type"] == "html"
    assert "Title" in documents[0].text
    assert "First paragraph." in documents[0].text
    assert "hidden" not in documents[0].text
    assert "ignored()" not in documents[0].text


def test_load_json_manifest(tmp_path: Path) -> None:
    path = tmp_path / "ingestion_manifest.json"
    path.write_text(json.dumps({"manifest": {"id": "test"}}), encoding="utf-8")

    document = load_json(path)[0]

    assert document.metadata["source_type"] == "manifest"
    assert '"id": "test"' in document.text
    assert len(document.metadata["content_hash"]) == 64


def test_invalid_json_raises_loader_error(tmp_path: Path) -> None:
    path = tmp_path / "broken.json"
    path.write_text("{not-json}", encoding="utf-8")

    with pytest.raises(LoaderError, match="Unable to load JSON"):
        load_json(path)


def test_load_file_dispatches_by_extension(
    product_csv: Path,
    policy_markdown: Path,
    buyer_faq: Path,
) -> None:
    assert len(load_file(product_csv)) == 2
    assert len(load_file(policy_markdown)) == 1
    assert len(load_file(buyer_faq)) == 2


def test_load_file_rejects_missing_and_unsupported_files(tmp_path: Path) -> None:
    with pytest.raises(LoaderError, match="does not exist"):
        load_file(tmp_path / "missing.csv")

    unsupported = tmp_path / "notes.txt"
    unsupported.write_text("text", encoding="utf-8")
    with pytest.raises(LoaderError, match="Unsupported file type"):
        load_file(unsupported)


def test_discover_files_excludes_json_by_default(
    tmp_path: Path,
    product_csv: Path,
) -> None:
    markdown = tmp_path / "guide.md"
    markdown.write_text("# Guide", encoding="utf-8")
    manifest = tmp_path / "manifest.json"
    manifest.write_text("{}", encoding="utf-8")
    text = tmp_path / "ignored.txt"
    text.write_text("ignore", encoding="utf-8")

    discovered = discover_files(tmp_path)
    names = [path.name for path in discovered]

    assert "product_catalog.csv" in names
    assert "guide.md" in names
    assert "manifest.json" not in names
    assert "ignored.txt" not in names


def test_discover_files_can_include_json_and_recurse(tmp_path: Path) -> None:
    nested = tmp_path / "nested"
    nested.mkdir()
    (nested / "manifest.json").write_text("{}", encoding="utf-8")
    (nested / "guide.md").write_text("# Guide", encoding="utf-8")

    shallow = discover_files(tmp_path, include_json=True)
    recursive = discover_files(tmp_path, recursive=True, include_json=True)

    assert shallow == []
    assert {path.name for path in recursive} == {"guide.md", "manifest.json"}


def test_discover_files_deduplicates_paths(product_csv: Path) -> None:
    discovered = discover_files([product_csv, product_csv.parent])

    matching = [path for path in discovered if path.name == product_csv.name]
    assert len(matching) == 1


def test_discover_files_rejects_unsupported_explicit_file(tmp_path: Path) -> None:
    path = tmp_path / "notes.txt"
    path.write_text("text", encoding="utf-8")

    with pytest.raises(LoaderError, match="Unsupported source file"):
        discover_files(path)


def test_load_documents_loads_mixed_sources_and_groups_them(
    product_csv: Path,
    review_csv: Path,
    policy_markdown: Path,
    buyer_faq: Path,
) -> None:
    documents = load_documents(
        [product_csv, review_csv, policy_markdown, buyer_faq]
    )
    grouped = group_by_source_type(documents)

    assert len(documents) == 6
    assert len(grouped["catalogue"]) == 2
    assert len(grouped["review_summary"]) == 1
    assert len(grouped["policy"]) == 1
    assert len(grouped["faq"]) == 2


def test_load_documents_includes_json_only_when_requested(tmp_path: Path) -> None:
    manifest = tmp_path / "ingestion_manifest.json"
    manifest.write_text("{}", encoding="utf-8")

    assert load_documents(tmp_path) == []
    documents = load_documents(tmp_path, include_json=True)

    assert len(documents) == 1
    assert documents[0].metadata["source_type"] == "manifest"


def test_group_by_source_type_uses_unknown_default() -> None:
    grouped = group_by_source_type([Document("example", {})])

    assert list(grouped) == ["unknown"]
    assert grouped["unknown"][0].text == "example"
