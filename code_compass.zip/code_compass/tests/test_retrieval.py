"""Unit tests for CatalogueIQ filtering and retrieval orchestration.

The suite uses deterministic fake embedding providers and fake LanceDB stores,
so it does not require a model download, network access, or a real vector
database. Run from the project root with::

    pytest tests/test_retrieval.py -v
"""

from __future__ import annotations

from typing import Sequence

import pytest

from catalogueiq.embeddings import EmbeddingProvider
from catalogueiq.filters import (
    FilterError,
    apply_post_filters,
    build_filter_plan,
    evaluate_metadata,
    filter_results,
    filters_for_source,
)
from catalogueiq.lancedb_store import SearchFilters, SearchResult
from catalogueiq.query_expansion import QueryConstraints, expand_query
from catalogueiq.retriever import (
    CatalogueRetriever,
    RetrievalError,
    RetrieverConfig,
    diversify_results,
    format_context,
    reciprocal_rank_fusion,
    result_key,
)


class FakeEmbeddingProvider(EmbeddingProvider):
    provider_name = "fake"
    model_name = "fake-4d"
    dimensions = 4
    normalize = True

    def __init__(self) -> None:
        self.queries: list[str] = []

    def embed_texts(self, texts: Sequence[str]) -> list[list[float]]:
        self.queries.extend(texts)
        return [[1.0, 0.0, 0.0, 0.0] for _ in texts]


class FakeStore:
    def __init__(self, results: Sequence[SearchResult] | None = None) -> None:
        self.results = list(results or [])
        self.vector_calls: list[dict] = []
        self.text_calls: list[dict] = []
        self.hybrid_calls: list[dict] = []

    def vector_search(self, vector, *, limit, filters=None):
        self.vector_calls.append({"vector": vector, "limit": limit, "filters": filters})
        return self.results[:limit]

    def text_search(self, query, *, limit, filters=None):
        self.text_calls.append({"query": query, "limit": limit, "filters": filters})
        return self.results[:limit]

    def hybrid_search(self, query, vector, *, limit, filters=None):
        self.hybrid_calls.append(
            {"query": query, "vector": vector, "limit": limit, "filters": filters}
        )
        return self.results[:limit]


def product_result(
    result_id: str,
    product_id: str,
    *,
    price: int = 1999,
    rating: float = 4.4,
    anc: bool = True,
    battery: int = 30,
    brand: str = "Auralite",
    seller_verified: bool = True,
    availability: str = "In Stock",
) -> SearchResult:
    return SearchResult(
        id=result_id,
        text=(
            f"Product Id: {product_id}\n"
            f"Name: {brand} Wireless Earbuds\n"
            f"Price Inr: {price}\n"
            f"Rating: {rating}\n"
            f"Battery Life Hours: {battery}\n"
            f"ANC: {anc}"
        ),
        metadata={
            "source": "product_catalog.csv",
            "source_type": "catalogue",
            "chunk_type": "product",
            "product_id": product_id,
            "product_name": f"{brand} Wireless Earbuds",
            "brand": brand,
            "category": "Electronics",
            "subcategory": "Wireless Earbuds",
            "price_inr": price,
            "rating": rating,
            "seller_verified": seller_verified,
            "availability": availability,
            "specifications_json": {
                "anc": anc,
                "battery_life_hours": battery,
            },
        },
    )


def policy_result(result_id: str = "policy-1") -> SearchResult:
    return SearchResult(
        id=result_id,
        text="Eligible Electronics products have a seven-day return window.",
        metadata={
            "source": "returns_refunds_policy.md",
            "source_type": "policy",
            "chunk_type": "policy",
            "section": "Electronics",
        },
    )


def faq_result(result_id: str = "faq-1") -> SearchResult:
    return SearchResult(
        id=result_id,
        text="Open My Orders and choose Return or Replace.",
        metadata={
            "source": "buyer_faq.html",
            "source_type": "faq",
            "chunk_type": "faq",
            "section": "Returns",
            "faq_id": "25",
        },
    )


def seller_result(result_id: str = "seller-1") -> SearchResult:
    return SearchResult(
        id=result_id,
        text="Use a clear primary image with a white background.",
        metadata={
            "source": "seller_onboarding.md",
            "source_type": "seller_guide",
            "chunk_type": "seller_guide",
            "section": "Product Images",
        },
    )


def test_search_filters_build_expected_sql() -> None:
    filters = SearchFilters(
        category="Electronics",
        subcategory="Wireless Earbuds",
        source_type="catalogue",
        max_price=3000,
        min_rating=4.0,
        seller_verified=True,
        availability="In Stock",
    )

    assert filters.to_sql() == (
        "category = 'Electronics' AND subcategory = 'Wireless Earbuds' "
        "AND source_type = 'catalogue' AND availability = 'In Stock' "
        "AND price_inr <= 3000.0 AND rating >= 4.0 "
        "AND seller_verified = TRUE"
    )


def test_search_filters_escape_single_quotes() -> None:
    filters = SearchFilters(brand="Kid's Choice")

    assert filters.to_sql() == "brand = 'Kid''s Choice'"


def test_build_product_filter_plan_uses_catalogue_prefilter() -> None:
    expanded = expand_query(
        "best earbuds under ₹3000 with ANC and at least 20 hours battery "
        "from verified sellers"
    )

    plan = build_filter_plan(expanded)

    assert plan.query_type == "comparative_recommendation"
    assert plan.pre_filters.source_type == "catalogue"
    assert plan.pre_filters.category == "Electronics"
    assert plan.pre_filters.subcategory == "Wireless Earbuds"
    assert plan.pre_filters.max_price == 3000
    assert plan.pre_filters.seller_verified is True
    assert plan.retrieval_limit == 12
    assert plan.candidate_limit == 36
    assert any("ANC" in note for note in plan.notes)
    assert any("Battery life" in note for note in plan.notes)


def test_build_policy_plan_does_not_apply_product_price_filter() -> None:
    expanded = expand_query("Can I return a Fashion item within 30 days?")

    plan = build_filter_plan(expanded)

    assert plan.query_type == "policy_eligibility"
    assert plan.pre_filters.category is None
    assert plan.pre_filters.max_price is None
    assert plan.pre_filters.source_type is None
    assert plan.preferred_source_types == ("policy", "faq", "category_guide")
    assert "Category retained" in " ".join(plan.notes)


def test_build_filter_plan_rejects_invalid_values() -> None:
    constraints = QueryConstraints(category="Electronics")

    with pytest.raises(FilterError, match="candidate_multiplier"):
        build_filter_plan(constraints, candidate_multiplier=0)
    with pytest.raises(FilterError, match="retrieval_limit"):
        build_filter_plan(constraints, retrieval_limit=-1)


def test_filters_for_source_returns_copy() -> None:
    plan = build_filter_plan(expand_query("Can I return an Electronics item?"))

    filters = filters_for_source(plan, "faq")

    assert filters.source_type == "faq"
    assert plan.pre_filters.source_type is None


def test_filters_for_source_rejects_empty_value() -> None:
    plan = build_filter_plan(expand_query("Can I return an item?"))

    with pytest.raises(FilterError, match="source_type"):
        filters_for_source(plan, "   ")


def test_evaluate_metadata_accepts_matching_product() -> None:
    constraints = expand_query(
        "earbuds under ₹3000 with ANC and at least 20 hours battery "
        "from verified sellers"
    ).constraints

    decision = evaluate_metadata(product_result("1", "P1").metadata, constraints)

    assert decision.accepted is True
    assert decision.reasons == []
    assert "ANC=True" in decision.matched_constraints
    assert "battery life=30 hours" in decision.matched_constraints


def test_evaluate_metadata_rejects_multiple_constraint_failures() -> None:
    constraints = expand_query(
        "best earbuds under ₹3000 with ANC and at least 20 hours battery "
        "from verified sellers"
    ).constraints
    metadata = product_result(
        "2",
        "P2",
        price=3499,
        anc=False,
        battery=18,
        seller_verified=False,
    ).metadata

    decision = evaluate_metadata(metadata, constraints)

    assert decision.accepted is False
    assert any("above maximum" in reason for reason in decision.reasons)
    assert any("ANC requirement not met" in reason for reason in decision.reasons)
    assert any("below 20 hours" in reason for reason in decision.reasons)
    assert any("not verified" in reason for reason in decision.reasons)


def test_evaluate_metadata_supports_json_string_specifications() -> None:
    constraints = QueryConstraints(anc_required=True, min_battery_hours=24)
    metadata = {
        "specifications_json": '{"anc": true, "battery_life_hours": 36}'
    }

    decision = evaluate_metadata(metadata, constraints)

    assert decision.accepted is True


def test_evaluate_metadata_strict_missing_controls_missing_attributes() -> None:
    constraints = QueryConstraints(anc_required=True, min_battery_hours=20)

    strict = evaluate_metadata({}, constraints, strict_missing=True)
    relaxed = evaluate_metadata({}, constraints, strict_missing=False)

    assert strict.accepted is False
    assert relaxed.accepted is True


def test_evaluate_metadata_applies_brand_exclusion_case_insensitively() -> None:
    constraints = QueryConstraints(excluded_brands=["Boat"])

    decision = evaluate_metadata({"brand": "boAt"}, constraints)

    assert decision.accepted is False
    assert "excluded" in decision.reasons[0]


def test_evaluate_metadata_validates_size() -> None:
    constraints = QueryConstraints(size="M")

    accepted = evaluate_metadata({"sizes": ["S", "M", "L"]}, constraints)
    rejected = evaluate_metadata({"sizes": "S,L,XL"}, constraints)

    assert accepted.accepted is True
    assert rejected.accepted is False


def test_apply_post_filters_preserves_input_objects() -> None:
    constraints = QueryConstraints(max_price=3000)
    first = product_result("1", "P1", price=1999)
    second = product_result("2", "P2", price=3999)

    accepted = apply_post_filters([first, second], constraints)

    assert accepted == [first]
    assert accepted[0] is first


def test_apply_post_filters_honors_limit() -> None:
    constraints = QueryConstraints(max_price=3000)
    results = [product_result(str(i), f"P{i}", price=1999) for i in range(4)]

    accepted = apply_post_filters(results, constraints, limit=2)

    assert len(accepted) == 2


def test_apply_post_filters_rejects_invalid_limit() -> None:
    with pytest.raises(FilterError, match="limit"):
        apply_post_filters([], QueryConstraints(), limit=0)


def test_filter_results_returns_rejection_audit() -> None:
    expanded = expand_query("best earbuds under ₹3000 with ANC")
    plan = build_filter_plan(expanded, retrieval_limit=5)
    good = product_result("1", "P1", price=1999, anc=True)
    bad = product_result("2", "P2", price=3999, anc=False)

    accepted, audit = filter_results([good, bad], plan)

    assert accepted == [good]
    assert audit["retrieved"] == 2
    assert audit["accepted"] == 1
    assert audit["rejected"] == 1
    assert audit["rejections"][0]["product_id"] == "P2"


def test_filter_results_does_not_product_filter_policy_evidence() -> None:
    expanded = expand_query("Can I return an Electronics item?")
    plan = build_filter_plan(expanded)
    policy = policy_result()

    accepted, audit = filter_results([policy], plan)

    assert accepted == [policy]
    assert audit["rejected"] == 0


def test_retriever_config_validation() -> None:
    with pytest.raises(ValueError, match="search_type"):
        RetrieverConfig(search_type="semantic")
    with pytest.raises(ValueError, match="max_query_variants"):
        RetrieverConfig(max_query_variants=1)
    with pytest.raises(ValueError, match="candidate_multiplier"):
        RetrieverConfig(candidate_multiplier=0)
    with pytest.raises(ValueError, match="rrf_k"):
        RetrieverConfig(rrf_k=0)


def test_vector_retriever_requires_embedding_provider() -> None:
    with pytest.raises(RetrievalError, match="embedding_provider"):
        CatalogueRetriever(FakeStore(), None, config=RetrieverConfig(search_type="vector"))


def test_fts_retriever_does_not_require_embedding_provider() -> None:
    retriever = CatalogueRetriever(
        FakeStore([policy_result()]),
        None,
        config=RetrieverConfig(search_type="fts", max_query_variants=2),
    )

    response = retriever.retrieve("Can I return an Electronics item?")

    assert response.results


def test_vector_retrieval_expands_queries_and_filters_results() -> None:
    good = product_result("good", "P1", price=1999, anc=True, battery=30)
    bad = product_result("bad", "P2", price=3499, anc=False, battery=18)
    store = FakeStore([good, bad])
    provider = FakeEmbeddingProvider()
    retriever = CatalogueRetriever(
        store,
        provider,
        config=RetrieverConfig(search_type="vector", max_query_variants=3),
    )

    response = retriever.retrieve(
        "best earbuds under ₹3000 with ANC and at least 20 hours battery",
        limit=5,
    )

    assert [result.id for result in response.results] == ["good"]
    assert response.trace.searches_executed == 4
    assert response.trace.raw_result_count == 8
    assert response.trace.fused_result_count == 2
    assert response.trace.rejected_result_count == 1
    assert len(store.vector_calls) == 4
    assert len(provider.queries) == 4
    assert all(call["filters"].source_type == "catalogue" for call in store.vector_calls)


def test_fts_retrieval_executes_source_specific_policy_searches() -> None:
    store = FakeStore([policy_result(), faq_result(), seller_result()])
    retriever = CatalogueRetriever(
        store,
        None,
        config=RetrieverConfig(search_type="fts", max_query_variants=2),
    )

    response = retriever.retrieve("Can I return an Electronics item?")

    assert response.trace.searches_executed == 9
    assert len(store.text_calls) == 9
    source_types = {call["filters"].source_type for call in store.text_calls}
    assert source_types == {"policy", "faq", "category_guide"}


def test_hybrid_retrieval_calls_hybrid_store_method() -> None:
    store = FakeStore([product_result("1", "P1")])
    provider = FakeEmbeddingProvider()
    retriever = CatalogueRetriever(
        store,
        provider,
        config=RetrieverConfig(search_type="hybrid", max_query_variants=2),
    )

    response = retriever.retrieve("show earbuds")

    assert response.results
    assert len(store.hybrid_calls) == 3
    assert store.vector_calls == []
    assert store.text_calls == []


def test_retrieve_rejects_unsupported_runtime_search_type() -> None:
    retriever = CatalogueRetriever(
        FakeStore(),
        FakeEmbeddingProvider(),
        config=RetrieverConfig(search_type="vector"),
    )

    with pytest.raises(RetrievalError, match="unsupported search type"):
        retriever.retrieve("show earbuds", search_type="semantic")


def test_retrieval_trace_collects_store_errors() -> None:
    class BrokenStore(FakeStore):
        def vector_search(self, vector, *, limit, filters=None):
            raise RuntimeError("database unavailable")

    retriever = CatalogueRetriever(
        BrokenStore(),
        FakeEmbeddingProvider(),
        config=RetrieverConfig(search_type="vector", max_query_variants=2),
    )

    response = retriever.retrieve("show earbuds")

    assert response.results == []
    assert response.trace.errors
    assert "database unavailable" in response.trace.errors[0]


def test_fallback_without_filters_is_used_when_filtered_results_empty() -> None:
    class FallbackStore(FakeStore):
        def vector_search(self, vector, *, limit, filters=None):
            self.vector_calls.append({"vector": vector, "limit": limit, "filters": filters})
            if filters is None:
                return [product_result("fallback", "P9", price=9999)]
            return []

    store = FallbackStore()
    retriever = CatalogueRetriever(
        store,
        FakeEmbeddingProvider(),
        config=RetrieverConfig(
            search_type="vector",
            max_query_variants=2,
            fallback_without_filters=True,
        ),
    )

    response = retriever.retrieve("show earbuds under ₹1000")

    assert [result.id for result in response.results] == ["fallback"]
    assert response.trace.fallback_used is True
    assert store.vector_calls[-1]["filters"] is None


def test_reciprocal_rank_fusion_promotes_repeated_result() -> None:
    first = product_result("a", "P1")
    repeated = product_result("b", "P2")
    third = product_result("c", "P3")

    fused = reciprocal_rank_fusion(
        [[first, repeated], [repeated, third]],
        rrf_k=60,
    )

    assert fused[0].id == "b"
    assert fused[0].relevance_score > fused[1].relevance_score


def test_reciprocal_rank_fusion_ignores_duplicate_within_same_list() -> None:
    result = product_result("a", "P1")

    fused = reciprocal_rank_fusion([[result, result]], rrf_k=60)

    assert len(fused) == 1
    assert fused[0].relevance_score == pytest.approx(1 / 61)


def test_reciprocal_rank_fusion_rejects_invalid_k() -> None:
    with pytest.raises(RetrievalError, match="rrf_k"):
        reciprocal_rank_fusion([], rrf_k=0)


def test_diversify_results_selects_preferred_source_types() -> None:
    results = [policy_result(), faq_result(), seller_result()]

    diversified = diversify_results(
        results,
        limit=2,
        preferred_source_types=("faq", "policy"),
    )

    assert [result.metadata["source_type"] for result in diversified] == [
        "faq",
        "policy",
    ]


def test_diversify_results_rejects_invalid_limit() -> None:
    with pytest.raises(RetrievalError, match="limit"):
        diversify_results([], limit=0)


def test_result_key_precedence() -> None:
    with_id = product_result("chunk-1", "P1")
    without_id = product_result("", "P2")
    without_product = policy_result("")

    assert result_key(with_id) == "id:chunk-1"
    assert result_key(without_id) == "product:P2"
    assert result_key(without_product).startswith("source:returns_refunds_policy.md")


def test_format_context_includes_citations() -> None:
    results = [product_result("1", "P1"), policy_result()]

    context = format_context(results)

    assert "[Evidence 1]" in context
    assert "[Source: product_catalog.csv | Product ID: P1]" in context
    assert "[Evidence 2]" in context
    assert "[Source: returns_refunds_policy.md | Section: Electronics]" in context


def test_format_context_honors_character_limit_after_first_block() -> None:
    results = [product_result("1", "P1"), product_result("2", "P2")]

    context = format_context(results, max_characters=50)

    assert "[Evidence 1]" in context
    assert "[Evidence 2]" not in context


def test_retrieval_response_serialization_and_citations() -> None:
    retriever = CatalogueRetriever(
        FakeStore([product_result("1", "P1")]),
        FakeEmbeddingProvider(),
        config=RetrieverConfig(search_type="vector", max_query_variants=2),
    )

    response = retriever.retrieve("show earbuds")
    payload = response.as_dict()

    assert response.citations == [
        "[Source: product_catalog.csv | Product ID: P1]"
    ]
    assert payload["results"][0]["id"] == "1"
    assert payload["results"][0]["citation"] == response.citations[0]
    assert payload["trace"]["accepted_result_count"] == 1
