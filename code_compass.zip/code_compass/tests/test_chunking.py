"""Unit tests for :mod:`catalogueiq.chunking`.

The tests use small in-memory documents and temporary Markdown content. They
verify natural-entity chunking, recursive and fixed splitting, heading-aware
Markdown handling, stable identifiers, metadata preservation, validation, and
strategy comparison.

Run from the project root with::

    pytest tests/test_chunking.py -v
"""

from __future__ import annotations

import pytest

from catalogueiq.chunking import (
    Chunk,
    ChunkingError,
    chunk_document,
    chunk_documents,
    chunk_generic_document,
    chunk_markdown_document,
    chunk_natural_document,
    compare_chunking_strategies,
    fixed_size_split,
    iter_chunks,
    recursive_text_split,
    validate_chunks,
)
from catalogueiq.loaders import Document


def product_document(product_id: str = "P0001") -> Document:
    return Document(
        text=(
            f"Product Id: {product_id}\n"
            "Name: Auralite Wireless Earbuds\n"
            "Category: Electronics\n"
            "Subcategory: Wireless Earbuds\n"
            "Price Inr: 1999"
        ),
        metadata={
            "source": "product_catalog.csv",
            "source_type": "catalogue",
            "chunk_type": "product",
            "product_id": product_id,
            "category": "Electronics",
            "subcategory": "Wireless Earbuds",
            "price_inr": 1999,
        },
    )


def review_document() -> Document:
    return Document(
        text="Review Summary Id: RS0001\nProduct Id: P0001\nPositive themes: battery life",
        metadata={
            "source": "product_review_summaries.csv",
            "source_type": "review_summary",
            "chunk_type": "review",
            "review_summary_id": "RS0001",
            "product_id": "P0001",
        },
    )


def faq_document() -> Document:
    return Document(
        text="Question: How do I return an item?\nAnswer: Open My Orders and choose Return.",
        metadata={
            "source": "buyer_faq.html",
            "source_type": "faq",
            "chunk_type": "faq",
            "faq_id": "01",
            "section": "Returns",
        },
    )


def markdown_document() -> Document:
    long_paragraph = " ".join(
        f"Sentence {index} explains the Electronics return requirement."
        for index in range(1, 35)
    )
    text = (
        "# ShopSmart India Policy\n\n"
        "Introduction to the policy.\n\n"
        "## Electronics\n\n"
        f"{long_paragraph}\n\n"
        "### Exceptions\n\n"
        "Damaged items require supporting evidence.\n\n"
        "## Fashion\n\n"
        "Eligible Fashion items retain original tags."
    )
    return Document(
        text=text,
        metadata={
            "source": "returns_refunds_policy.md",
            "source_type": "policy",
            "chunk_type": "policy",
            "document_id": "SSI-POL-RR-001",
        },
    )


def test_recursive_text_split_returns_empty_for_blank_text() -> None:
    assert recursive_text_split("   \n\t") == []


def test_recursive_text_split_keeps_short_text_intact() -> None:
    text = "A short paragraph that does not need splitting."

    assert recursive_text_split(text, chunk_size=100, chunk_overlap=10) == [text]


def test_recursive_text_split_respects_maximum_size() -> None:
    text = " ".join(f"word{index}" for index in range(300))

    chunks = recursive_text_split(text, chunk_size=120, chunk_overlap=20)

    assert len(chunks) > 1
    assert all(chunk for chunk in chunks)
    assert all(len(chunk) <= 120 for chunk in chunks)


def test_recursive_text_split_preserves_overlap_context() -> None:
    text = "Alpha beta gamma delta epsilon zeta eta theta iota kappa lambda mu. " * 8

    chunks = recursive_text_split(text, chunk_size=100, chunk_overlap=20)

    assert len(chunks) > 2
    for previous, current in zip(chunks, chunks[1:]):
        previous_words = set(previous.split()[-5:])
        current_words = set(current.split()[:8])
        assert previous_words.intersection(current_words)


@pytest.mark.parametrize(
    ("chunk_size", "chunk_overlap", "message"),
    [
        (0, 0, "chunk_size"),
        (-1, 0, "chunk_size"),
        (100, -1, "chunk_overlap"),
        (100, 100, "smaller"),
        (100, 101, "smaller"),
    ],
)
def test_recursive_text_split_rejects_invalid_configuration(
    chunk_size: int,
    chunk_overlap: int,
    message: str,
) -> None:
    with pytest.raises(ChunkingError, match=message):
        recursive_text_split(
            "Example text",
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
        )


def test_fixed_size_split_uses_fixed_offsets() -> None:
    text = "abcdefghijklmnopqrstuvwxyz"

    chunks = fixed_size_split(text, chunk_size=10, chunk_overlap=2)

    assert chunks == ["abcdefghij", "ijklmnopqr", "qrstuvwxyz", "yz"]


def test_natural_product_document_remains_one_chunk() -> None:
    document = product_document()

    chunks = chunk_natural_document(document)

    assert len(chunks) == 1
    chunk = chunks[0]
    assert chunk.text == document.text
    assert chunk.metadata["chunking_strategy"] == "natural_entity"
    assert chunk.metadata["chunk_index"] == 0
    assert chunk.metadata["product_id"] == "P0001"
    assert chunk.metadata["price_inr"] == 1999
    assert chunk.id.startswith("chk-")
    assert len(chunk.metadata["content_hash"]) == 64


def test_empty_natural_document_returns_no_chunks() -> None:
    document = Document(
        "   ",
        {"source": "product_catalog.csv", "chunk_type": "product"},
    )

    assert chunk_natural_document(document) == []


@pytest.mark.parametrize("document_factory", [product_document, review_document, faq_document])
def test_chunk_document_routes_natural_entities(document_factory) -> None:
    chunks = chunk_document(document_factory())

    assert len(chunks) == 1
    assert chunks[0].metadata["chunking_strategy"] == "natural_entity"


def test_heading_aware_markdown_preserves_heading_path() -> None:
    chunks = chunk_markdown_document(
        markdown_document(),
        chunk_size=260,
        chunk_overlap=40,
    )

    sections = [chunk.metadata["section"] for chunk in chunks]
    assert "ShopSmart India Policy" in sections
    assert any(section == "ShopSmart India Policy > Electronics" for section in sections)
    assert any(
        section == "ShopSmart India Policy > Electronics > Exceptions"
        for section in sections
    )
    assert any(section == "ShopSmart India Policy > Fashion" for section in sections)
    assert all(chunk.metadata["chunking_strategy"] == "heading_aware_recursive" for chunk in chunks)
    assert all(len(chunk.text) <= 260 for chunk in chunks)


def test_markdown_section_chunk_metadata_is_consistent() -> None:
    chunks = chunk_markdown_document(
        markdown_document(),
        chunk_size=220,
        chunk_overlap=30,
    )
    electronics = [
        chunk
        for chunk in chunks
        if chunk.metadata["section"] == "ShopSmart India Policy > Electronics"
    ]

    assert len(electronics) > 1
    expected_count = len(electronics)
    assert [chunk.metadata["section_chunk_index"] for chunk in electronics] == list(
        range(expected_count)
    )
    assert all(
        chunk.metadata["section_chunk_count"] == expected_count
        for chunk in electronics
    )


def test_markdown_parser_ignores_headings_inside_code_fence() -> None:
    document = Document(
        "# Guide\n\n```text\n## Not A Heading\nvalue\n```\n\n## Real Section\nContent.",
        {
            "source": "category_electronics.md",
            "source_type": "category_guide",
            "chunk_type": "category_guide",
        },
    )

    chunks = chunk_markdown_document(document, chunk_size=300, chunk_overlap=20)
    sections = [chunk.metadata["section"] for chunk in chunks]

    assert "Guide > Not A Heading" not in sections
    assert "Guide > Real Section" in sections
    assert any("## Not A Heading" in chunk.text for chunk in chunks)


def test_chunk_document_routes_markdown_by_extension() -> None:
    document = Document(
        "# Guide\n\n## Section\n\nUseful content.",
        {"source": "guide.md", "chunk_type": "document"},
    )

    chunks = chunk_document(document, chunk_size=100, chunk_overlap=10)

    assert all(chunk.metadata["chunking_strategy"] == "heading_aware_recursive" for chunk in chunks)


def test_chunk_document_routes_policy_without_markdown_extension() -> None:
    document = Document(
        "# Policy\n\n## Rule\n\nUseful content.",
        {"source": "policy.txt", "chunk_type": "policy"},
    )

    chunks = chunk_document(document, chunk_size=100, chunk_overlap=10)

    assert all(chunk.metadata["chunking_strategy"] == "heading_aware_recursive" for chunk in chunks)


def test_generic_recursive_chunking() -> None:
    document = Document(
        "Generic content. " * 80,
        {"source": "document.json", "chunk_type": "document"},
    )

    chunks = chunk_generic_document(
        document,
        chunk_size=150,
        chunk_overlap=25,
        strategy="recursive",
    )

    assert len(chunks) > 1
    assert all(chunk.metadata["chunking_strategy"] == "recursive_character" for chunk in chunks)
    assert all(len(chunk.text) <= 150 for chunk in chunks)


def test_generic_fixed_chunking() -> None:
    document = Document(
        "0123456789" * 15,
        {"source": "document.json", "chunk_type": "document"},
    )

    chunks = chunk_generic_document(
        document,
        chunk_size=50,
        chunk_overlap=10,
        strategy="fixed",
    )

    assert len(chunks) == 4
    assert all(chunk.metadata["chunking_strategy"] == "fixed_character" for chunk in chunks)


def test_generic_chunking_rejects_unknown_strategy() -> None:
    document = Document("Example", {"source": "document.json"})

    with pytest.raises(ChunkingError, match="Unsupported generic"):
        chunk_generic_document(document, strategy="semantic")


def test_chunk_documents_assigns_source_indexes() -> None:
    documents = [product_document("P0001"), product_document("P0002"), faq_document()]

    chunks = chunk_documents(documents)

    product_chunks = [
        chunk for chunk in chunks if chunk.metadata["source"] == "product_catalog.csv"
    ]
    faq_chunks = [chunk for chunk in chunks if chunk.metadata["source"] == "buyer_faq.html"]
    assert [chunk.metadata["source_chunk_index"] for chunk in product_chunks] == [0, 1]
    assert [chunk.metadata["source_chunk_index"] for chunk in faq_chunks] == [0]


def test_chunk_ids_are_stable_for_same_input() -> None:
    document = product_document()

    first = chunk_document(document)[0]
    second = chunk_document(document)[0]

    assert first.id == second.id
    assert first.metadata["content_hash"] == second.metadata["content_hash"]


def test_chunk_ids_change_when_content_changes() -> None:
    first_document = product_document()
    second_document = product_document()
    second_document.text += "\nWarranty Months: 12"

    first = chunk_document(first_document)[0]
    second = chunk_document(second_document)[0]

    assert first.id != second.id
    assert first.metadata["content_hash"] != second.metadata["content_hash"]


def test_iter_chunks_matches_chunk_document_results() -> None:
    documents = [product_document(), faq_document(), markdown_document()]

    lazy = list(iter_chunks(documents, chunk_size=300, chunk_overlap=40))
    eager = [
        chunk
        for document in documents
        for chunk in chunk_document(document, chunk_size=300, chunk_overlap=40)
    ]

    assert [chunk.id for chunk in lazy] == [chunk.id for chunk in eager]


def test_compare_chunking_strategies_returns_metrics() -> None:
    comparison = compare_chunking_strategies(
        markdown_document(),
        chunk_size=220,
        chunk_overlap=30,
    )

    assert set(comparison) == {"fixed", "source_aware"}
    assert comparison["fixed"]["chunk_count"] > 0
    assert comparison["source_aware"]["chunk_count"] > 0
    assert comparison["fixed"]["sections_preserved"] == 0
    assert comparison["source_aware"]["sections_preserved"] > 0
    assert comparison["fixed"]["maximum_characters"] <= 220
    assert comparison["source_aware"]["maximum_characters"] <= 220


def test_validate_chunks_accepts_valid_collection() -> None:
    chunks = chunk_documents([product_document(), faq_document(), markdown_document()])

    report = validate_chunks(chunks)

    assert report["valid"] is True
    assert report["chunk_count"] == len(chunks)
    assert report["unique_id_count"] == len(chunks)
    assert report["duplicate_ids"] == []
    assert report["empty_chunk_indexes"] == []
    assert report["missing_source_indexes"] == []


def test_validate_chunks_reports_duplicates_empty_text_and_missing_source() -> None:
    chunks = [
        Chunk("Valid", {"id": "same", "source": "source.md"}),
        Chunk("", {"id": "same", "source": "source.md"}),
        Chunk("No source", {"id": "third"}),
    ]

    report = validate_chunks(chunks)

    assert report["valid"] is False
    assert report["duplicate_ids"] == ["same"]
    assert report["empty_chunk_indexes"] == [1]
    assert report["missing_source_indexes"] == [2]


def test_chunk_as_dict_returns_copy_of_metadata() -> None:
    chunk = Chunk("Example", {"id": "chunk-1", "source": "example.md"})

    payload = chunk.as_dict()
    payload["metadata"]["source"] = "changed.md"

    assert chunk.metadata["source"] == "example.md"
    assert chunk.id == "chunk-1"


def test_validate_chunks_handles_empty_collection() -> None:
    report = validate_chunks([])

    assert report == {
        "valid": True,
        "chunk_count": 0,
        "unique_id_count": 0,
        "duplicate_ids": [],
        "empty_chunk_indexes": [],
        "missing_source_indexes": [],
    }
