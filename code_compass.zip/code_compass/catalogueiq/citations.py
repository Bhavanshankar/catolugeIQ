"""Citation utilities for CatalogueIQ.

This module creates, extracts, validates, deduplicates, and formats citation
markers for product catalogue records, review summaries, policies, seller
guides, category guides, and buyer FAQs.

Citation markers use this project format::

    [Source: product_catalog.csv | Product ID: P0101]
    [Source: returns_refunds_policy.md | Section: Electronics]
    [Source: buyer_faq.html | Section: Refunds | FAQ: 33]

Only citations that correspond to retrieved evidence should be included in a
final answer.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping, Sequence

CITATION_PATTERN = re.compile(r"\[Source:\s*[^\]\r\n]+\]")
FIELD_PATTERN = re.compile(r"\s*([^|:]+?)\s*:\s*(.*?)\s*(?=\||$)")


class CitationError(ValueError):
    """Raised when citation data is invalid."""


@dataclass(frozen=True, slots=True)
class Citation:
    """Structured representation of one CatalogueIQ citation."""

    source: str
    product_id: str | None = None
    section: str | None = None
    faq_id: str | None = None
    review_summary_id: str | None = None
    document_id: str | None = None
    extra: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.source or not self.source.strip():
            raise CitationError("citation source cannot be empty")

    def marker(self) -> str:
        """Render the canonical citation marker."""
        fields: list[tuple[str, str]] = [("Source", self.source.strip())]
        if self.product_id:
            fields.append(("Product ID", str(self.product_id).strip()))
        elif self.faq_id:
            if self.section:
                fields.append(("Section", str(self.section).strip()))
            fields.append(("FAQ", str(self.faq_id).strip()))
        elif self.section:
            fields.append(("Section", str(self.section).strip()))
        elif self.review_summary_id:
            fields.append(("Review Summary ID", str(self.review_summary_id).strip()))
        elif self.document_id:
            fields.append(("Document ID", str(self.document_id).strip()))
        for key, value in self.extra.items():
            if value not in (None, ""):
                fields.append((str(key).strip(), str(value).strip()))
        return "[" + " | ".join(f"{key}: {value}" for key, value in fields) + "]"

    def as_dict(self) -> dict[str, Any]:
        return {
            "source": self.source,
            "product_id": self.product_id,
            "section": self.section,
            "faq_id": self.faq_id,
            "review_summary_id": self.review_summary_id,
            "document_id": self.document_id,
            "extra": dict(self.extra),
            "marker": self.marker(),
        }


@dataclass(slots=True)
class CitationValidationReport:
    """Result of comparing answer citations with retrieved evidence."""

    found: list[str]
    valid: list[str]
    invalid: list[str]
    available: list[str]
    missing_required: bool
    passed: bool

    def as_dict(self) -> dict[str, Any]:
        return {
            "found": list(self.found),
            "valid": list(self.valid),
            "invalid": list(self.invalid),
            "available": list(self.available),
            "missing_required": self.missing_required,
            "passed": self.passed,
        }


def citation_from_metadata(metadata: Mapping[str, Any]) -> Citation:
    """Create a citation using source-aware metadata precedence."""
    source = _clean(metadata.get("source"))
    if not source:
        raise CitationError("metadata does not contain a source")

    product_id = _clean(metadata.get("product_id"))
    faq_id = _clean(metadata.get("faq_id"))
    section = _clean(metadata.get("section"))
    review_id = _clean(metadata.get("review_summary_id"))
    document_id = _clean(metadata.get("document_id"))

    # Review summaries cite the product when possible so product and review
    # evidence can be joined clearly in generated answers.
    return Citation(
        source=source,
        product_id=product_id,
        section=section,
        faq_id=faq_id,
        review_summary_id=review_id,
        document_id=document_id,
    )


def citation_from_result(result: Any) -> Citation:
    """Create a citation from SearchResult, mapping, or metadata-bearing object."""
    if hasattr(result, "metadata"):
        metadata = getattr(result, "metadata")
    elif isinstance(result, Mapping) and isinstance(result.get("metadata"), Mapping):
        metadata = result["metadata"]
    elif isinstance(result, Mapping):
        metadata = result
    else:
        raise CitationError(f"cannot extract citation metadata from {type(result).__name__}")
    if not isinstance(metadata, Mapping):
        raise CitationError("result metadata must be a mapping")
    return citation_from_metadata(metadata)


def format_citation(metadata_or_result: Any) -> str:
    """Return one canonical citation marker."""
    if isinstance(metadata_or_result, Citation):
        return metadata_or_result.marker()
    if isinstance(metadata_or_result, Mapping) and "source" in metadata_or_result:
        return citation_from_metadata(metadata_or_result).marker()
    return citation_from_result(metadata_or_result).marker()


def parse_citation(marker: str) -> Citation:
    """Parse one CatalogueIQ citation marker."""
    if not isinstance(marker, str) or not marker.strip():
        raise CitationError("citation marker cannot be empty")
    value = marker.strip()
    if not (value.startswith("[") and value.endswith("]")):
        raise CitationError("citation marker must be enclosed in square brackets")
    inside = value[1:-1]
    fields: dict[str, str] = {}
    for part in inside.split("|"):
        match = FIELD_PATTERN.fullmatch(part.strip())
        if not match:
            raise CitationError(f"invalid citation field: {part!r}")
        fields[match.group(1).strip().casefold()] = match.group(2).strip()
    source = fields.pop("source", "")
    if not source:
        raise CitationError("citation marker does not contain Source")
    known = {
        "product id": "product_id",
        "section": "section",
        "faq": "faq_id",
        "review summary id": "review_summary_id",
        "document id": "document_id",
    }
    values: dict[str, str | None] = {
        "product_id": None,
        "section": None,
        "faq_id": None,
        "review_summary_id": None,
        "document_id": None,
    }
    extra: dict[str, str] = {}
    for key, item in fields.items():
        if key in known:
            values[known[key]] = item
        else:
            extra[key.title()] = item
    return Citation(source=source, extra=extra, **values)


def extract_citation_markers(text: str) -> list[str]:
    """Extract unique citation markers in first-appearance order."""
    if not text:
        return []
    return _unique(CITATION_PATTERN.findall(text))


def extract_citations(text: str, *, strict: bool = False) -> list[Citation]:
    """Extract and parse citations from text.

    When ``strict`` is false, malformed markers are skipped. When true, the
    first malformed marker raises ``CitationError``.
    """
    citations: list[Citation] = []
    for marker in extract_citation_markers(text):
        try:
            citations.append(parse_citation(marker))
        except CitationError:
            if strict:
                raise
    return citations


def available_citations(evidence: Iterable[Any]) -> list[str]:
    """Build unique canonical citations from retrieved evidence."""
    markers: list[str] = []
    for item in evidence:
        try:
            markers.append(format_citation(item))
        except CitationError:
            continue
    return _unique(markers)


def validate_citations(
    answer: str,
    evidence: Iterable[Any],
    *,
    require_at_least_one: bool = True,
) -> CitationValidationReport:
    """Validate answer markers against retrieved evidence citations."""
    found = extract_citation_markers(answer)
    available = available_citations(evidence)
    allowed = set(available)
    valid = [marker for marker in found if marker in allowed]
    invalid = [marker for marker in found if marker not in allowed]
    missing_required = require_at_least_one and not valid
    return CitationValidationReport(
        found=found,
        valid=valid,
        invalid=invalid,
        available=available,
        missing_required=missing_required,
        passed=not invalid and not missing_required,
    )


def append_citation(statement: str, citation: Citation | str) -> str:
    """Append one marker to a statement unless it is already present."""
    if not isinstance(statement, str) or not statement.strip():
        raise CitationError("statement cannot be empty")
    marker = citation.marker() if isinstance(citation, Citation) else parse_citation(citation).marker()
    cleaned = statement.strip()
    if marker in cleaned:
        return cleaned
    return f"{cleaned} {marker}"


def format_evidence_block(
    text: str,
    metadata_or_result: Any,
    *,
    evidence_number: int | None = None,
) -> str:
    """Format one retrieved chunk for inclusion in an LLM context."""
    if not isinstance(text, str) or not text.strip():
        raise CitationError("evidence text cannot be empty")
    marker = format_citation(metadata_or_result)
    prefix = f"[Evidence {evidence_number}] " if evidence_number is not None else ""
    return f"{prefix}{marker}\n{text.strip()}"


def format_evidence_context(
    evidence: Sequence[Any],
    *,
    max_characters: int | None = None,
) -> str:
    """Format retrieved results into citation-marked context blocks."""
    blocks: list[str] = []
    length = 0
    for index, item in enumerate(evidence, start=1):
        text = _result_text(item)
        if not text:
            continue
        block = format_evidence_block(text, item, evidence_number=index)
        if max_characters is not None and blocks and length + len(block) > max_characters:
            break
        blocks.append(block)
        length += len(block) + 2
    return "\n\n".join(blocks)


def citation_coverage(answer: str) -> dict[str, Any]:
    """Calculate lightweight sentence-level citation coverage.

    This is a formatting diagnostic, not a factual-faithfulness metric.
    Questions, headings, and the fixed insufficient-evidence response are
    ignored.
    """
    if not answer or not answer.strip():
        return {
            "claim_sentence_count": 0,
            "cited_sentence_count": 0,
            "coverage": 0.0,
        }
    sentences = re.split(r"(?<=[.!?])\s+|\n+", answer.strip())
    claims: list[str] = []
    for sentence in sentences:
        cleaned = sentence.strip(" -•\t")
        if not cleaned or cleaned.endswith(":") or cleaned.endswith("?"):
            continue
        if cleaned == (
            "I could not find enough information in the ShopSmart India "
            "knowledge base to answer that confidently."
        ):
            continue
        if re.search(r"[A-Za-z0-9]", cleaned):
            claims.append(cleaned)
    cited = sum(bool(CITATION_PATTERN.search(sentence)) for sentence in claims)
    return {
        "claim_sentence_count": len(claims),
        "cited_sentence_count": cited,
        "coverage": round(cited / len(claims), 4) if claims else 1.0,
    }


def remove_invalid_citations(answer: str, evidence: Iterable[Any]) -> str:
    """Remove citation markers that were not present in retrieved evidence."""
    allowed = set(available_citations(evidence))
    return CITATION_PATTERN.sub(
        lambda match: match.group(0) if match.group(0) in allowed else "",
        answer,
    ).replace("  ", " ").strip()


def _result_text(item: Any) -> str:
    if hasattr(item, "text"):
        return _clean(getattr(item, "text"))
    if isinstance(item, Mapping):
        return _clean(item.get("text"))
    return ""


def _clean(value: Any) -> str:
    return "" if value is None else str(value).strip()


def _unique(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    output: list[str] = []
    for value in values:
        if value not in seen:
            seen.add(value)
            output.append(value)
    return output


__all__ = [
    "CITATION_PATTERN",
    "Citation",
    "CitationError",
    "CitationValidationReport",
    "append_citation",
    "available_citations",
    "citation_coverage",
    "citation_from_metadata",
    "citation_from_result",
    "extract_citation_markers",
    "extract_citations",
    "format_citation",
    "format_evidence_block",
    "format_evidence_context",
    "parse_citation",
    "remove_invalid_citations",
    "validate_citations",
]
