"""CatalogueIQ package.

CatalogueIQ is a RAG-powered product intelligence assistant for the
fictional ShopSmart India marketplace. The package contains ingestion,
chunking, embedding, LanceDB storage, retrieval, prompting, memory,
citation, and RAG orchestration components.

The package deliberately avoids importing optional or heavyweight
modules at import time. This keeps ``import catalogueiq`` fast and lets
individual modules report their own missing optional dependencies.
"""

from __future__ import annotations

from typing import Final

__title__: Final[str] = "CatalogueIQ"
__description__: Final[str] = (
    "A RAG-powered product intelligence assistant for ShopSmart India."
)
__version__: Final[str] = "1.0.0"
__author__: Final[str] = "CatalogueIQ Project Team"
__company__: Final[str] = "ShopSmart India"

# Public package metadata exposed by wildcard imports.
__all__ = [
    "__title__",
    "__description__",
    "__version__",
    "__author__",
    "__company__",
    "get_version",
]


def get_version() -> str:
    """Return the installed CatalogueIQ package version."""
    return __version__
