"""High-level retrieval orchestration for CatalogueIQ.

The retriever joins query expansion, query classification, metadata filtering,
LanceDB vector or full-text search, reciprocal-rank fusion, deterministic
post-filtering, source diversification, and citation-ready context formatting.

The module is deliberately independent from generation. It returns retrieved
evidence and a detailed trace so the UI, RAG chain, and evaluation suite can
inspect exactly what the system retrieved.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping, Sequence

try:
    from .embeddings import EmbeddingProvider
    from .filters import FilterPlan, build_filter_plan, filter_results, filters_for_source
    from .lancedb_store import LanceDBStore, LanceDBStoreError, SearchFilters, SearchResult
    from .query_expansion import ExpandedQuery, expand_query
except ImportError:  # Supports direct module execution during development.
    from embeddings import EmbeddingProvider
    from filters import FilterPlan, build_filter_plan, filter_results, filters_for_source
    from lancedb_store import LanceDBStore, LanceDBStoreError, SearchFilters, SearchResult
    from query_expansion import ExpandedQuery, expand_query

DEFAULT_RRF_K = 60


class RetrievalError(RuntimeError):
    """Raised when a retrieval request cannot be completed."""


@dataclass(frozen=True, slots=True)
class RetrieverConfig:
    """Configurable retrieval behaviour."""

    search_type: str = "vector"
    max_query_variants: int = 4
    candidate_multiplier: int = 3
    rrf_k: int = DEFAULT_RRF_K
    source_diversity: bool = True
    include_original_query: bool = True
    strict_product_constraints: bool = True
    fallback_without_filters: bool = False

    def __post_init__(self) -> None:
        if self.search_type not in {"vector", "fts", "hybrid"}:
            raise ValueError("search_type must be vector, fts, or hybrid")
        if self.max_query_variants < 2:
            raise ValueError("max_query_variants must be at least 2")
        if self.candidate_multiplier <= 0:
            raise ValueError("candidate_multiplier must be greater than zero")
        if self.rrf_k <= 0:
            raise ValueError("rrf_k must be greater than zero")


@dataclass(slots=True)
class RetrievalTrace:
    """Inspectable execution trace for one retrieval request."""

    original_query: str
    query_type: str
    persona: str
    query_variants: list[str]
    pre_filter_sql: str | None
    preferred_source_types: list[str]
    search_type: str
    searches_executed: int = 0
    raw_result_count: int = 0
    fused_result_count: int = 0
    accepted_result_count: int = 0
    rejected_result_count: int = 0
    fallback_used: bool = False
    errors: list[str] = field(default_factory=list)
    filter_audit: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "original_query": self.original_query,
            "query_type": self.query_type,
            "persona": self.persona,
            "query_variants": list(self.query_variants),
            "pre_filter_sql": self.pre_filter_sql,
            "preferred_source_types": list(self.preferred_source_types),
            "search_type": self.search_type,
            "searches_executed": self.searches_executed,
            "raw_result_count": self.raw_result_count,
            "fused_result_count": self.fused_result_count,
            "accepted_result_count": self.accepted_result_count,
            "rejected_result_count": self.rejected_result_count,
            "fallback_used": self.fallback_used,
            "errors": list(self.errors),
            "filter_audit": dict(self.filter_audit),
        }


@dataclass(slots=True)
class RetrievalResponse:
    """Final evidence returned by the CatalogueIQ retriever."""

    expanded_query: ExpandedQuery
    filter_plan: FilterPlan
    results: list[SearchResult]
    trace: RetrievalTrace

    @property
    def citations(self) -> list[str]:
        return _unique(result.citation() for result in self.results)

    def context(self, *, max_characters: int | None = None) -> str:
        """Format retrieved records as grounded, citation-marked context."""
        blocks: list[str] = []
        current_length = 0
        for index, result in enumerate(self.results, start=1):
            block = f"[Evidence {index}] {result.citation()}\n{result.text.strip()}"
            if max_characters is not None and blocks and current_length + len(block) > max_characters:
                break
            blocks.append(block)
            current_length += len(block) + 2
        return "\n\n".join(blocks)

    def as_dict(self) -> dict[str, Any]:
        return {
            "expanded_query": self.expanded_query.as_dict(),
            "filter_plan": self.filter_plan.as_dict(),
            "results": [
                {
                    "id": result.id,
                    "text": result.text,
                    "metadata": result.metadata,
                    "distance": result.distance,
                    "score": result.score,
                    "relevance_score": result.relevance_score,
                    "citation": result.citation(),
                }
                for result in self.results
            ],
            "citations": self.citations,
            "trace": self.trace.as_dict(),
        }


class CatalogueRetriever:
    """Expansion-aware, filter-aware retriever over a LanceDB store."""

    def __init__(
        self,
        store: LanceDBStore,
        embedding_provider: EmbeddingProvider | None = None,
        *,
        config: RetrieverConfig | None = None,
        known_brands: Iterable[str] = (),
    ) -> None:
        self.store = store
        self.embedding_provider = embedding_provider
        self.config = config or RetrieverConfig()
        self.known_brands = tuple(known_brands)
        if self.config.search_type in {"vector", "hybrid"} and embedding_provider is None:
            raise RetrievalError(
                f"embedding_provider is required for {self.config.search_type} search"
            )

    def retrieve(
        self,
        query: str,
        *,
        persona: str | None = None,
        limit: int | None = None,
        search_type: str | None = None,
    ) -> RetrievalResponse:
        """Expand, search, fuse, filter, and return grounded evidence."""
        expanded = expand_query(
            query,
            max_variants=self.config.max_query_variants,
            persona=persona,
            known_brands=self.known_brands,
        )
        plan = build_filter_plan(
            expanded,
            retrieval_limit=limit,
            candidate_multiplier=self.config.candidate_multiplier,
            strict_product_constraints=self.config.strict_product_constraints,
        )
        mode = search_type or self.config.search_type
        if mode not in {"vector", "fts", "hybrid"}:
            raise RetrievalError(f"unsupported search type: {mode!r}")
        if mode in {"vector", "hybrid"} and self.embedding_provider is None:
            raise RetrievalError(f"embedding_provider is required for {mode} search")

        variants = expanded.all_queries if self.config.include_original_query else expanded.variants
        trace = RetrievalTrace(
            original_query=expanded.original,
            query_type=expanded.query_type,
            persona=expanded.persona,
            query_variants=list(variants),
            pre_filter_sql=plan.where,
            preferred_source_types=list(plan.preferred_source_types),
            search_type=mode,
        )

        ranked_lists: list[list[SearchResult]] = []
        source_types = self._search_source_types(plan)
        for variant in variants:
            for source_type in source_types:
                source_filters = (
                    filters_for_source(plan, source_type)
                    if source_type
                    else plan.pre_filters
                )
                try:
                    results = self._search_once(
                        variant,
                        mode=mode,
                        limit=plan.candidate_limit,
                        filters=source_filters,
                    )
                    trace.searches_executed += 1
                    trace.raw_result_count += len(results)
                    if results:
                        ranked_lists.append(results)
                except (LanceDBStoreError, Exception) as exc:
                    trace.errors.append(
                        f"query={variant!r}, source_type={source_type or 'any'}: {exc}"
                    )

        fused = reciprocal_rank_fusion(ranked_lists, rrf_k=self.config.rrf_k)
        trace.fused_result_count = len(fused)

        accepted, audit = filter_results(fused, plan)
        trace.filter_audit = audit
        trace.rejected_result_count = audit.get("rejected", 0)

        if not accepted and self.config.fallback_without_filters:
            fallback = self._fallback_search(expanded.original, mode, plan.retrieval_limit, trace)
            accepted = fallback
            trace.fallback_used = bool(fallback)

        if self.config.source_diversity and expanded.query_type not in {
            "product_factual_lookup",
            "comparative_recommendation",
        }:
            accepted = diversify_results(
                accepted,
                limit=plan.retrieval_limit,
                preferred_source_types=plan.preferred_source_types,
            )
        else:
            accepted = accepted[: plan.retrieval_limit]

        trace.accepted_result_count = len(accepted)
        return RetrievalResponse(expanded, plan, accepted, trace)

    def _search_source_types(self, plan: FilterPlan) -> tuple[str | None, ...]:
        # Product queries use the catalogue pre-filter before optional review
        # enrichment. Other query types search each preferred document type so
        # one large source cannot crowd out all other evidence.
        if plan.query_type in {"product_factual_lookup", "comparative_recommendation"}:
            return ("catalogue",)
        if plan.preferred_source_types:
            return tuple(plan.preferred_source_types)
        return (None,)

    def _search_once(
        self,
        query: str,
        *,
        mode: str,
        limit: int,
        filters: SearchFilters,
    ) -> list[SearchResult]:
        if mode == "fts":
            return self.store.text_search(query, limit=limit, filters=filters)
        assert self.embedding_provider is not None
        vector = self.embedding_provider.embed_query(query)
        if mode == "vector":
            return self.store.vector_search(vector, limit=limit, filters=filters)
        return self.store.hybrid_search(
            query,
            vector,
            limit=limit,
            filters=filters,
        )

    def _fallback_search(
        self,
        query: str,
        mode: str,
        limit: int,
        trace: RetrievalTrace,
    ) -> list[SearchResult]:
        try:
            trace.searches_executed += 1
            if mode == "fts":
                results = self.store.text_search(query, limit=limit)
            else:
                assert self.embedding_provider is not None
                vector = self.embedding_provider.embed_query(query)
                if mode == "vector":
                    results = self.store.vector_search(vector, limit=limit)
                else:
                    results = self.store.hybrid_search(query, vector, limit=limit)
            trace.raw_result_count += len(results)
            return results
        except Exception as exc:
            trace.errors.append(f"fallback: {exc}")
            return []


def reciprocal_rank_fusion(
    ranked_lists: Iterable[Sequence[SearchResult]],
    *,
    rrf_k: int = DEFAULT_RRF_K,
) -> list[SearchResult]:
    """Fuse rankings from query variants and source-specific searches.

    The score for a result is the sum of ``1 / (rrf_k + rank)`` across all
    result lists. Duplicate records are identified by chunk ID, then product
    ID, then source and text.
    """
    if rrf_k <= 0:
        raise RetrievalError("rrf_k must be greater than zero")
    scores: dict[str, float] = {}
    best: dict[str, SearchResult] = {}
    best_rank: dict[str, int] = {}

    for results in ranked_lists:
        seen_in_list: set[str] = set()
        for rank, result in enumerate(results, start=1):
            key = result_key(result)
            if key in seen_in_list:
                continue
            seen_in_list.add(key)
            scores[key] = scores.get(key, 0.0) + 1.0 / (rrf_k + rank)
            if key not in best or rank < best_rank[key]:
                best[key] = result
                best_rank[key] = rank

    ordered_keys = sorted(
        scores,
        key=lambda key: (-scores[key], best_rank[key], key),
    )
    fused: list[SearchResult] = []
    for key in ordered_keys:
        result = best[key]
        # Retain native LanceDB score fields while storing fusion score in
        # relevance_score for downstream ranking and inspection.
        result.relevance_score = scores[key]
        fused.append(result)
    return fused


def diversify_results(
    results: Sequence[SearchResult],
    *,
    limit: int,
    preferred_source_types: Sequence[str] = (),
) -> list[SearchResult]:
    """Select diverse evidence while preserving fused-ranking priority."""
    if limit <= 0:
        raise RetrievalError("limit must be greater than zero")
    if not results:
        return []

    output: list[SearchResult] = []
    selected: set[str] = set()
    preferences = list(preferred_source_types)

    # First pass takes the highest-ranked result from each preferred source.
    for source_type in preferences:
        for result in results:
            key = result_key(result)
            if key not in selected and result.metadata.get("source_type") == source_type:
                output.append(result)
                selected.add(key)
                break
        if len(output) >= limit:
            return output

    # Second pass fills remaining slots according to fused ranking.
    for result in results:
        key = result_key(result)
        if key not in selected:
            output.append(result)
            selected.add(key)
        if len(output) >= limit:
            break
    return output


def result_key(result: SearchResult) -> str:
    """Return a stable de-duplication key for a search result."""
    if result.id:
        return f"id:{result.id}"
    product_id = result.metadata.get("product_id")
    if product_id:
        return f"product:{product_id}"
    return f"source:{result.metadata.get('source', '')}|text:{result.text.strip()}"


def format_context(
    results: Sequence[SearchResult],
    *,
    max_characters: int | None = None,
) -> str:
    """Format search results without requiring a RetrievalResponse."""
    blocks: list[str] = []
    length = 0
    for index, result in enumerate(results, start=1):
        block = f"[Evidence {index}] {result.citation()}\n{result.text.strip()}"
        if max_characters is not None and blocks and length + len(block) > max_characters:
            break
        blocks.append(block)
        length += len(block) + 2
    return "\n\n".join(blocks)


def _unique(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    output: list[str] = []
    for value in values:
        if value not in seen:
            seen.add(value)
            output.append(value)
    return output


__all__ = [
    "CatalogueRetriever",
    "DEFAULT_RRF_K",
    "RetrievalError",
    "RetrievalResponse",
    "RetrievalTrace",
    "RetrieverConfig",
    "diversify_results",
    "format_context",
    "reciprocal_rank_fusion",
    "result_key",
]
