"""Document loaders for the CatalogueIQ ingestion pipeline.

The module loads ShopSmart India knowledge-base files without LangChain or
BeautifulSoup. It supports CSV, Markdown, HTML, and JSON manifest files using
only the Python standard library.

Typical usage::

    from catalogueiq.loaders import load_documents

    documents = load_documents("data/raw")
    for document in documents:
        print(document.source, document.metadata)

CSV files are loaded one row per document because each product or review
summary is a natural business entity. Markdown files are loaded as complete
source documents and are split later by the chunking module. Buyer FAQ HTML is
loaded one ``details.faq-item`` element per document.
"""

from __future__ import annotations

import csv
import hashlib
import json
import re
from dataclasses import dataclass, field
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Iterable, Iterator, Mapping, Sequence

SUPPORTED_EXTENSIONS = frozenset({".csv", ".md", ".markdown", ".html", ".htm", ".json"})


@dataclass(slots=True)
class Document:
    """A framework-independent source document.

    Attributes:
        text: Human-readable content that will later be chunked or embedded.
        metadata: Filterable source and business metadata.
    """

    text: str
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def source(self) -> str:
        """Return the source filename stored in metadata."""
        return str(self.metadata.get("source", "unknown"))

    def as_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable representation."""
        return {"text": self.text, "metadata": dict(self.metadata)}


class LoaderError(RuntimeError):
    """Raised when a supported source cannot be loaded safely."""


class _HTMLTextExtractor(HTMLParser):
    """Extract readable text while discarding scripts and styles."""

    BLOCK_TAGS = {
        "address", "article", "aside", "blockquote", "br", "div", "dl",
        "dt", "dd", "footer", "h1", "h2", "h3", "h4", "h5", "h6",
        "header", "hr", "li", "main", "nav", "ol", "p", "pre", "section",
        "summary", "table", "td", "th", "tr", "ul",
    }

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self._ignored_depth = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        if tag in {"script", "style", "noscript"}:
            self._ignored_depth += 1
        elif not self._ignored_depth and tag in self.BLOCK_TAGS:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag in {"script", "style", "noscript"} and self._ignored_depth:
            self._ignored_depth -= 1
        elif not self._ignored_depth and tag in self.BLOCK_TAGS:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        if not self._ignored_depth:
            self.parts.append(data)

    def get_text(self) -> str:
        return _normalise_text("".join(self.parts))


class _FAQHTMLParser(HTMLParser):
    """Extract individual ``details.faq-item`` records from buyer FAQ HTML."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.records: list[dict[str, str]] = []
        self._in_item = False
        self._item_depth = 0
        self._in_summary = False
        self._in_answer = False
        self._current_category = ""
        self._current_id = ""
        self._question_parts: list[str] = []
        self._answer_parts: list[str] = []
        self._ignored_depth = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attributes = dict(attrs)
        classes = set((attributes.get("class") or "").split())

        if tag in {"script", "style", "noscript"}:
            self._ignored_depth += 1
            return
        if self._ignored_depth:
            return

        if tag == "details" and "faq-item" in classes and not self._in_item:
            self._in_item = True
            self._item_depth = 1
            self._current_id = attributes.get("id", "")
            self._current_category = attributes.get("data-category", "")
            self._question_parts = []
            self._answer_parts = []
            return

        if self._in_item:
            if tag == "details":
                self._item_depth += 1
            elif tag == "summary":
                self._in_summary = True
            elif "answer" in classes:
                self._in_answer = True
            elif tag in {"p", "br", "li"}:
                target = self._question_parts if self._in_summary else self._answer_parts
                target.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in {"script", "style", "noscript"}:
            if self._ignored_depth:
                self._ignored_depth -= 1
            return
        if self._ignored_depth or not self._in_item:
            return

        if tag == "summary":
            self._in_summary = False
        elif tag == "div" and self._in_answer:
            self._in_answer = False
        elif tag == "details":
            self._item_depth -= 1
            if self._item_depth == 0:
                question = _normalise_text("".join(self._question_parts))
                question = re.sub(r"^\d{2}\s+", "", question)
                answer = _normalise_text("".join(self._answer_parts))
                answer = re.sub(r"\s*\[Source: buyer_faq\.html.*?]\s*$", "", answer)
                self.records.append({
                    "faq_id": self._current_id.removeprefix("faq-"),
                    "category": self._current_category or "Buyer FAQ",
                    "question": question,
                    "answer": answer,
                })
                self._in_item = False
                self._in_answer = False

    def handle_data(self, data: str) -> None:
        if self._ignored_depth or not self._in_item:
            return
        if self._in_summary:
            self._question_parts.append(data)
        elif self._in_answer:
            self._answer_parts.append(data)


def _normalise_text(value: str) -> str:
    """Collapse horizontal whitespace while retaining paragraph boundaries."""
    lines = [re.sub(r"[ \t\f\v]+", " ", line).strip() for line in value.splitlines()]
    output: list[str] = []
    previous_blank = True
    for line in lines:
        if line:
            output.append(line)
            previous_blank = False
        elif not previous_blank:
            output.append("")
            previous_blank = True
    return "\n".join(output).strip()


def _content_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _parse_scalar(value: str | None) -> Any:
    """Convert useful CSV scalar values without corrupting identifiers."""
    if value is None:
        return None
    cleaned = value.strip()
    if not cleaned:
        return None
    lowered = cleaned.lower()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    if lowered in {"null", "none", "n/a"}:
        return None
    if re.fullmatch(r"-?\d+", cleaned) and not (
        len(cleaned) > 1 and cleaned.startswith("0")
    ):
        return int(cleaned)
    if re.fullmatch(r"-?(?:\d+\.\d*|\d*\.\d+)", cleaned):
        return float(cleaned)
    if (cleaned.startswith("{") and cleaned.endswith("}")) or (
        cleaned.startswith("[") and cleaned.endswith("]")
    ):
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            pass
    return cleaned


def _display_name(field_name: str) -> str:
    return field_name.replace("_", " ").strip().title()


def _row_to_text(row: Mapping[str, Any]) -> str:
    """Format a CSV row as an embedding-friendly entity document."""
    lines = []
    for key, value in row.items():
        if value is None or value == "":
            continue
        if isinstance(value, (dict, list)):
            value = json.dumps(value, ensure_ascii=False, sort_keys=True)
        lines.append(f"{_display_name(key)}: {value}")
    return "\n".join(lines)


def load_csv(path: str | Path) -> list[Document]:
    """Load one CSV row per document with typed metadata."""
    source_path = Path(path)
    documents: list[Document] = []
    try:
        with source_path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            if not reader.fieldnames:
                raise LoaderError(f"CSV has no header: {source_path}")
            for row_number, raw_row in enumerate(reader, start=2):
                row = {key: _parse_scalar(value) for key, value in raw_row.items() if key}
                text = _row_to_text(row)
                if not text:
                    continue
                is_review = "review_summary_id" in row
                metadata = {
                    **row,
                    "source": source_path.name,
                    "source_path": str(source_path),
                    "source_type": "review_summary" if is_review else "catalogue",
                    "chunk_type": "review" if is_review else "product",
                    "row_number": row_number,
                    "content_hash": _content_hash(text),
                }
                documents.append(Document(text=text, metadata=metadata))
    except (OSError, UnicodeError, csv.Error) as exc:
        raise LoaderError(f"Unable to load CSV {source_path}: {exc}") from exc
    return documents


def load_markdown(path: str | Path) -> list[Document]:
    """Load a Markdown file as one document for later heading-aware chunking."""
    source_path = Path(path)
    try:
        text = source_path.read_text(encoding="utf-8").strip()
    except (OSError, UnicodeError) as exc:
        raise LoaderError(f"Unable to load Markdown {source_path}: {exc}") from exc
    if not text:
        return []

    source_type = "category_guide"
    if source_path.name == "returns_refunds_policy.md":
        source_type = "policy"
    elif source_path.name == "seller_onboarding.md":
        source_type = "seller_guide"

    title_match = re.search(r"^#\s+(.+)$", text, flags=re.MULTILINE)
    document_id_match = re.search(r"\*\*Document ID:\*\*\s*([^\n]+)", text)
    metadata: dict[str, Any] = {
        "source": source_path.name,
        "source_path": str(source_path),
        "source_type": source_type,
        "chunk_type": source_type,
        "title": title_match.group(1).strip() if title_match else source_path.stem,
        "document_id": document_id_match.group(1).strip() if document_id_match else None,
        "content_hash": _content_hash(text),
    }
    if "electronics" in source_path.stem:
        metadata["category"] = "Electronics"
    elif "fashion" in source_path.stem:
        metadata["category"] = "Fashion"
    return [Document(text=text, metadata=metadata)]


def load_html(path: str | Path) -> list[Document]:
    """Load FAQ items separately, or fall back to one cleaned HTML document."""
    source_path = Path(path)
    try:
        html = source_path.read_text(encoding="utf-8")
    except (OSError, UnicodeError) as exc:
        raise LoaderError(f"Unable to load HTML {source_path}: {exc}") from exc
    if not html.strip():
        return []

    faq_parser = _FAQHTMLParser()
    faq_parser.feed(html)
    if faq_parser.records:
        documents = []
        for record in faq_parser.records:
            text = f"Question: {record['question']}\nAnswer: {record['answer']}"
            metadata = {
                "source": source_path.name,
                "source_path": str(source_path),
                "source_type": "faq",
                "chunk_type": "faq",
                "faq_id": record["faq_id"],
                "section": record["category"],
                "question": record["question"],
                "content_hash": _content_hash(text),
            }
            documents.append(Document(text=text, metadata=metadata))
        return documents

    parser = _HTMLTextExtractor()
    parser.feed(html)
    text = parser.get_text()
    if not text:
        return []
    return [Document(text=text, metadata={
        "source": source_path.name,
        "source_path": str(source_path),
        "source_type": "html",
        "chunk_type": "document",
        "content_hash": _content_hash(text),
    })]


def load_json(path: str | Path) -> list[Document]:
    """Load a JSON file as a document; intended mainly for manifests."""
    source_path = Path(path)
    try:
        payload = json.loads(source_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise LoaderError(f"Unable to load JSON {source_path}: {exc}") from exc
    text = json.dumps(payload, indent=2, ensure_ascii=False, sort_keys=True)
    return [Document(text=text, metadata={
        "source": source_path.name,
        "source_path": str(source_path),
        "source_type": "manifest" if "manifest" in source_path.stem else "json",
        "chunk_type": "document",
        "content_hash": _content_hash(text),
    })]


def load_file(path: str | Path) -> list[Document]:
    """Dispatch a supported file to its appropriate loader."""
    source_path = Path(path)
    if not source_path.is_file():
        raise LoaderError(f"Source file does not exist: {source_path}")
    extension = source_path.suffix.lower()
    if extension == ".csv":
        return load_csv(source_path)
    if extension in {".md", ".markdown"}:
        return load_markdown(source_path)
    if extension in {".html", ".htm"}:
        return load_html(source_path)
    if extension == ".json":
        return load_json(source_path)
    raise LoaderError(
        f"Unsupported file type {extension!r} for {source_path}. "
        f"Supported extensions: {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
    )


def discover_files(
    source: str | Path | Iterable[str | Path],
    *,
    recursive: bool = False,
    include_json: bool = False,
) -> list[Path]:
    """Resolve files or directories into a stable, de-duplicated file list."""
    if isinstance(source, (str, Path)):
        inputs: Sequence[str | Path] = [source]
    else:
        inputs = list(source)

    allowed = SUPPORTED_EXTENSIONS if include_json else SUPPORTED_EXTENSIONS - {".json"}
    found: dict[str, Path] = {}
    for item in inputs:
        path = Path(item)
        if path.is_file():
            if path.suffix.lower() in allowed:
                found[str(path.resolve())] = path
            else:
                raise LoaderError(f"Unsupported source file: {path}")
        elif path.is_dir():
            iterator: Iterator[Path] = path.rglob("*") if recursive else path.glob("*")
            for candidate in iterator:
                if candidate.is_file() and candidate.suffix.lower() in allowed:
                    found[str(candidate.resolve())] = candidate
        else:
            raise LoaderError(f"Source path does not exist: {path}")
    return sorted(found.values(), key=lambda value: str(value).lower())


def load_documents(
    source: str | Path | Iterable[str | Path],
    *,
    recursive: bool = False,
    include_json: bool = False,
    strict: bool = True,
) -> list[Document]:
    """Load all supported sources into framework-independent documents.

    Args:
        source: A file, directory, or iterable of file and directory paths.
        recursive: Search nested directories when a source is a directory.
        include_json: Include JSON files such as the ingestion manifest.
        strict: Raise immediately on a load failure. When false, unreadable
            files are skipped.

    Returns:
        Documents in deterministic source-path order.
    """
    documents: list[Document] = []
    for path in discover_files(source, recursive=recursive, include_json=include_json):
        try:
            documents.extend(load_file(path))
        except LoaderError:
            if strict:
                raise
    return documents


def group_by_source_type(documents: Iterable[Document]) -> dict[str, list[Document]]:
    """Group loaded documents by ``source_type`` metadata."""
    grouped: dict[str, list[Document]] = {}
    for document in documents:
        key = str(document.metadata.get("source_type", "unknown"))
        grouped.setdefault(key, []).append(document)
    return grouped


__all__ = [
    "Document",
    "LoaderError",
    "SUPPORTED_EXTENSIONS",
    "discover_files",
    "group_by_source_type",
    "load_csv",
    "load_documents",
    "load_file",
    "load_html",
    "load_json",
    "load_markdown",
]
