"""Chunking strategies for the CatalogueIQ RAG ingestion pipeline.

The module applies source-aware chunking without LangChain:

* product catalogue rows remain one product per chunk;
* review summaries remain one review per chunk;
* buyer FAQs remain one question-and-answer pair per chunk;
* Markdown policies and guides are split by heading, then recursively split
  when a section exceeds the configured size;
* generic documents use recursive character chunking.

The public functions accept the framework-independent ``Document`` class from
``catalogueiq.loaders`` and return ``Chunk`` objects ready for embedding and
storage in LanceDB.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from typing import Any, Iterable, Iterator, Sequence

try:
    from .loaders import Document
except ImportError:  # Allows direct execution during development.
    from loaders import Document

DEFAULT_CHUNK_SIZE = 800
DEFAULT_CHUNK_OVERLAP = 120
NATURAL_CHUNK_TYPES = frozenset({"product", "review", "faq"})


@dataclass(slots=True)
class Chunk:
    """A text chunk and its retrieval metadata."""

    text: str
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def id(self) -> str:
        """Return the stable chunk identifier."""
        return str(self.metadata.get("id", self.metadata.get("chunk_id", "")))

    def as_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable representation."""
        return {"text": self.text, "metadata": dict(self.metadata)}


class ChunkingError(ValueError):
    """Raised when chunking configuration or input is invalid."""


def _sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _normalise_text(text: str) -> str:
    lines = [re.sub(r"[ \t]+", " ", line).strip() for line in text.splitlines()]
    output: list[str] = []
    previous_blank = True
    for line in lines:
        if line:
            output.append(line)
            previous_blank = False
        elif not previous_blank:
            output.append("")
            previous_blank = True
    return "\n".join(output).strip()


def _validate_config(chunk_size: int, chunk_overlap: int) -> None:
    if chunk_size <= 0:
        raise ChunkingError("chunk_size must be greater than zero")
    if chunk_overlap < 0:
        raise ChunkingError("chunk_overlap cannot be negative")
    if chunk_overlap >= chunk_size:
        raise ChunkingError("chunk_overlap must be smaller than chunk_size")


def _preferred_break(text: str, start: int, maximum_end: int) -> int:
    """Find a readable split point before ``maximum_end``."""
    minimum = start + max(1, (maximum_end - start) // 2)
    candidates = [
        text.rfind("\n\n", minimum, maximum_end),
        text.rfind("\n", minimum, maximum_end),
        text.rfind(". ", minimum, maximum_end),
        text.rfind("; ", minimum, maximum_end),
        text.rfind(", ", minimum, maximum_end),
        text.rfind(" ", minimum, maximum_end),
    ]
    best = max(candidates)
    if best < minimum:
        return maximum_end
    if text.startswith("\n\n", best):
        return best + 2
    if text.startswith((". ", "; ", ", "), best):
        return best + 1
    return best + 1


def recursive_text_split(
    text: str,
    *,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
) -> list[str]:
    """Split text into readable overlapping chunks.

    Splits prefer paragraph, line, sentence, clause, and word boundaries in
    that order. Every returned chunk is non-empty and no longer than the
    configured chunk size, apart from unavoidable differences caused by
    whitespace normalization.
    """
    _validate_config(chunk_size, chunk_overlap)
    cleaned = _normalise_text(text)
    if not cleaned:
        return []
    if len(cleaned) <= chunk_size:
        return [cleaned]

    chunks: list[str] = []
    start = 0
    text_length = len(cleaned)
    while start < text_length:
        maximum_end = min(start + chunk_size, text_length)
        end = maximum_end if maximum_end == text_length else _preferred_break(
            cleaned, start, maximum_end
        )
        if end <= start:
            end = maximum_end
        chunk = cleaned[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end >= text_length:
            break

        next_start = max(0, end - chunk_overlap)
        if next_start <= start:
            next_start = end
        while next_start < text_length and cleaned[next_start].isspace():
            next_start += 1
        start = next_start
    return chunks


def fixed_size_split(
    text: str,
    *,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
) -> list[str]:
    """Split at fixed character offsets for chunking experiments."""
    _validate_config(chunk_size, chunk_overlap)
    cleaned = _normalise_text(text)
    if not cleaned:
        return []
    step = chunk_size - chunk_overlap
    return [cleaned[start : start + chunk_size].strip() for start in range(0, len(cleaned), step)]


def _parse_markdown_sections(text: str) -> list[tuple[str, str]]:
    """Return ``(heading_path, section_text)`` pairs from Markdown."""
    heading_pattern = re.compile(r"^(#{1,6})\s+(.+?)\s*$")
    headings: list[str] = []
    sections: list[tuple[str, str]] = []
    current_path = "Document"
    current_lines: list[str] = []
    in_fence = False

    def flush() -> None:
        section_text = _normalise_text("\n".join(current_lines))
        if section_text:
            sections.append((current_path, section_text))

    for line in text.splitlines():
        if line.lstrip().startswith("```"):
            in_fence = not in_fence
        match = None if in_fence else heading_pattern.match(line)
        if match:
            flush()
            current_lines = []
            level = len(match.group(1))
            title = match.group(2).strip()
            headings[level - 1 :] = [title]
            current_path = " > ".join(headings)
            current_lines.append(line)
        else:
            current_lines.append(line)
    flush()
    return sections


def _identity(metadata: dict[str, Any], fallback: str) -> str:
    for key in ("product_id", "review_summary_id", "faq_id", "document_id"):
        value = metadata.get(key)
        if value not in (None, ""):
            return str(value)
    return fallback


def _make_chunk(
    text: str,
    base_metadata: dict[str, Any],
    *,
    index: int,
    section: str | None = None,
    strategy: str,
) -> Chunk:
    cleaned = _normalise_text(text)
    source = str(base_metadata.get("source", "unknown"))
    identity = _identity(base_metadata, source)
    section_value = section or str(base_metadata.get("section", ""))
    stable_input = f"{source}|{identity}|{section_value}|{index}|{cleaned}"
    chunk_id = f"chk-{_sha256(stable_input)[:20]}"
    metadata = dict(base_metadata)
    metadata.update(
        {
            "id": chunk_id,
            "chunk_id": chunk_id,
            "chunk_index": index,
            "section": section_value or None,
            "chunking_strategy": strategy,
            "character_count": len(cleaned),
            "word_count": len(cleaned.split()),
            "content_hash": _sha256(cleaned),
        }
    )
    return Chunk(text=cleaned, metadata=metadata)


def chunk_natural_document(document: Document) -> list[Chunk]:
    """Keep a product, review summary, or FAQ document intact."""
    if not document.text.strip():
        return []
    return [
        _make_chunk(
            document.text,
            document.metadata,
            index=0,
            strategy="natural_entity",
        )
    ]


def chunk_markdown_document(
    document: Document,
    *,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
) -> list[Chunk]:
    """Split Markdown by headings and recursively split long sections."""
    _validate_config(chunk_size, chunk_overlap)
    chunks: list[Chunk] = []
    chunk_index = 0
    for heading_path, section_text in _parse_markdown_sections(document.text):
        pieces = recursive_text_split(
            section_text,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
        )
        for section_index, piece in enumerate(pieces):
            chunk = _make_chunk(
                piece,
                document.metadata,
                index=chunk_index,
                section=heading_path,
                strategy="heading_aware_recursive",
            )
            chunk.metadata["section_chunk_index"] = section_index
            chunk.metadata["section_chunk_count"] = len(pieces)
            chunks.append(chunk)
            chunk_index += 1
    return chunks


def chunk_generic_document(
    document: Document,
    *,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
    strategy: str = "recursive",
) -> list[Chunk]:
    """Chunk an unstructured document with the requested strategy."""
    if strategy == "recursive":
        pieces = recursive_text_split(
            document.text, chunk_size=chunk_size, chunk_overlap=chunk_overlap
        )
    elif strategy == "fixed":
        pieces = fixed_size_split(
            document.text, chunk_size=chunk_size, chunk_overlap=chunk_overlap
        )
    else:
        raise ChunkingError(f"Unsupported generic chunking strategy: {strategy}")
    return [
        _make_chunk(
            piece,
            document.metadata,
            index=index,
            strategy=f"{strategy}_character",
        )
        for index, piece in enumerate(pieces)
    ]


def chunk_document(
    document: Document,
    *,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
    generic_strategy: str = "recursive",
) -> list[Chunk]:
    """Apply the correct strategy based on source and chunk metadata."""
    chunk_type = str(document.metadata.get("chunk_type", "")).lower()
    source = str(document.metadata.get("source", "")).lower()

    if chunk_type in NATURAL_CHUNK_TYPES:
        return chunk_natural_document(document)
    if source.endswith((".md", ".markdown")) or chunk_type in {
        "policy", "seller_guide", "category_guide"
    }:
        return chunk_markdown_document(
            document,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
        )
    return chunk_generic_document(
        document,
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        strategy=generic_strategy,
    )


def chunk_documents(
    documents: Iterable[Document],
    *,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
    generic_strategy: str = "recursive",
) -> list[Chunk]:
    """Chunk a collection and assign collection-level source indexes."""
    _validate_config(chunk_size, chunk_overlap)
    chunks: list[Chunk] = []
    source_counts: dict[str, int] = {}

    for document in documents:
        document_chunks = chunk_document(
            document,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            generic_strategy=generic_strategy,
        )
        source = str(document.metadata.get("source", "unknown"))
        start = source_counts.get(source, 0)
        for offset, chunk in enumerate(document_chunks):
            chunk.metadata["source_chunk_index"] = start + offset
            chunks.append(chunk)
        source_counts[source] = start + len(document_chunks)
    return chunks


def iter_chunks(
    documents: Iterable[Document],
    *,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
    generic_strategy: str = "recursive",
) -> Iterator[Chunk]:
    """Yield chunks lazily, one source document at a time."""
    for document in documents:
        yield from chunk_document(
            document,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            generic_strategy=generic_strategy,
        )


def compare_chunking_strategies(
    document: Document,
    *,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
) -> dict[str, dict[str, Any]]:
    """Compare fixed and source-aware strategies for the evaluation report."""
    fixed = chunk_generic_document(
        document,
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        strategy="fixed",
    )
    source_aware = chunk_document(
        document,
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )

    def metrics(chunks: Sequence[Chunk]) -> dict[str, Any]:
        lengths = [len(chunk.text) for chunk in chunks]
        return {
            "chunk_count": len(chunks),
            "minimum_characters": min(lengths, default=0),
            "maximum_characters": max(lengths, default=0),
            "average_characters": round(sum(lengths) / len(lengths), 2) if lengths else 0.0,
            "sections_preserved": sum(bool(chunk.metadata.get("section")) for chunk in chunks),
        }

    return {"fixed": metrics(fixed), "source_aware": metrics(source_aware)}


def validate_chunks(chunks: Iterable[Chunk]) -> dict[str, Any]:
    """Check required fields, duplicate IDs, and empty content."""
    chunk_list = list(chunks)
    ids: set[str] = set()
    duplicate_ids: list[str] = []
    empty_indexes: list[int] = []
    missing_sources: list[int] = []

    for index, chunk in enumerate(chunk_list):
        if not chunk.text.strip():
            empty_indexes.append(index)
        if not chunk.metadata.get("source"):
            missing_sources.append(index)
        if chunk.id in ids:
            duplicate_ids.append(chunk.id)
        ids.add(chunk.id)

    return {
        "valid": not (duplicate_ids or empty_indexes or missing_sources),
        "chunk_count": len(chunk_list),
        "unique_id_count": len(ids),
        "duplicate_ids": duplicate_ids,
        "empty_chunk_indexes": empty_indexes,
        "missing_source_indexes": missing_sources,
    }


__all__ = [
    "Chunk",
    "ChunkingError",
    "DEFAULT_CHUNK_OVERLAP",
    "DEFAULT_CHUNK_SIZE",
    "chunk_document",
    "chunk_documents",
    "chunk_generic_document",
    "chunk_markdown_document",
    "chunk_natural_document",
    "compare_chunking_strategies",
    "fixed_size_split",
    "iter_chunks",
    "recursive_text_split",
    "validate_chunks",
]
