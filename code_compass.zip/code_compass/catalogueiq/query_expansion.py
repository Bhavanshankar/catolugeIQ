"""Query expansion and lightweight query analysis for CatalogueIQ.

The module expands shopper, seller, and support-agent questions into multiple
retrieval variants. It combines deterministic e-commerce synonyms with
constraint-aware rewrites, while preserving important restrictions such as
budget, category, brand exclusion, size, ANC, battery life, and rating.

No external dependency or LLM is required. An optional rewrite callback can be
provided by the application when LLM-based expansion is desired.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Mapping, Sequence

DEFAULT_MAX_VARIANTS = 4

# Longest phrases are matched first to avoid replacing part of a larger term.
DEFAULT_SYNONYMS: dict[str, tuple[str, ...]] = {
    "wireless earphones": ("wireless earbuds", "TWS earbuds", "Bluetooth earbuds"),
    "true wireless stereo": ("TWS", "wireless earbuds"),
    "earphones": ("earbuds", "in-ear headphones", "TWS"),
    "earbuds": ("wireless earphones", "TWS", "in-ear headphones"),
    "tws": ("wireless earbuds", "true wireless stereo", "Bluetooth earbuds"),
    "noise cancellation": ("ANC", "active noise cancellation"),
    "anc": ("active noise cancellation", "noise-cancelling"),
    "call noise reduction": ("ENC", "microphone noise reduction"),
    "mobile": ("smartphone", "phone", "handset"),
    "smart phone": ("smartphone", "mobile phone"),
    "smart band": ("fitness band", "activity tracker"),
    "power bank": ("portable charger", "battery pack"),
    "charger": ("power adaptor", "charging adaptor"),
    "fridge": ("refrigerator",),
    "washing machine": ("washer",),
    "mixer": ("mixer grinder", "food mixer"),
    "tee": ("T-shirt", "crew-neck T-shirt"),
    "kurti": ("kurta", "women's ethnic top"),
    "trainers": ("sneakers", "sports shoes"),
    "hand purse": ("handbag", "shoulder bag"),
    "denims": ("jeans", "denim trousers"),
    "rucksack": ("backpack", "daypack"),
    "flip-flops": ("slippers", "casual sandals"),
    "refund": ("money back", "payment reversal"),
    "return": ("return eligibility", "replacement", "refund"),
    "genuine": ("authentic", "original"),
    "fake": ("counterfeit", "not genuine"),
    "seller verified": ("verified seller", "seller verification"),
}

CATEGORY_TERMS: dict[str, tuple[str, ...]] = {
    "Electronics": (
        "earbud", "earbuds", "earphone", "earphones", "headphone", "headphones", "tws", "smartwatch", "speaker",
        "power bank", "charger", "keyboard", "mouse", "smartphone", "mobile",
        "phone", "tablet", "electronics",
    ),
    "Fashion": (
        "shirt", "t-shirt", "tee", "jeans", "trouser", "kurta", "kurti",
        "dress", "sneaker", "shoe", "jacket", "handbag", "backpack",
        "fashion", "size", "fit",
    ),
    "Home & Kitchen": (
        "mixer", "cookware", "bottle", "bedsheet", "storage box", "kettle",
        "lamp", "air fryer", "kitchen", "home appliance",
    ),
    "Beauty": (
        "face wash", "moisturizer", "sunscreen", "shampoo", "lipstick",
        "serum", "body lotion", "perfume", "beauty", "skin care", "hair care",
    ),
    "Books": (
        "book", "novel", "fiction", "biography", "textbook", "paperback",
        "hardcover", "author", "publisher", "isbn",
    ),
}

PERSONA_HINTS: dict[str, tuple[str, ...]] = {
    "seller": (
        "listing", "onboarding", "image requirement", "seller account", "sku",
        "inventory", "compliance", "product title", "catalogue upload",
    ),
    "support_agent": (
        "refund delayed", "appeal", "dispute", "escalate", "buyer protection",
        "support agent", "case", "complaint",
    ),
}


@dataclass(slots=True)
class QueryConstraints:
    """Structured constraints extracted from a natural-language query."""

    category: str | None = None
    subcategory: str | None = None
    max_price: float | None = None
    min_price: float | None = None
    min_rating: float | None = None
    min_battery_hours: float | None = None
    size: str | None = None
    brand: str | None = None
    excluded_brands: list[str] = field(default_factory=list)
    anc_required: bool | None = None
    verified_seller_required: bool | None = None
    in_stock_required: bool | None = None
    return_window_days: int | None = None

    def as_dict(self) -> dict[str, Any]:
        """Return only constraints that were detected."""
        return {
            key: value
            for key, value in {
                "category": self.category,
                "subcategory": self.subcategory,
                "max_price": self.max_price,
                "min_price": self.min_price,
                "min_rating": self.min_rating,
                "min_battery_hours": self.min_battery_hours,
                "size": self.size,
                "brand": self.brand,
                "excluded_brands": self.excluded_brands or None,
                "anc_required": self.anc_required,
                "verified_seller_required": self.verified_seller_required,
                "in_stock_required": self.in_stock_required,
                "return_window_days": self.return_window_days,
            }.items()
            if value is not None
        }


@dataclass(slots=True)
class ExpandedQuery:
    """Original query, variants, and inferred retrieval metadata."""

    original: str
    variants: list[str]
    constraints: QueryConstraints
    persona: str
    query_type: str
    detected_terms: list[str] = field(default_factory=list)

    @property
    def all_queries(self) -> list[str]:
        """Return the original query followed by unique expansion variants."""
        return _deduplicate([self.original, *self.variants])

    def as_dict(self) -> dict[str, Any]:
        return {
            "original": self.original,
            "variants": list(self.variants),
            "all_queries": self.all_queries,
            "constraints": self.constraints.as_dict(),
            "persona": self.persona,
            "query_type": self.query_type,
            "detected_terms": list(self.detected_terms),
        }


class QueryExpansionError(ValueError):
    """Raised when a query or expansion configuration is invalid."""


def normalize_query(query: str) -> str:
    """Normalize whitespace and common Indian currency expressions."""
    if not isinstance(query, str) or not query.strip():
        raise QueryExpansionError("query must be a non-empty string")
    value = query.strip()
    value = re.sub(r"\b(?:rs\.?|inr)\s*", "₹", value, flags=re.IGNORECASE)
    value = re.sub(r"₹\s+", "₹", value)
    value = re.sub(r"\s+", " ", value)
    return value


def extract_constraints(query: str, *, known_brands: Iterable[str] = ()) -> QueryConstraints:
    """Extract common CatalogueIQ filters from a user query."""
    normalized = normalize_query(query)
    lowered = normalized.casefold()
    constraints = QueryConstraints()

    constraints.category = _detect_category(lowered)
    constraints.subcategory = _detect_subcategory(lowered)

    max_match = re.search(
        r"(?:under|below|less than|up to|within|max(?:imum)?(?: price)?(?: of)?|budget(?: of)?)\s*"
        r"₹?\s*([\d,]+(?:\.\d+)?)\s*(k|thousand)?\b",
        lowered,
    )
    if max_match:
        tail = lowered[max_match.end() : max_match.end() + 12]
        has_currency = "₹" in max_match.group(0) or bool(
            re.search(r"\b(?:rs\.?|inr|rupees?)\b", max_match.group(0), flags=re.IGNORECASE)
        )
        looks_like_time = bool(re.match(r"\s*(?:days?|hours?|months?|years?)\b", tail))
        if has_currency or not looks_like_time:
            constraints.max_price = _money_value(max_match.group(1), max_match.group(2))

    min_match = re.search(
        r"(?:above|over|more than|at least|min(?:imum)?(?: price)?(?: of)?)\s*"
        r"₹\s*([\d,]+(?:\.\d+)?)\s*(k|thousand)?\b",
        lowered,
    )
    if min_match:
        constraints.min_price = _money_value(min_match.group(1), min_match.group(2))

    rating_match = re.search(
        r"(?:rating|rated)\s*(?:of|above|over|at least|>=)?\s*(\d(?:\.\d)?)",
        lowered,
    ) or re.search(r"(\d(?:\.\d)?)\s*(?:stars?|star rating)", lowered)
    if rating_match:
        rating = float(rating_match.group(1))
        if 0 <= rating <= 5:
            constraints.min_rating = rating

    battery_match = re.search(
        r"(?:at least|min(?:imum)?(?: of)?|over|more than)?\s*(\d+(?:\.\d+)?)\s*"
        r"(?:hours?|hrs?)\s*(?:of\s*)?battery(?: life)?",
        lowered,
    ) or re.search(
        r"battery(?: life)?\s*(?:of|at least|over|more than)?\s*(\d+(?:\.\d+)?)\s*(?:hours?|hrs?)",
        lowered,
    )
    if battery_match:
        constraints.min_battery_hours = float(battery_match.group(1))

    size_match = re.search(
        r"\b(?:size|in size)\s*(?:uk\s*)?(xxs|xs|s|m|l|xl|xxl|\d{1,2}(?:\.5)?)\b",
        lowered,
        flags=re.IGNORECASE,
    )
    if size_match:
        constraints.size = size_match.group(1).upper()

    if re.search(r"\b(?:with|support(?:s|ing)?|must have|need)\s+(?:good\s+)?(?:anc|active noise cancellation)\b", lowered):
        constraints.anc_required = True
    elif re.search(r"\b(?:without|no)\s+(?:anc|active noise cancellation)\b", lowered):
        constraints.anc_required = False

    if re.search(r"\b(?:verified seller|seller verified|from verified sellers?)\b", lowered):
        constraints.verified_seller_required = True
    if re.search(r"\b(?:in stock|available now|currently available)\b", lowered):
        constraints.in_stock_required = True

    return_match = re.search(r"\b(?:within|for)\s+(\d+)\s+days?\b", lowered)
    if return_match and any(word in lowered for word in ("return", "refund", "replace")):
        constraints.return_window_days = int(return_match.group(1))

    excluded = re.findall(
        r"\b(?:exclude|excluding|except|without|do not include|don't include)\s+"
        r"([a-z][a-z0-9& .'-]{1,30}?)(?=\s+(?:and|under|below|with|having|that)|[,?.]|$)",
        lowered,
    )
    constraints.excluded_brands = [item.strip().title() for item in excluded]

    for brand in sorted(set(known_brands), key=len, reverse=True):
        if re.search(rf"\b{re.escape(brand.casefold())}\b", lowered):
            if not any(brand.casefold() in excluded.casefold() for excluded in constraints.excluded_brands):
                constraints.brand = brand
            break
    return constraints


def detect_persona(query: str, requested_persona: str | None = None) -> str:
    """Infer Shopper, Seller, or Support Agent persona."""
    if requested_persona:
        normalized = requested_persona.strip().lower().replace(" ", "_")
        aliases = {"shopper": "shopper", "seller": "seller", "support": "support_agent", "support_agent": "support_agent"}
        if normalized not in aliases:
            raise QueryExpansionError(f"unsupported persona: {requested_persona!r}")
        return aliases[normalized]
    lowered = query.casefold()
    for persona, hints in PERSONA_HINTS.items():
        if any(hint in lowered for hint in hints):
            return persona
    return "shopper"


def classify_query(query: str) -> str:
    """Classify the query into one of the five capstone query types."""
    lowered = normalize_query(query).casefold()
    policy_terms = ("return", "refund", "eligible", "policy", "cancel", "replacement")
    seller_terms = ("listing", "onboarding", "image requirement", "seller account", "sku", "compliance")
    comparative_terms = ("best", "compare", "which", "top", "recommend", "better", "versus", " vs ")
    multi_hop_terms = ("after", "stops working", "third-party", "what are my options", "buyer protection", "warranty")

    if sum(term in lowered for term in multi_hop_terms) >= 2:
        return "multi_hop"
    if any(term in lowered for term in seller_terms):
        return "seller_policy_lookup"
    if any(term in lowered for term in comparative_terms) and any(
        term in lowered for term in ("under", "below", "with", "at least", "compare", "best")
    ):
        return "comparative_recommendation"
    if any(term in lowered for term in policy_terms):
        return "policy_eligibility"
    return "product_factual_lookup"


def expand_query(
    query: str,
    *,
    max_variants: int = DEFAULT_MAX_VARIANTS,
    synonyms: Mapping[str, Sequence[str]] | None = None,
    persona: str | None = None,
    known_brands: Iterable[str] = (),
    rewrite_callback: Callable[[str, QueryConstraints], Sequence[str]] | None = None,
) -> ExpandedQuery:
    """Expand one query into deterministic and optional callback variants.

    At least two variants are produced when a synonym is detected. If no
    synonym applies, retrieval-oriented variants are created from the query
    type and extracted constraints.
    """
    if max_variants < 2:
        raise QueryExpansionError("max_variants must be at least 2")
    original = normalize_query(query)
    constraints = extract_constraints(original, known_brands=known_brands)
    query_type = classify_query(original)
    detected_persona = detect_persona(original, persona)
    synonym_map = synonyms or DEFAULT_SYNONYMS

    variants: list[str] = []
    detected_terms: list[str] = []
    lowered = original.casefold()

    for term in sorted(synonym_map, key=len, reverse=True):
        match = re.search(rf"(?<!\w){re.escape(term.casefold())}(?!\w)", lowered)
        if not match:
            continue
        detected_terms.append(term)
        for replacement in synonym_map[term]:
            variant = original[: match.start()] + replacement + original[match.end() :]
            variants.append(_clean_variant(variant))

    variants.extend(_retrieval_rewrites(original, constraints, query_type))

    if rewrite_callback is not None:
        try:
            variants.extend(str(item) for item in rewrite_callback(original, constraints))
        except Exception as exc:
            raise QueryExpansionError(f"rewrite callback failed: {exc}") from exc

    variants = [variant for variant in _deduplicate(variants) if variant.casefold() != original.casefold()]
    variants = [_preserve_constraints(variant, original, constraints) for variant in variants]
    variants = _deduplicate(variants)

    while len(variants) < 2:
        suffix = "product specifications and catalogue attributes" if len(variants) == 0 else "relevant ShopSmart India policy and evidence"
        variants.append(_clean_variant(f"{original} {suffix}"))
    variants = variants[:max_variants]

    return ExpandedQuery(
        original=original,
        variants=variants,
        constraints=constraints,
        persona=detected_persona,
        query_type=query_type,
        detected_terms=_deduplicate(detected_terms),
    )


def expand_queries(
    queries: Iterable[str],
    **kwargs: Any,
) -> list[ExpandedQuery]:
    """Expand multiple independent user queries."""
    return [expand_query(query, **kwargs) for query in queries]


def _retrieval_rewrites(
    original: str,
    constraints: QueryConstraints,
    query_type: str,
) -> list[str]:
    suffixes = {
        "product_factual_lookup": (
            "exact product specifications model attributes",
            "catalogue product record technical details",
        ),
        "policy_eligibility": (
            "return refund eligibility conditions exceptions",
            "ShopSmart India policy window requirements",
        ),
        "comparative_recommendation": (
            "compare eligible products specifications ratings reviews",
            "rank matching catalogue products by constraints",
        ),
        "seller_policy_lookup": (
            "seller onboarding listing compliance requirements",
            "seller guide exact section and checklist",
        ),
        "multi_hop": (
            "return window warranty seller responsibility buyer protection",
            "policy options exceptions escalation evidence",
        ),
    }
    additions = suffixes[query_type]
    return [_clean_variant(f"{original} {addition}") for addition in additions]


def _preserve_constraints(variant: str, original: str, constraints: QueryConstraints) -> str:
    """Append missing hard constraints to prevent semantic drift."""
    additions: list[str] = []
    lowered = variant.casefold()
    if constraints.max_price is not None and not re.search(r"₹\s*[\d,]+|\b\d+\s*(?:rupees?|inr)\b", lowered):
        additions.append(f"under ₹{constraints.max_price:g}")
    if constraints.min_rating is not None and str(constraints.min_rating) not in lowered:
        additions.append(f"rating at least {constraints.min_rating:g}")
    if constraints.min_battery_hours is not None and not re.search(r"\d+(?:\.\d+)?\s*(?:hours?|hrs?)", lowered):
        additions.append(f"battery at least {constraints.min_battery_hours:g} hours")
    if constraints.size and not re.search(rf"\b{re.escape(constraints.size.casefold())}\b", lowered):
        additions.append(f"size {constraints.size}")
    if constraints.anc_required is True and not re.search(r"\banc\b|active noise cancellation", lowered):
        additions.append("with ANC")
    for brand in constraints.excluded_brands:
        if brand.casefold() not in lowered:
            additions.append(f"exclude {brand}")
    return _clean_variant(" ".join([variant, *additions]))


def _detect_category(lowered: str) -> str | None:
    for category, terms in CATEGORY_TERMS.items():
        if any(re.search(rf"(?<!\w){re.escape(term)}(?!\w)", lowered) for term in terms):
            return category
    return None


def _detect_subcategory(lowered: str) -> str | None:
    mapping = {
        "Wireless Earbuds": ("wireless earbuds", "wireless earphones", "tws", "earbuds", "earphones"),
        "Smartwatch": ("smartwatch", "smart watch"),
        "Bluetooth Speaker": ("bluetooth speaker", "wireless speaker"),
        "Power Bank": ("power bank", "portable charger"),
        "Keyboard": ("keyboard",),
        "Mouse": ("mouse",),
        "Smartphone": ("smartphone", "smart phone", "mobile phone"),
        "Tablet": ("tablet",),
        "T-Shirt": ("t-shirt", "t shirt", "tee"),
        "Jeans": ("jeans", "denims"),
        "Kurta": ("kurta", "kurti"),
        "Dress": ("dress",),
        "Sneakers": ("sneakers", "trainers", "sports shoes"),
        "Jacket": ("jacket",),
        "Handbag": ("handbag", "hand purse"),
    }
    for subcategory, terms in mapping.items():
        if any(re.search(rf"(?<!\w){re.escape(term)}(?!\w)", lowered) for term in terms):
            return subcategory
    return None


def _money_value(number: str, multiplier: str | None) -> float:
    value = float(number.replace(",", ""))
    if multiplier:
        value *= 1000
    return value


def _clean_variant(value: str) -> str:
    value = re.sub(r"\s+", " ", value).strip(" ,")
    return value


def _deduplicate(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    output: list[str] = []
    for value in values:
        cleaned = _clean_variant(str(value))
        key = cleaned.casefold()
        if cleaned and key not in seen:
            seen.add(key)
            output.append(cleaned)
    return output


__all__ = [
    "CATEGORY_TERMS",
    "DEFAULT_MAX_VARIANTS",
    "DEFAULT_SYNONYMS",
    "ExpandedQuery",
    "PERSONA_HINTS",
    "QueryConstraints",
    "QueryExpansionError",
    "classify_query",
    "detect_persona",
    "expand_queries",
    "expand_query",
    "extract_constraints",
    "normalize_query",
]
