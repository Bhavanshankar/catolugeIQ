"""Metadata filters and deterministic eligibility checks for CatalogueIQ.

This module converts constraints extracted by ``query_expansion.py`` into safe
LanceDB pre-filters and applies post-retrieval checks for attributes stored in
JSON or free-form metadata, such as ANC, battery life, Fashion size, and brand
exclusions.

The two-stage approach is intentional:

1. Use LanceDB pre-filters for typed columns such as category, subcategory,
   price, rating, seller verification, and availability.
2. Apply deterministic Python checks for nested or optional attributes that
   are not guaranteed to exist as top-level LanceDB columns.

This prevents semantically similar products that violate mandatory user
constraints from being recommended.
"""

from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass, field, replace
from typing import Any, Iterable, Mapping, Sequence, TypeVar

try:
    from .lancedb_store import SearchFilters, SearchResult
    from .query_expansion import ExpandedQuery, QueryConstraints
except ImportError:  # Allows direct execution during development.
    from lancedb_store import SearchFilters, SearchResult
    from query_expansion import ExpandedQuery, QueryConstraints

T = TypeVar("T")


class FilterError(ValueError):
    """Raised when filter configuration or metadata is invalid."""


@dataclass(frozen=True, slots=True)
class FilterPlan:
    """Complete retrieval filter plan for one query."""

    pre_filters: SearchFilters
    post_constraints: QueryConstraints
    query_type: str = "product_factual_lookup"
    persona: str = "shopper"
    preferred_source_types: tuple[str, ...] = ()
    retrieval_limit: int = 8
    candidate_multiplier: int = 3
    strict_product_constraints: bool = True
    notes: tuple[str, ...] = ()

    @property
    def candidate_limit(self) -> int:
        """Number of candidates to retrieve before post-filtering."""
        return max(self.retrieval_limit, self.retrieval_limit * self.candidate_multiplier)

    @property
    def where(self) -> str | None:
        """Return the LanceDB SQL pre-filter expression."""
        return self.pre_filters.to_sql()

    def as_dict(self) -> dict[str, Any]:
        return {
            "pre_filter_sql": self.where,
            "post_constraints": self.post_constraints.as_dict(),
            "query_type": self.query_type,
            "persona": self.persona,
            "preferred_source_types": list(self.preferred_source_types),
            "retrieval_limit": self.retrieval_limit,
            "candidate_limit": self.candidate_limit,
            "strict_product_constraints": self.strict_product_constraints,
            "notes": list(self.notes),
        }


@dataclass(slots=True)
class FilterDecision:
    """Explain why one retrieved item passed or failed constraints."""

    accepted: bool
    reasons: list[str] = field(default_factory=list)
    matched_constraints: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {
            "accepted": self.accepted,
            "reasons": list(self.reasons),
            "matched_constraints": list(self.matched_constraints),
        }


QUERY_TYPE_SOURCE_PREFERENCES: dict[str, tuple[str, ...]] = {
    "product_factual_lookup": ("catalogue", "review_summary", "category_guide"),
    "comparative_recommendation": ("catalogue", "review_summary", "category_guide"),
    "policy_eligibility": ("policy", "faq", "category_guide"),
    "seller_policy_lookup": ("seller_guide", "category_guide", "policy"),
    "multi_hop": ("policy", "faq", "seller_guide", "catalogue", "category_guide"),
}

QUERY_TYPE_LIMITS: dict[str, int] = {
    "product_factual_lookup": 4,
    "policy_eligibility": 6,
    "comparative_recommendation": 12,
    "seller_policy_lookup": 6,
    "multi_hop": 10,
}


def build_filter_plan(
    query: ExpandedQuery | QueryConstraints,
    *,
    query_type: str | None = None,
    persona: str | None = None,
    retrieval_limit: int | None = None,
    candidate_multiplier: int = 3,
    force_source_type: str | None = None,
    strict_product_constraints: bool = True,
) -> FilterPlan:
    """Convert expanded-query constraints into a two-stage filter plan."""
    if candidate_multiplier <= 0:
        raise FilterError("candidate_multiplier must be greater than zero")

    if isinstance(query, ExpandedQuery):
        constraints = query.constraints
        detected_query_type = query.query_type
        detected_persona = query.persona
    else:
        constraints = query
        detected_query_type = "product_factual_lookup"
        detected_persona = "shopper"

    final_query_type = query_type or detected_query_type
    final_persona = persona or detected_persona
    limit = retrieval_limit or QUERY_TYPE_LIMITS.get(final_query_type, 8)
    if limit <= 0:
        raise FilterError("retrieval_limit must be greater than zero")

    source_type = force_source_type
    notes: list[str] = []

    # Product constraints belong on catalogue records. Policy and multi-hop
    # retrieval should not apply product price/category filters to policy text.
    is_product_query = final_query_type in {
        "product_factual_lookup",
        "comparative_recommendation",
    }
    if is_product_query and source_type is None:
        source_type = "catalogue"

    if final_query_type == "seller_policy_lookup" and source_type is None:
        # Leave source type unset so seller-guide and category-guide chunks can
        # both participate. The retriever can run one search per preference.
        notes.append("Search seller_guide and category_guide source types separately.")

    if is_product_query:
        pre_filters = SearchFilters(
            category=constraints.category,
            subcategory=constraints.subcategory,
            source_type=source_type,
            brand=constraints.brand,
            availability="In Stock" if constraints.in_stock_required else None,
            max_price=constraints.max_price,
            min_price=constraints.min_price,
            min_rating=constraints.min_rating,
            seller_verified=True if constraints.verified_seller_required else None,
        )
    else:
        pre_filters = SearchFilters(source_type=source_type)
        if constraints.category:
            notes.append(
                "Category retained for post-ranking context rather than policy pre-filtering."
            )

    if constraints.anc_required is not None:
        notes.append("ANC is checked after retrieval from product specifications metadata.")
    if constraints.min_battery_hours is not None:
        notes.append("Battery life is checked after retrieval from normalized specifications.")
    if constraints.size:
        notes.append("Size availability is checked after retrieval.")
    if constraints.excluded_brands:
        notes.append("Excluded brands are removed after retrieval.")

    return FilterPlan(
        pre_filters=pre_filters,
        post_constraints=constraints,
        query_type=final_query_type,
        persona=final_persona,
        preferred_source_types=QUERY_TYPE_SOURCE_PREFERENCES.get(final_query_type, ()),
        retrieval_limit=limit,
        candidate_multiplier=candidate_multiplier,
        strict_product_constraints=strict_product_constraints,
        notes=tuple(notes),
    )


def filters_for_source(plan: FilterPlan, source_type: str) -> SearchFilters:
    """Return a copy of the plan's pre-filter for one source type."""
    if not source_type or not source_type.strip():
        raise FilterError("source_type cannot be empty")
    return replace(plan.pre_filters, source_type=source_type.strip())


def evaluate_metadata(
    metadata: Mapping[str, Any],
    constraints: QueryConstraints,
    *,
    strict_missing: bool = True,
) -> FilterDecision:
    """Evaluate one product metadata record against mandatory constraints."""
    values = _flatten_metadata(metadata)
    failures: list[str] = []
    matches: list[str] = []

    def compare_text(field: str, expected: str | None) -> None:
        if expected is None:
            return
        actual = _text(values.get(field))
        if not actual:
            if strict_missing:
                failures.append(f"missing {field}")
            return
        if actual.casefold() != expected.casefold():
            failures.append(f"{field} is {actual!r}, expected {expected!r}")
        else:
            matches.append(f"{field}={expected}")

    compare_text("category", constraints.category)
    compare_text("subcategory", constraints.subcategory)
    compare_text("brand", constraints.brand)

    _compare_number(values, "price_inr", constraints.max_price, "max", failures, matches, strict_missing)
    _compare_number(values, "price_inr", constraints.min_price, "min", failures, matches, strict_missing)
    _compare_number(values, "rating", constraints.min_rating, "min", failures, matches, strict_missing)

    if constraints.excluded_brands:
        brand = _text(values.get("brand"))
        excluded = {item.casefold() for item in constraints.excluded_brands}
        if brand and brand.casefold() in excluded:
            failures.append(f"brand {brand!r} is excluded")
        elif brand:
            matches.append("brand is not excluded")

    if constraints.verified_seller_required:
        verified = _bool(values.get("seller_verified"))
        if verified is True:
            matches.append("seller is verified")
        elif verified is False or strict_missing:
            failures.append("seller is not verified or verification is unavailable")

    if constraints.in_stock_required:
        availability = _text(values.get("availability"))
        stock = _number(values.get("stock_quantity"))
        in_stock = availability.casefold() == "in stock" if availability else None
        if in_stock is None and stock is not None:
            in_stock = stock > 0
        if in_stock:
            matches.append("product is in stock")
        elif in_stock is False or strict_missing:
            failures.append("product is not confirmed in stock")

    if constraints.anc_required is not None:
        anc = _first_bool(values, "anc", "active_noise_cancellation", "active noise cancellation")
        if anc is constraints.anc_required:
            matches.append(f"ANC={constraints.anc_required}")
        elif anc is None and not strict_missing:
            pass
        else:
            expected = "supported" if constraints.anc_required else "not supported"
            failures.append(f"ANC requirement not met; expected {expected}")

    if constraints.min_battery_hours is not None:
        battery = _first_number(
            values,
            "battery_life_hours",
            "total_battery_life_hours",
            "battery_hours",
            "battery life hours",
        )
        if battery is None:
            battery = _extract_hours(_text(values.get("text")))
        if battery is None:
            if strict_missing:
                failures.append("battery life is unavailable")
        elif battery < constraints.min_battery_hours:
            failures.append(
                f"battery life {battery:g} hours is below {constraints.min_battery_hours:g} hours"
            )
        else:
            matches.append(f"battery life={battery:g} hours")

    if constraints.size:
        sizes = _available_sizes(values)
        required = _normalize_size(constraints.size)
        if required in sizes:
            matches.append(f"size={constraints.size}")
        elif sizes or strict_missing:
            failures.append(f"size {constraints.size!r} is unavailable")

    return FilterDecision(
        accepted=not failures,
        reasons=failures,
        matched_constraints=matches,
    )


def apply_post_filters(
    items: Iterable[T],
    constraints: QueryConstraints,
    *,
    strict_missing: bool = True,
    limit: int | None = None,
) -> list[T]:
    """Filter SearchResult objects, mappings, or objects with metadata."""
    if limit is not None and limit <= 0:
        raise FilterError("limit must be greater than zero")
    output: list[T] = []
    for item in items:
        metadata = _metadata_from_item(item)
        decision = evaluate_metadata(metadata, constraints, strict_missing=strict_missing)
        if decision.accepted:
            output.append(item)
            if limit is not None and len(output) >= limit:
                break
    return output


def filter_results(
    results: Iterable[SearchResult],
    plan: FilterPlan,
) -> tuple[list[SearchResult], dict[str, Any]]:
    """Apply a plan and return accepted results with an audit summary."""
    result_list = list(results)
    accepted: list[SearchResult] = []
    rejected: list[dict[str, Any]] = []

    should_filter_products = plan.query_type in {
        "product_factual_lookup",
        "comparative_recommendation",
    }
    for result in result_list:
        if not should_filter_products or result.metadata.get("source_type") != "catalogue":
            accepted.append(result)
            continue
        decision = evaluate_metadata(
            {**result.metadata, "text": result.text},
            plan.post_constraints,
            strict_missing=plan.strict_product_constraints,
        )
        if decision.accepted:
            accepted.append(result)
        else:
            rejected.append(
                {
                    "id": result.id,
                    "product_id": result.metadata.get("product_id"),
                    "reasons": decision.reasons,
                }
            )

    accepted = accepted[: plan.retrieval_limit]
    audit = {
        "retrieved": len(result_list),
        "accepted": len(accepted),
        "rejected": len(rejected),
        "rejections": rejected,
        "pre_filter_sql": plan.where,
    }
    return accepted, audit


def _metadata_from_item(item: Any) -> Mapping[str, Any]:
    if isinstance(item, SearchResult):
        return {**item.metadata, "text": item.text}
    if isinstance(item, Mapping):
        if isinstance(item.get("metadata"), Mapping):
            return {**item["metadata"], "text": item.get("text", "")}
        return item
    metadata = getattr(item, "metadata", None)
    if isinstance(metadata, Mapping):
        return {**metadata, "text": getattr(item, "text", "")}
    raise FilterError(f"cannot extract metadata from {type(item).__name__}")


def _flatten_metadata(metadata: Mapping[str, Any]) -> dict[str, Any]:
    values = dict(metadata)
    for key in ("metadata_json", "specifications_json", "specifications", "attributes"):
        nested = values.get(key)
        if isinstance(nested, str):
            try:
                nested = json.loads(nested)
            except json.JSONDecodeError:
                continue
        if isinstance(nested, Mapping):
            for nested_key, nested_value in nested.items():
                values.setdefault(str(nested_key), nested_value)
                values.setdefault(str(nested_key).casefold(), nested_value)
    return values


def _compare_number(
    values: Mapping[str, Any],
    field: str,
    expected: float | None,
    operation: str,
    failures: list[str],
    matches: list[str],
    strict_missing: bool,
) -> None:
    if expected is None:
        return
    actual = _number(values.get(field))
    if actual is None:
        if strict_missing:
            failures.append(f"missing numeric {field}")
        return
    valid = actual <= expected if operation == "max" else actual >= expected
    if valid:
        symbol = "<=" if operation == "max" else ">="
        matches.append(f"{field} {symbol} {expected:g}")
    else:
        relation = "above maximum" if operation == "max" else "below minimum"
        failures.append(f"{field}={actual:g} is {relation} {expected:g}")


def _first_bool(values: Mapping[str, Any], *keys: str) -> bool | None:
    for key in keys:
        result = _bool(values.get(key))
        if result is not None:
            return result
    return None


def _first_number(values: Mapping[str, Any], *keys: str) -> float | None:
    for key in keys:
        result = _number(values.get(key))
        if result is not None:
            return result
    return None


def _number(value: Any) -> float | None:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        number = float(value)
        return number if math.isfinite(number) else None
    match = re.search(r"-?\d+(?:\.\d+)?", str(value).replace(",", ""))
    return float(match.group()) if match else None


def _bool(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)) and value in {0, 1}:
        return bool(value)
    if isinstance(value, str):
        normalized = value.strip().casefold()
        if normalized in {"true", "yes", "y", "1", "supported", "available"}:
            return True
        if normalized in {"false", "no", "n", "0", "unsupported", "not available", "none"}:
            return False
    return None


def _text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def _extract_hours(text: str) -> float | None:
    if not text:
        return None
    patterns = (
        r"(?:total\s+)?battery(?:\s+life)?\s*[:=-]?\s*(\d+(?:\.\d+)?)\s*(?:hours?|hrs?)",
        r"(\d+(?:\.\d+)?)\s*(?:hours?|hrs?)\s+(?:total\s+)?battery(?:\s+life)?",
    )
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            return float(match.group(1))
    return None


def _available_sizes(values: Mapping[str, Any]) -> set[str]:
    raw_values: list[Any] = []
    for key in ("size", "sizes", "available_sizes", "size_display"):
        if values.get(key) not in (None, ""):
            raw_values.append(values[key])
    sizes: set[str] = set()
    for value in raw_values:
        if isinstance(value, (list, tuple, set)):
            candidates = value
        else:
            candidates = re.split(r"[,/|]", str(value))
        sizes.update(_normalize_size(str(candidate)) for candidate in candidates if str(candidate).strip())
    return sizes


def _normalize_size(value: str) -> str:
    return re.sub(r"\s+", "", value).upper().replace("SIZE", "")


__all__ = [
    "FilterDecision",
    "FilterError",
    "FilterPlan",
    "QUERY_TYPE_LIMITS",
    "QUERY_TYPE_SOURCE_PREFERENCES",
    "apply_post_filters",
    "build_filter_plan",
    "evaluate_metadata",
    "filter_results",
    "filters_for_source",
]
