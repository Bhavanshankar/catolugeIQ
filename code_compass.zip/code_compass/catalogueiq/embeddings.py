"""Embedding providers and persistent cache for CatalogueIQ.

Supported providers:

* Sentence Transformers for local embeddings, defaulting to
  ``all-MiniLM-L6-v2`` with 384 dimensions.
* OpenAI embeddings, defaulting to ``text-embedding-3-small``.

The module contains no mandatory third-party imports at module import time.
Provider libraries are imported only when their provider is instantiated.
Embeddings can be cached in SQLite by content hash, model, dimensions, and
normalization setting so unchanged catalogue chunks are not re-embedded.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import sqlite3
import struct
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Iterator, Sequence

try:
    from .chunking import Chunk
except ImportError:  # Allows direct execution during development.
    from chunking import Chunk

DEFAULT_SENTENCE_TRANSFORMER_MODEL = "all-MiniLM-L6-v2"
DEFAULT_OPENAI_MODEL = "text-embedding-3-small"
DEFAULT_CACHE_PATH = "storage/embedding_cache.sqlite3"


class EmbeddingError(RuntimeError):
    """Raised when embeddings cannot be generated or validated."""


@dataclass(frozen=True, slots=True)
class EmbeddingConfig:
    """Provider-independent embedding configuration."""

    provider: str = "sentence_transformers"
    model: str = DEFAULT_SENTENCE_TRANSFORMER_MODEL
    dimensions: int | None = None
    batch_size: int = 64
    normalize: bool = True
    cache_enabled: bool = True
    cache_path: str = DEFAULT_CACHE_PATH
    device: str | None = None
    show_progress: bool = False
    max_retries: int = 3
    retry_base_seconds: float = 1.0

    def __post_init__(self) -> None:
        if self.batch_size <= 0:
            raise ValueError("batch_size must be greater than zero")
        if self.dimensions is not None and self.dimensions <= 0:
            raise ValueError("dimensions must be greater than zero")
        if self.max_retries < 0:
            raise ValueError("max_retries cannot be negative")
        if self.retry_base_seconds < 0:
            raise ValueError("retry_base_seconds cannot be negative")


@dataclass(slots=True)
class EmbeddedChunk:
    """A CatalogueIQ chunk with its dense vector."""

    id: str
    text: str
    vector: list[float]
    metadata: dict[str, Any]

    def as_record(self) -> dict[str, Any]:
        """Flatten common metadata into a LanceDB-compatible record."""
        record = {
            "id": self.id,
            "text": self.text,
            "vector": self.vector,
            **self.metadata,
        }
        record["id"] = self.id
        return record


class EmbeddingProvider(ABC):
    """Interface implemented by all embedding providers."""

    provider_name: str
    model_name: str
    dimensions: int | None
    normalize: bool

    @abstractmethod
    def embed_texts(self, texts: Sequence[str]) -> list[list[float]]:
        """Embed texts while preserving input order."""

    def embed_query(self, query: str) -> list[float]:
        """Embed one search query with the same model settings."""
        if not query or not query.strip():
            raise EmbeddingError("query cannot be empty")
        vectors = self.embed_texts([query])
        return vectors[0]

    @property
    def cache_namespace(self) -> str:
        """Return a stable namespace for cache isolation."""
        return "|".join(
            [
                self.provider_name,
                self.model_name,
                str(self.dimensions or "native"),
                f"normalize={self.normalize}",
            ]
        )


class SentenceTransformerProvider(EmbeddingProvider):
    """Local Sentence Transformers embedding provider."""

    provider_name = "sentence_transformers"

    def __init__(
        self,
        model_name: str = DEFAULT_SENTENCE_TRANSFORMER_MODEL,
        *,
        device: str | None = None,
        normalize: bool = True,
        batch_size: int = 64,
        show_progress: bool = False,
    ) -> None:
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as exc:
            raise EmbeddingError(
                "Sentence Transformers is not installed. Run: "
                "pip install sentence-transformers"
            ) from exc

        self.model_name = model_name
        self.normalize = normalize
        self.batch_size = batch_size
        self.show_progress = show_progress
        try:
            self._model = SentenceTransformer(model_name, device=device)
            self.dimensions = int(self._model.get_sentence_embedding_dimension())
        except Exception as exc:  # Model loading may involve local files or a hub.
            raise EmbeddingError(f"Unable to load embedding model {model_name!r}: {exc}") from exc

    def embed_texts(self, texts: Sequence[str]) -> list[list[float]]:
        cleaned = _validate_texts(texts)
        if not cleaned:
            return []
        try:
            values = self._model.encode(
                cleaned,
                batch_size=self.batch_size,
                show_progress_bar=self.show_progress,
                normalize_embeddings=self.normalize,
                convert_to_numpy=True,
            )
        except Exception as exc:
            raise EmbeddingError(f"Sentence Transformers embedding failed: {exc}") from exc
        vectors = [[float(value) for value in row] for row in values]
        _validate_vectors(vectors, len(cleaned), self.dimensions)
        return vectors


class OpenAIEmbeddingProvider(EmbeddingProvider):
    """OpenAI embedding provider with batching and retry support."""

    provider_name = "openai"

    def __init__(
        self,
        model_name: str = DEFAULT_OPENAI_MODEL,
        *,
        dimensions: int | None = None,
        api_key: str | None = None,
        batch_size: int = 64,
        normalize: bool = True,
        max_retries: int = 3,
        retry_base_seconds: float = 1.0,
        client: Any | None = None,
    ) -> None:
        try:
            from openai import OpenAI
        except ImportError as exc:
            raise EmbeddingError("OpenAI is not installed. Run: pip install openai") from exc

        self.model_name = model_name
        self.dimensions = dimensions
        self.batch_size = batch_size
        self.normalize = normalize
        self.max_retries = max_retries
        self.retry_base_seconds = retry_base_seconds
        self._client = client or OpenAI(api_key=api_key or os.getenv("OPENAI_API_KEY"))

    def _request(self, batch: Sequence[str]) -> list[list[float]]:
        request: dict[str, Any] = {
            "model": self.model_name,
            "input": list(batch),
            "encoding_format": "float",
        }
        if self.dimensions is not None:
            request["dimensions"] = self.dimensions

        last_error: Exception | None = None
        for attempt in range(self.max_retries + 1):
            try:
                response = self._client.embeddings.create(**request)
                ordered = sorted(response.data, key=lambda item: item.index)
                vectors = [[float(value) for value in item.embedding] for item in ordered]
                if self.normalize:
                    vectors = [_l2_normalize(vector) for vector in vectors]
                return vectors
            except Exception as exc:
                last_error = exc
                if attempt >= self.max_retries:
                    break
                time.sleep(self.retry_base_seconds * (2**attempt))
        raise EmbeddingError(f"OpenAI embedding request failed: {last_error}")

    def embed_texts(self, texts: Sequence[str]) -> list[list[float]]:
        cleaned = _validate_texts(texts)
        vectors: list[list[float]] = []
        for batch in _batched(cleaned, self.batch_size):
            vectors.extend(self._request(batch))
        expected_dimensions = self.dimensions or (len(vectors[0]) if vectors else None)
        if self.dimensions is None and expected_dimensions is not None:
            self.dimensions = expected_dimensions
        _validate_vectors(vectors, len(cleaned), expected_dimensions)
        return vectors


class EmbeddingCache:
    """SQLite cache for dense vectors.

    Vectors are stored as little-endian 32-bit floats, reducing cache size
    compared with JSON while retaining sufficient precision for retrieval.
    """

    def __init__(self, path: str | Path = DEFAULT_CACHE_PATH) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._connection = sqlite3.connect(self.path)
        self._connection.execute("PRAGMA journal_mode=WAL")
        self._connection.execute(
            """
            CREATE TABLE IF NOT EXISTS embeddings (
                cache_key TEXT PRIMARY KEY,
                namespace TEXT NOT NULL,
                content_hash TEXT NOT NULL,
                dimensions INTEGER NOT NULL,
                vector BLOB NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        self._connection.execute(
            "CREATE INDEX IF NOT EXISTS idx_embeddings_namespace "
            "ON embeddings(namespace)"
        )
        self._connection.commit()

    def close(self) -> None:
        self._connection.close()

    def __enter__(self) -> "EmbeddingCache":
        return self

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        self.close()

    @staticmethod
    def make_key(namespace: str, text: str) -> tuple[str, str]:
        content_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()
        cache_key = hashlib.sha256(f"{namespace}|{content_hash}".encode("utf-8")).hexdigest()
        return cache_key, content_hash

    def get_many(self, namespace: str, texts: Sequence[str]) -> dict[int, list[float]]:
        keys = [self.make_key(namespace, text)[0] for text in texts]
        if not keys:
            return {}
        output: dict[int, list[float]] = {}
        key_to_indexes: dict[str, list[int]] = {}
        for index, key in enumerate(keys):
            key_to_indexes.setdefault(key, []).append(index)
        for key_batch in _batched(list(key_to_indexes), 500):
            placeholders = ",".join("?" for _ in key_batch)
            query = f"SELECT cache_key, dimensions, vector FROM embeddings WHERE cache_key IN ({placeholders})"
            for cache_key, dimensions, blob in self._connection.execute(query, key_batch):
                vector = list(struct.unpack(f"<{dimensions}f", blob))
                for index in key_to_indexes[cache_key]:
                    output[index] = vector
        return output

    def set_many(
        self,
        namespace: str,
        texts: Sequence[str],
        vectors: Sequence[Sequence[float]],
    ) -> None:
        if len(texts) != len(vectors):
            raise EmbeddingError("cache text and vector counts do not match")
        rows = []
        for text, vector in zip(texts, vectors):
            cache_key, content_hash = self.make_key(namespace, text)
            values = [float(value) for value in vector]
            blob = struct.pack(f"<{len(values)}f", *values)
            rows.append((cache_key, namespace, content_hash, len(values), blob))
        self._connection.executemany(
            """
            INSERT INTO embeddings(cache_key, namespace, content_hash, dimensions, vector)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(cache_key) DO UPDATE SET
                namespace=excluded.namespace,
                content_hash=excluded.content_hash,
                dimensions=excluded.dimensions,
                vector=excluded.vector,
                created_at=CURRENT_TIMESTAMP
            """,
            rows,
        )
        self._connection.commit()

    def count(self, namespace: str | None = None) -> int:
        if namespace is None:
            row = self._connection.execute("SELECT COUNT(*) FROM embeddings").fetchone()
        else:
            row = self._connection.execute(
                "SELECT COUNT(*) FROM embeddings WHERE namespace = ?", (namespace,)
            ).fetchone()
        return int(row[0]) if row else 0

    def clear(self, namespace: str | None = None) -> int:
        if namespace is None:
            cursor = self._connection.execute("DELETE FROM embeddings")
        else:
            cursor = self._connection.execute(
                "DELETE FROM embeddings WHERE namespace = ?", (namespace,)
            )
        self._connection.commit()
        return max(cursor.rowcount, 0)


def create_embedding_provider(config: EmbeddingConfig) -> EmbeddingProvider:
    """Create a configured embedding provider."""
    provider = config.provider.strip().lower().replace("-", "_")
    if provider in {"sentence_transformers", "sentence_transformer", "local"}:
        return SentenceTransformerProvider(
            model_name=config.model,
            device=config.device,
            normalize=config.normalize,
            batch_size=config.batch_size,
            show_progress=config.show_progress,
        )
    if provider == "openai":
        return OpenAIEmbeddingProvider(
            model_name=config.model,
            dimensions=config.dimensions,
            batch_size=config.batch_size,
            normalize=config.normalize,
            max_retries=config.max_retries,
            retry_base_seconds=config.retry_base_seconds,
        )
    raise EmbeddingError(f"Unsupported embedding provider: {config.provider!r}")


def embed_texts_cached(
    texts: Sequence[str],
    provider: EmbeddingProvider,
    *,
    cache: EmbeddingCache | None = None,
) -> tuple[list[list[float]], dict[str, int]]:
    """Embed texts in order, reusing cached vectors when available."""
    cleaned = _validate_texts(texts)
    if not cleaned:
        return [], {"requested": 0, "cache_hits": 0, "embedded": 0}

    cached = cache.get_many(provider.cache_namespace, cleaned) if cache else {}
    output: list[list[float] | None] = [None] * len(cleaned)
    missing_indexes: list[int] = []
    for index in range(len(cleaned)):
        if index in cached:
            output[index] = cached[index]
        else:
            missing_indexes.append(index)

    if missing_indexes:
        missing_texts = [cleaned[index] for index in missing_indexes]
        new_vectors = provider.embed_texts(missing_texts)
        _validate_vectors(new_vectors, len(missing_texts), provider.dimensions)
        for index, vector in zip(missing_indexes, new_vectors):
            output[index] = vector
        if cache:
            cache.set_many(provider.cache_namespace, missing_texts, new_vectors)

    vectors = [vector for vector in output if vector is not None]
    _validate_vectors(vectors, len(cleaned), provider.dimensions)
    return vectors, {
        "requested": len(cleaned),
        "cache_hits": len(cleaned) - len(missing_indexes),
        "embedded": len(missing_indexes),
    }


def embed_chunks(
    chunks: Iterable[Chunk],
    provider: EmbeddingProvider,
    *,
    cache: EmbeddingCache | None = None,
) -> tuple[list[EmbeddedChunk], dict[str, int]]:
    """Embed CatalogueIQ chunks and attach embedding metadata."""
    chunk_list = list(chunks)
    texts = [chunk.text for chunk in chunk_list]
    vectors, statistics = embed_texts_cached(texts, provider, cache=cache)
    embedded: list[EmbeddedChunk] = []
    for chunk, vector in zip(chunk_list, vectors):
        metadata = dict(chunk.metadata)
        metadata.update(
            {
                "embedding_provider": provider.provider_name,
                "embedding_model": provider.model_name,
                "embedding_dimensions": len(vector),
                "embeddings_normalized": provider.normalize,
            }
        )
        embedded.append(
            EmbeddedChunk(
                id=chunk.id,
                text=chunk.text,
                vector=vector,
                metadata=metadata,
            )
        )
    statistics["output_chunks"] = len(embedded)
    return embedded, statistics


def embed_chunks_from_config(
    chunks: Iterable[Chunk],
    config: EmbeddingConfig,
) -> tuple[list[EmbeddedChunk], dict[str, int]]:
    """Convenience entry point that creates the provider and optional cache."""
    provider = create_embedding_provider(config)
    if not config.cache_enabled:
        return embed_chunks(chunks, provider)
    with EmbeddingCache(config.cache_path) as cache:
        return embed_chunks(chunks, provider, cache=cache)


def _validate_texts(texts: Sequence[str]) -> list[str]:
    cleaned: list[str] = []
    for index, text in enumerate(texts):
        if not isinstance(text, str):
            raise EmbeddingError(f"text at index {index} is not a string")
        value = text.strip()
        if not value:
            raise EmbeddingError(f"text at index {index} is empty")
        cleaned.append(value)
    return cleaned


def _validate_vectors(
    vectors: Sequence[Sequence[float]],
    expected_count: int,
    expected_dimensions: int | None,
) -> None:
    if len(vectors) != expected_count:
        raise EmbeddingError(
            f"expected {expected_count} vectors but received {len(vectors)}"
        )
    dimensions = expected_dimensions
    for index, vector in enumerate(vectors):
        if dimensions is None:
            dimensions = len(vector)
        if len(vector) != dimensions:
            raise EmbeddingError(
                f"vector {index} has {len(vector)} dimensions; expected {dimensions}"
            )
        if not all(math.isfinite(float(value)) for value in vector):
            raise EmbeddingError(f"vector {index} contains a non-finite value")


def _l2_normalize(vector: Sequence[float]) -> list[float]:
    norm = math.sqrt(sum(float(value) ** 2 for value in vector))
    if norm == 0:
        raise EmbeddingError("cannot normalize a zero-length vector")
    return [float(value) / norm for value in vector]


def _batched(values: Sequence[Any], size: int) -> Iterator[list[Any]]:
    if size <= 0:
        raise ValueError("batch size must be greater than zero")
    for start in range(0, len(values), size):
        yield list(values[start : start + size])


__all__ = [
    "DEFAULT_CACHE_PATH",
    "DEFAULT_OPENAI_MODEL",
    "DEFAULT_SENTENCE_TRANSFORMER_MODEL",
    "EmbeddedChunk",
    "EmbeddingCache",
    "EmbeddingConfig",
    "EmbeddingError",
    "EmbeddingProvider",
    "OpenAIEmbeddingProvider",
    "SentenceTransformerProvider",
    "create_embedding_provider",
    "embed_chunks",
    "embed_chunks_from_config",
    "embed_texts_cached",
]
