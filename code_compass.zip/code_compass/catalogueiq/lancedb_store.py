"""LanceDB persistence and retrieval for CatalogueIQ.

This module stores :class:`EmbeddedChunk` records in a local or cloud-backed
LanceDB table and exposes vector, full-text, hybrid, and metadata-filtered
search helpers.

Embeddings are generated outside this module. This keeps storage independent
from the selected Sentence Transformers or OpenAI embedding provider.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

try:
    from .embeddings import EmbeddedChunk, EmbeddingProvider
except ImportError:  # Direct module execution during development.
    from embeddings import EmbeddedChunk, EmbeddingProvider

DEFAULT_URI = "./storage/lancedb"
DEFAULT_TABLE = "knowledge_chunks"
DEFAULT_DISTANCE_TYPE = "cosine"

# Stable columns keep one LanceDB schema across mixed product, review, FAQ,
# policy, seller-guide, and category-guide records.
SCHEMA_DEFAULTS: dict[str, Any] = {
    "id": "",
    "text": "",
    "vector": [],
    "source": "",
    "source_path": "",
    "source_type": "",
    "chunk_type": "",
    "section": "",
    "product_id": "",
    "product_name": "",
    "review_summary_id": "",
    "faq_id": "",
    "document_id": "",
    "brand": "",
    "category": "",
    "subcategory": "",
    "seller_id": "",
    "availability": "",
    "price_inr": None,
    "mrp_inr": None,
    "rating": None,
    "review_count": None,
    "seller_verified": None,
    "stock_quantity": None,
    "warranty_months": None,
    "returnable": None,
    "return_window_days": None,
    "chunk_index": None,
    "source_chunk_index": None,
    "character_count": None,
    "word_count": None,
    "content_hash": "",
    "chunking_strategy": "",
    "embedding_provider": "",
    "embedding_model": "",
    "embedding_dimensions": None,
    "embeddings_normalized": None,
    "persona_scope": "",
    "metadata_json": "{}",
}
KNOWN_COLUMNS = frozenset(SCHEMA_DEFAULTS)


class LanceDBStoreError(RuntimeError):
    """Raised for invalid data, filters, or LanceDB operations."""


@dataclass(frozen=True, slots=True)
class LanceDBConfig:
    """Connection and table configuration."""

    uri: str = DEFAULT_URI
    table_name: str = DEFAULT_TABLE
    distance_type: str = DEFAULT_DISTANCE_TYPE
    api_key: str | None = None
    region: str | None = None

    def __post_init__(self) -> None:
        if not self.uri.strip():
            raise ValueError("uri cannot be empty")
        if not self.table_name.strip():
            raise ValueError("table_name cannot be empty")
        if self.distance_type not in {"cosine", "l2", "dot"}:
            raise ValueError("distance_type must be cosine, l2, or dot")


@dataclass(frozen=True, slots=True)
class SearchFilters:
    """Safe, typed filters for CatalogueIQ retrieval."""

    category: str | None = None
    subcategory: str | None = None
    source_type: str | None = None
    chunk_type: str | None = None
    brand: str | None = None
    product_id: str | None = None
    seller_id: str | None = None
    availability: str | None = None
    max_price: float | None = None
    min_price: float | None = None
    min_rating: float | None = None
    seller_verified: bool | None = None
    returnable: bool | None = None

    def to_sql(self) -> str | None:
        conditions: list[str] = []
        equals = {
            "category": self.category,
            "subcategory": self.subcategory,
            "source_type": self.source_type,
            "chunk_type": self.chunk_type,
            "brand": self.brand,
            "product_id": self.product_id,
            "seller_id": self.seller_id,
            "availability": self.availability,
        }
        for column, value in equals.items():
            if value is not None:
                conditions.append(f"{column} = {_sql_literal(value)}")
        if self.max_price is not None:
            conditions.append(f"price_inr <= {float(self.max_price)}")
        if self.min_price is not None:
            conditions.append(f"price_inr >= {float(self.min_price)}")
        if self.min_rating is not None:
            conditions.append(f"rating >= {float(self.min_rating)}")
        if self.seller_verified is not None:
            conditions.append(f"seller_verified = {_sql_literal(self.seller_verified)}")
        if self.returnable is not None:
            conditions.append(f"returnable = {_sql_literal(self.returnable)}")
        return " AND ".join(conditions) or None


@dataclass(slots=True)
class SearchResult:
    """Normalized search result returned to the retriever layer."""

    id: str
    text: str
    metadata: dict[str, Any]
    distance: float | None = None
    score: float | None = None
    relevance_score: float | None = None

    @classmethod
    def from_record(cls, record: Mapping[str, Any]) -> "SearchResult":
        reserved = {"id", "text", "vector", "_distance", "_score", "_relevance_score"}
        metadata = {key: value for key, value in record.items() if key not in reserved}
        extra = metadata.pop("metadata_json", None)
        if isinstance(extra, str) and extra:
            try:
                decoded = json.loads(extra)
                if isinstance(decoded, dict):
                    for key, value in decoded.items():
                        metadata.setdefault(key, value)
            except json.JSONDecodeError:
                pass
        return cls(
            id=str(record.get("id", "")),
            text=str(record.get("text", "")),
            metadata=metadata,
            distance=_optional_float(record.get("_distance")),
            score=_optional_float(record.get("_score")),
            relevance_score=_optional_float(record.get("_relevance_score")),
        )

    def citation(self) -> str:
        source = self.metadata.get("source", "unknown")
        if self.metadata.get("product_id"):
            return f"[Source: {source} | Product ID: {self.metadata['product_id']}]"
        if self.metadata.get("faq_id"):
            return (
                f"[Source: {source} | Section: {self.metadata.get('section', 'Buyer FAQ')} "
                f"| FAQ: {self.metadata['faq_id']}]"
            )
        return f"[Source: {source} | Section: {self.metadata.get('section', 'Document')}]"


class LanceDBStore:
    """CatalogueIQ storage facade around the synchronous LanceDB API."""

    def __init__(self, config: LanceDBConfig | None = None) -> None:
        self.config = config or LanceDBConfig()
        try:
            import lancedb
        except ImportError as exc:
            raise LanceDBStoreError("LanceDB is not installed. Run: pip install lancedb") from exc

        connect_kwargs: dict[str, Any] = {}
        if self.config.api_key:
            connect_kwargs["api_key"] = self.config.api_key
        if self.config.region:
            connect_kwargs["region"] = self.config.region
        try:
            if not self.config.uri.startswith("db://"):
                Path(self.config.uri).expanduser().mkdir(parents=True, exist_ok=True)
            self.db = lancedb.connect(self.config.uri, **connect_kwargs)
        except Exception as exc:
            raise LanceDBStoreError(f"Unable to connect to LanceDB: {exc}") from exc

    def table_exists(self) -> bool:
        return self.config.table_name in self.db.table_names()

    def open_table(self) -> Any:
        if not self.table_exists():
            raise LanceDBStoreError(f"Table {self.config.table_name!r} does not exist")
        return self.db.open_table(self.config.table_name)

    def create_or_replace(self, chunks: Iterable[EmbeddedChunk]) -> int:
        """Create the table or replace it with embedded chunks."""
        records = self._prepare_records(chunks)
        if not records:
            raise LanceDBStoreError("cannot create a LanceDB table with no records")
        try:
            self.db.create_table(self.config.table_name, data=records, mode="overwrite")
        except Exception as exc:
            raise LanceDBStoreError(f"Unable to create table: {exc}") from exc
        return len(records)

    def append(self, chunks: Iterable[EmbeddedChunk]) -> int:
        """Append chunks to an existing table."""
        records = self._prepare_records(chunks)
        if not records:
            return 0
        if not self.table_exists():
            return self.create_or_replace_records(records)
        try:
            self.open_table().add(records)
        except Exception as exc:
            raise LanceDBStoreError(f"Unable to append records: {exc}") from exc
        return len(records)

    def create_or_replace_records(self, records: Sequence[dict[str, Any]]) -> int:
        if not records:
            raise LanceDBStoreError("cannot create a table with no records")
        self.db.create_table(self.config.table_name, data=list(records), mode="overwrite")
        return len(records)

    def upsert(self, chunks: Iterable[EmbeddedChunk]) -> int:
        """Replace records with matching IDs, then add current versions."""
        records = self._prepare_records(chunks)
        if not records:
            return 0
        if not self.table_exists():
            return self.create_or_replace_records(records)
        table = self.open_table()
        ids = [record["id"] for record in records]
        try:
            for batch in _batched(ids, 200):
                table.delete(f"id IN ({', '.join(_sql_literal(value) for value in batch)})")
            table.add(records)
        except Exception as exc:
            raise LanceDBStoreError(f"Unable to upsert records: {exc}") from exc
        return len(records)

    def count(self, where: str | None = None) -> int:
        table = self.open_table()
        try:
            return int(table.count_rows(where)) if where else int(table.count_rows())
        except Exception as exc:
            raise LanceDBStoreError(f"Unable to count rows: {exc}") from exc

    def delete(self, filters: SearchFilters | None = None, *, where: str | None = None) -> None:
        expression = where or (filters.to_sql() if filters else None)
        if not expression:
            raise LanceDBStoreError("delete requires a filter expression")
        try:
            self.open_table().delete(expression)
        except Exception as exc:
            raise LanceDBStoreError(f"Unable to delete records: {exc}") from exc

    def vector_search(
        self,
        query_vector: Sequence[float],
        *,
        limit: int = 8,
        filters: SearchFilters | None = None,
        where: str | None = None,
        select: Sequence[str] | None = None,
    ) -> list[SearchResult]:
        """Run dense search with optional metadata pre-filtering."""
        _validate_limit(limit)
        if not query_vector:
            raise LanceDBStoreError("query_vector cannot be empty")
        try:
            query = self.open_table().search(list(map(float, query_vector)))
            if hasattr(query, "distance_type"):
                query = query.distance_type(self.config.distance_type)
            expression = where or (filters.to_sql() if filters else None)
            if expression:
                query = query.where(expression, prefilter=True)
            if select:
                query = query.select(list(select))
            records = query.limit(limit).to_list()
            return [SearchResult.from_record(record) for record in records]
        except Exception as exc:
            raise LanceDBStoreError(f"Vector search failed: {exc}") from exc

    def text_search(
        self,
        query_text: str,
        *,
        limit: int = 8,
        filters: SearchFilters | None = None,
        where: str | None = None,
    ) -> list[SearchResult]:
        """Run BM25 full-text search on the indexed text column."""
        _validate_query(query_text, limit)
        try:
            query = self.open_table().search(query_text, query_type="fts", fts_columns="text")
            expression = where or (filters.to_sql() if filters else None)
            if expression:
                query = query.where(expression, prefilter=True)
            records = query.limit(limit).to_list()
            return [SearchResult.from_record(record) for record in records]
        except Exception as exc:
            raise LanceDBStoreError(f"Full-text search failed: {exc}") from exc

    def hybrid_search(
        self,
        query_text: str,
        query_vector: Sequence[float] | None = None,
        *,
        limit: int = 8,
        filters: SearchFilters | None = None,
        where: str | None = None,
        reranker: Any | None = None,
    ) -> list[SearchResult]:
        """Run LanceDB hybrid search with vector and BM25 retrieval.

        LanceDB versions differ slightly in hybrid builder signatures, so the
        method tries the current query/vector form and then a text-only form
        suitable when the table owns an embedding function.
        """
        _validate_query(query_text, limit)
        table = self.open_table()
        expression = where or (filters.to_sql() if filters else None)
        errors: list[str] = []
        attempts: list[dict[str, Any]] = []
        if query_vector is not None:
            attempts.append({"query": query_text, "vector_column_name": "vector", "query_type": "hybrid", "vector": list(map(float, query_vector))})
        attempts.append({"query": query_text, "query_type": "hybrid"})

        for parameters in attempts:
            try:
                vector = parameters.pop("vector", None)
                if vector is not None:
                    query = table.search(vector, query_type="hybrid")
                    if hasattr(query, "nearest_to_text"):
                        query = query.nearest_to_text(query_text, columns="text")
                else:
                    query = table.search(query_text, query_type="hybrid")
                if expression:
                    query = query.where(expression, prefilter=True)
                if reranker is not None and hasattr(query, "rerank"):
                    query = query.rerank(reranker)
                records = query.limit(limit).to_list()
                return [SearchResult.from_record(record) for record in records]
            except Exception as exc:
                errors.append(str(exc))
        raise LanceDBStoreError("Hybrid search failed: " + " | ".join(errors))

    def search_with_provider(
        self,
        query_text: str,
        provider: EmbeddingProvider,
        *,
        query_type: str = "vector",
        limit: int = 8,
        filters: SearchFilters | None = None,
    ) -> list[SearchResult]:
        """Embed a query and dispatch to vector, full-text, or hybrid search."""
        normalized = query_type.strip().lower()
        if normalized == "fts":
            return self.text_search(query_text, limit=limit, filters=filters)
        vector = provider.embed_query(query_text)
        if normalized == "vector":
            return self.vector_search(vector, limit=limit, filters=filters)
        if normalized == "hybrid":
            return self.hybrid_search(
                query_text, vector, limit=limit, filters=filters
            )
        raise LanceDBStoreError(f"Unsupported query_type: {query_type!r}")

    def create_fts_index(self, *, replace: bool = True) -> None:
        """Create a full-text index over the text column."""
        table = self.open_table()
        try:
            table.create_fts_index("text", replace=replace)
        except TypeError:
            # Compatibility with releases that do not expose replace.
            table.create_fts_index("text")
        except Exception as exc:
            raise LanceDBStoreError(f"Unable to create FTS index: {exc}") from exc

    def create_vector_index(
        self,
        *,
        index_type: str = "IVF_PQ",
        num_partitions: int | None = None,
        num_sub_vectors: int | None = None,
        replace: bool = True,
    ) -> None:
        """Create an ANN index. Exact search remains suitable for small data."""
        kwargs: dict[str, Any] = {
            "metric": self.config.distance_type,
            "vector_column_name": "vector",
            "index_type": index_type,
            "replace": replace,
        }
        if num_partitions is not None:
            kwargs["num_partitions"] = num_partitions
        if num_sub_vectors is not None:
            kwargs["num_sub_vectors"] = num_sub_vectors
        try:
            self.open_table().create_index(**kwargs)
        except Exception as exc:
            raise LanceDBStoreError(f"Unable to create vector index: {exc}") from exc

    def optimize(self) -> Any:
        """Compact table fragments and update indexes after appends."""
        try:
            return self.open_table().optimize()
        except Exception as exc:
            raise LanceDBStoreError(f"Unable to optimize table: {exc}") from exc

    def _prepare_records(self, chunks: Iterable[EmbeddedChunk]) -> list[dict[str, Any]]:
        chunks_list = list(chunks)
        if not chunks_list:
            return []
        dimensions = len(chunks_list[0].vector)
        if dimensions <= 0:
            raise LanceDBStoreError("vectors cannot be empty")
        records = []
        ids: set[str] = set()
        for chunk in chunks_list:
            if not chunk.id or not chunk.text.strip():
                raise LanceDBStoreError("every chunk requires a non-empty id and text")
            if chunk.id in ids:
                raise LanceDBStoreError(f"duplicate chunk id: {chunk.id}")
            ids.add(chunk.id)
            if len(chunk.vector) != dimensions:
                raise LanceDBStoreError("all vectors must use the same dimensions")
            records.append(_normalize_record(chunk))
        return records


def _normalize_record(chunk: EmbeddedChunk) -> dict[str, Any]:
    metadata = dict(chunk.metadata)
    record = dict(SCHEMA_DEFAULTS)
    record["id"] = chunk.id
    record["text"] = chunk.text
    record["vector"] = [float(value) for value in chunk.vector]

    extras: dict[str, Any] = {}
    for key, value in metadata.items():
        if key in KNOWN_COLUMNS and key not in {"id", "text", "vector", "metadata_json"}:
            record[key] = _normalize_value(value, SCHEMA_DEFAULTS[key])
        else:
            extras[key] = value
    persona = record.get("persona_scope")
    if isinstance(persona, (list, tuple, set)):
        record["persona_scope"] = ",".join(map(str, persona))
    record["metadata_json"] = json.dumps(extras, ensure_ascii=False, sort_keys=True, default=str)
    return record


def _normalize_value(value: Any, default: Any) -> Any:
    if value is None:
        return default
    if isinstance(default, str):
        if isinstance(value, (dict, list, tuple, set)):
            return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
        return str(value)
    if isinstance(default, bool):
        return bool(value)
    if isinstance(default, int):
        return int(value)
    if isinstance(default, float):
        return float(value)
    return value


def _sql_literal(value: Any) -> str:
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return str(value)
    return "'" + str(value).replace("'", "''") + "'"


def _optional_float(value: Any) -> float | None:
    try:
        return float(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _validate_limit(limit: int) -> None:
    if limit <= 0:
        raise LanceDBStoreError("limit must be greater than zero")


def _validate_query(query_text: str, limit: int) -> None:
    _validate_limit(limit)
    if not query_text or not query_text.strip():
        raise LanceDBStoreError("query_text cannot be empty")


def _batched(values: Sequence[Any], size: int) -> Iterable[list[Any]]:
    for start in range(0, len(values), size):
        yield list(values[start : start + size])


__all__ = [
    "DEFAULT_DISTANCE_TYPE",
    "DEFAULT_TABLE",
    "DEFAULT_URI",
    "KNOWN_COLUMNS",
    "LanceDBConfig",
    "LanceDBStore",
    "LanceDBStoreError",
    "SCHEMA_DEFAULTS",
    "SearchFilters",
    "SearchResult",
]
