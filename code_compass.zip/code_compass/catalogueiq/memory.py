"""Conversation memory for CatalogueIQ.

The module provides session-scoped memory for Shopper, Seller, and Support
Agent conversations without requiring LangChain. It keeps a configurable
window of recent turns, extracts safe shopping preferences and constraints,
and creates retrieval-aware follow-up queries.

Important design rule: memory preserves conversational context, but it is not
an authoritative source for product facts or policy rules. Every turn must
still retrieve fresh evidence from the ShopSmart India knowledge base.
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from threading import RLock
from typing import Any, Iterable, Mapping
from uuid import uuid4

DEFAULT_MEMORY_TURNS = 5
SUPPORTED_ROLES = frozenset({"user", "assistant", "system"})
SUPPORTED_PERSONAS = frozenset({"shopper", "seller", "support_agent"})


class MemoryError(ValueError):
    """Raised when conversation memory input is invalid."""


@dataclass(slots=True)
class ConversationTurn:
    """One message in a CatalogueIQ session."""

    role: str
    content: str
    timestamp: float = field(default_factory=time.time)
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.role = self.role.strip().lower()
        self.content = self.content.strip()
        if self.role not in SUPPORTED_ROLES:
            raise MemoryError(f"Unsupported role: {self.role!r}")
        if not self.content:
            raise MemoryError("Conversation content cannot be empty")

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class SessionPreferences:
    """Session-only preferences and constraints stated by the user."""

    preferred_brands: list[str] = field(default_factory=list)
    excluded_brands: list[str] = field(default_factory=list)
    category: str | None = None
    subcategory: str | None = None
    max_price: float | None = None
    min_rating: float | None = None
    min_battery_hours: float | None = None
    size: str | None = None
    colour: str | None = None
    anc_required: bool | None = None
    verified_seller_required: bool | None = None
    in_stock_required: bool | None = None
    language: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            key: value
            for key, value in asdict(self).items()
            if value not in (None, [], "")
        }

    def merge(self, updates: Mapping[str, Any]) -> None:
        """Merge explicitly detected session updates."""
        for key, value in updates.items():
            if not hasattr(self, key) or value is None:
                continue
            if key in {"preferred_brands", "excluded_brands"}:
                current = list(getattr(self, key))
                additions = value if isinstance(value, list) else [value]
                setattr(self, key, _unique([*current, *map(str, additions)]))
            else:
                setattr(self, key, value)
        # An exclusion takes precedence over a preference within the session.
        excluded = {brand.casefold() for brand in self.excluded_brands}
        self.preferred_brands = [
            brand for brand in self.preferred_brands if brand.casefold() not in excluded
        ]


@dataclass(slots=True)
class ConversationSnapshot:
    """Serializable state for persistence or debugging."""

    session_id: str
    persona: str
    max_turns: int
    turns: list[dict[str, Any]]
    preferences: dict[str, Any]
    summary: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class ConversationMemory:
    """Thread-safe, session-level conversational memory.

    ``max_turns`` refers to user-assistant exchanges. Internally, up to twice
    that number of messages are retained in the recent window.
    """

    def __init__(
        self,
        *,
        session_id: str | None = None,
        persona: str = "shopper",
        max_turns: int = DEFAULT_MEMORY_TURNS,
        known_brands: Iterable[str] = (),
    ) -> None:
        if max_turns < 1:
            raise MemoryError("max_turns must be at least 1")
        normalized_persona = persona.strip().lower().replace(" ", "_")
        if normalized_persona not in SUPPORTED_PERSONAS:
            raise MemoryError(
                "persona must be shopper, seller, or support_agent"
            )
        self.session_id = session_id or str(uuid4())
        self.persona = normalized_persona
        self.max_turns = max_turns
        self.known_brands = tuple(sorted(set(known_brands), key=len, reverse=True))
        self.preferences = SessionPreferences()
        self._turns: list[ConversationTurn] = []
        self._summary = ""
        self._lock = RLock()

    @property
    def turns(self) -> tuple[ConversationTurn, ...]:
        with self._lock:
            return tuple(self._turns)

    @property
    def summary(self) -> str:
        with self._lock:
            return self._summary

    def add_message(
        self,
        role: str,
        content: str,
        *,
        metadata: Mapping[str, Any] | None = None,
    ) -> ConversationTurn:
        """Add one message and update session preferences for user messages."""
        turn = ConversationTurn(role, content, metadata=dict(metadata or {}))
        with self._lock:
            self._turns.append(turn)
            if turn.role == "user":
                updates = extract_preferences(turn.content, self.known_brands)
                self.preferences.merge(updates)
            self._compact_if_needed()
        return turn

    def add_exchange(
        self,
        user_message: str,
        assistant_message: str,
        *,
        user_metadata: Mapping[str, Any] | None = None,
        assistant_metadata: Mapping[str, Any] | None = None,
    ) -> None:
        """Add one complete user-assistant exchange."""
        self.add_message("user", user_message, metadata=user_metadata)
        self.add_message("assistant", assistant_message, metadata=assistant_metadata)

    def recent_messages(self, *, max_messages: int | None = None) -> list[dict[str, str]]:
        """Return recent messages in chat-completion format."""
        with self._lock:
            turns = self._turns[-max_messages:] if max_messages else self._turns
            return [{"role": turn.role, "content": turn.content} for turn in turns]

    def retrieval_query(self, current_query: str) -> str:
        """Build a self-contained retrieval query from follow-up context.

        The result contains only user-stated session context. Product facts and
        policy claims from prior assistant answers are intentionally excluded.
        """
        if not isinstance(current_query, str) or not current_query.strip():
            raise MemoryError("current_query must be a non-empty string")
        current = current_query.strip()
        if not is_follow_up(current):
            return current

        context_parts: list[str] = []
        with self._lock:
            previous_user = next(
                (
                    turn.content
                    for turn in reversed(self._turns)
                    if turn.role == "user" and turn.content != current
                ),
                "",
            )
            if previous_user:
                context_parts.append(f"Previous user request: {previous_user}")
            preference_text = format_preferences(self.preferences)
            if preference_text:
                context_parts.append(f"Session preferences: {preference_text}")
        context_parts.append(f"Current follow-up: {current}")
        return " | ".join(context_parts)

    def prompt_history(self) -> str:
        """Format recent history for a generation prompt.

        This history is conversational context only and must never be treated
        as retrieved evidence or used as a citation source.
        """
        with self._lock:
            lines: list[str] = []
            if self._summary:
                lines.append(f"Earlier conversation summary: {self._summary}")
            for turn in self._turns:
                label = {
                    "user": "User",
                    "assistant": "Assistant",
                    "system": "System",
                }[turn.role]
                lines.append(f"{label}: {turn.content}")
            return "\n".join(lines)

    def clear(self, *, keep_preferences: bool = False) -> None:
        """Clear messages and optionally preserve session preferences."""
        with self._lock:
            self._turns.clear()
            self._summary = ""
            if not keep_preferences:
                self.preferences = SessionPreferences()

    def snapshot(self) -> ConversationSnapshot:
        with self._lock:
            return ConversationSnapshot(
                session_id=self.session_id,
                persona=self.persona,
                max_turns=self.max_turns,
                turns=[turn.as_dict() for turn in self._turns],
                preferences=self.preferences.as_dict(),
                summary=self._summary,
            )

    def save(self, path: str | Path) -> Path:
        """Save session memory as readable JSON."""
        output = Path(path)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(self.snapshot().as_dict(), indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        return output

    @classmethod
    def load(
        cls,
        path: str | Path,
        *,
        known_brands: Iterable[str] = (),
    ) -> "ConversationMemory":
        """Restore a previously saved session."""
        source = Path(path)
        try:
            payload = json.loads(source.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            raise MemoryError(f"Unable to load memory file {source}: {exc}") from exc
        memory = cls(
            session_id=str(payload["session_id"]),
            persona=str(payload["persona"]),
            max_turns=int(payload["max_turns"]),
            known_brands=known_brands,
        )
        memory._summary = str(payload.get("summary", ""))
        for key, value in payload.get("preferences", {}).items():
            if hasattr(memory.preferences, key):
                setattr(memory.preferences, key, value)
        memory._turns = [
            ConversationTurn(
                role=str(item["role"]),
                content=str(item["content"]),
                timestamp=float(item.get("timestamp", time.time())),
                metadata=dict(item.get("metadata", {})),
            )
            for item in payload.get("turns", [])
        ]
        memory._compact_if_needed()
        return memory

    def _compact_if_needed(self) -> None:
        maximum_messages = self.max_turns * 2
        if len(self._turns) <= maximum_messages:
            return
        overflow = self._turns[: len(self._turns) - maximum_messages]
        self._turns = self._turns[-maximum_messages:]
        summary_lines: list[str] = []
        if self._summary:
            summary_lines.append(self._summary)
        for turn in overflow:
            # Earlier user intent is retained. Assistant claims are omitted to
            # avoid turning generated text into authoritative memory.
            if turn.role == "user":
                summary_lines.append(f"Earlier user request: {turn.content}")
        preference_text = format_preferences(self.preferences)
        if preference_text:
            summary_lines.append(f"Session preferences: {preference_text}")
        self._summary = " ".join(_unique(summary_lines))


class MemoryManager:
    """Manage multiple in-process CatalogueIQ sessions."""

    def __init__(self, *, default_max_turns: int = DEFAULT_MEMORY_TURNS) -> None:
        if default_max_turns < 1:
            raise MemoryError("default_max_turns must be at least 1")
        self.default_max_turns = default_max_turns
        self._sessions: dict[str, ConversationMemory] = {}
        self._lock = RLock()

    def create_session(
        self,
        *,
        persona: str = "shopper",
        session_id: str | None = None,
        known_brands: Iterable[str] = (),
    ) -> ConversationMemory:
        memory = ConversationMemory(
            session_id=session_id,
            persona=persona,
            max_turns=self.default_max_turns,
            known_brands=known_brands,
        )
        with self._lock:
            if memory.session_id in self._sessions:
                raise MemoryError(f"Session already exists: {memory.session_id}")
            self._sessions[memory.session_id] = memory
        return memory

    def get_session(self, session_id: str) -> ConversationMemory:
        with self._lock:
            if session_id not in self._sessions:
                raise MemoryError(f"Unknown session: {session_id}")
            return self._sessions[session_id]

    def get_or_create(
        self,
        session_id: str,
        *,
        persona: str = "shopper",
        known_brands: Iterable[str] = (),
    ) -> ConversationMemory:
        with self._lock:
            if session_id in self._sessions:
                return self._sessions[session_id]
        return self.create_session(
            persona=persona,
            session_id=session_id,
            known_brands=known_brands,
        )

    def delete_session(self, session_id: str) -> bool:
        with self._lock:
            return self._sessions.pop(session_id, None) is not None

    def list_sessions(self) -> list[str]:
        with self._lock:
            return sorted(self._sessions)


def extract_preferences(
    text: str,
    known_brands: Iterable[str] = (),
) -> dict[str, Any]:
    """Extract explicit session preferences from one user message."""
    if not isinstance(text, str) or not text.strip():
        return {}
    lowered = text.casefold()
    updates: dict[str, Any] = {}

    price = re.search(
        r"(?:under|below|up to|budget(?: of)?)\s*(?:₹|rs\.?|inr)?\s*"
        r"([\d,]+(?:\.\d+)?)\s*(k|thousand)?\b",
        lowered,
    )
    if price:
        value = float(price.group(1).replace(",", ""))
        if price.group(2):
            value *= 1000
        updates["max_price"] = value

    rating = re.search(
        r"(?:rating|rated)\s*(?:above|at least|of)?\s*(\d(?:\.\d)?)",
        lowered,
    )
    if rating and 0 <= float(rating.group(1)) <= 5:
        updates["min_rating"] = float(rating.group(1))

    battery = re.search(
        r"(?:at least|minimum(?: of)?)?\s*(\d+(?:\.\d+)?)\s*"
        r"(?:hours?|hrs?)\s*(?:of\s*)?battery",
        lowered,
    )
    if battery:
        updates["min_battery_hours"] = float(battery.group(1))

    size = re.search(
        r"\b(?:size|in size)\s*(xxs|xs|s|m|l|xl|xxl|\d{1,2}(?:\.5)?)\b",
        lowered,
    )
    if size:
        updates["size"] = size.group(1).upper()

    colour = re.search(
        r"\b(?:prefer|want|in)\s+(black|white|blue|green|red|grey|gray|beige|pink|navy|silver)\b",
        lowered,
    )
    if colour:
        updates["colour"] = colour.group(1).title()

    if re.search(r"\b(?:with|need|must have|only)\s+(?:good\s+)?anc\b", lowered):
        updates["anc_required"] = True
    elif re.search(r"\b(?:without|no)\s+anc\b", lowered):
        updates["anc_required"] = False
    if re.search(r"\b(?:verified sellers?|seller verified|from verified sellers?)\b", lowered):
        updates["verified_seller_required"] = True
    if re.search(r"\b(?:in stock|available now|currently available)\b", lowered):
        updates["in_stock_required"] = True

    category_terms = {
        "Electronics": ("earbud", "earphone", "tws", "smartwatch", "speaker", "power bank", "electronics"),
        "Fashion": ("fashion", "t-shirt", "jeans", "kurta", "kurti", "dress", "sneaker", "jacket"),
        "Home & Kitchen": ("home & kitchen", "mixer", "cookware", "kettle", "air fryer"),
        "Beauty": ("beauty", "face wash", "moisturizer", "sunscreen", "shampoo", "perfume"),
        "Books": ("books", "book", "novel", "paperback", "hardcover"),
    }
    for category, terms in category_terms.items():
        if any(term in lowered for term in terms):
            updates["category"] = category
            break

    subcategories = {
        "Wireless Earbuds": ("wireless earbuds", "earbuds", "earphones", "tws"),
        "Smartwatch": ("smartwatch", "smart watch"),
        "Power Bank": ("power bank",),
        "Kurta": ("kurta", "kurti"),
        "Sneakers": ("sneakers", "trainers"),
    }
    for subcategory, terms in subcategories.items():
        if any(term in lowered for term in terms):
            updates["subcategory"] = subcategory
            break

    exclusions: list[str] = []
    preferences: list[str] = []
    for brand in known_brands:
        brand_lower = brand.casefold()
        if brand_lower not in lowered:
            continue
        exclusion_pattern = rf"(?:exclude|excluding|except|without|do not include|don't include)\s+{re.escape(brand_lower)}"
        preference_pattern = rf"(?:prefer|like|favour|favor|only)\s+{re.escape(brand_lower)}"
        if re.search(exclusion_pattern, lowered):
            exclusions.append(brand)
        elif re.search(preference_pattern, lowered):
            preferences.append(brand)
    if exclusions:
        updates["excluded_brands"] = exclusions
    if preferences:
        updates["preferred_brands"] = preferences

    if any(token in lowered for token in ("hinglish", "hindi and english", "hindi + english")):
        updates["language"] = "Hinglish"
    elif re.search(r"\bin hindi\b", lowered):
        updates["language"] = "Hindi"
    elif re.search(r"\bin english\b", lowered):
        updates["language"] = "English"

    return updates


def is_follow_up(query: str) -> bool:
    """Detect whether a query relies on preceding conversation context."""
    if not isinstance(query, str) or not query.strip():
        return False
    lowered = query.strip().casefold()
    signals = (
        "only ", "which one", "which has", "compare them", "compare these",
        "top three", "top 3", "exclude ", "what about", "how about",
        "and warranty", "and returns", "is it", "are they", "that one",
        "those", "them", "cheaper one", "best one", "recommend again",
    )
    return any(signal in lowered for signal in signals) or len(lowered.split()) <= 4


def format_preferences(preferences: SessionPreferences) -> str:
    """Return a compact retrieval-oriented preference string."""
    values = preferences.as_dict()
    labels = {
        "preferred_brands": "preferred brands",
        "excluded_brands": "excluded brands",
        "category": "category",
        "subcategory": "subcategory",
        "max_price": "maximum price INR",
        "min_rating": "minimum rating",
        "min_battery_hours": "minimum battery hours",
        "size": "size",
        "colour": "colour",
        "anc_required": "ANC required",
        "verified_seller_required": "verified seller required",
        "in_stock_required": "in stock required",
        "language": "language",
    }
    parts: list[str] = []
    for key, value in values.items():
        if isinstance(value, list):
            value = ", ".join(map(str, value))
        parts.append(f"{labels.get(key, key)}: {value}")
    return "; ".join(parts)


def _unique(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    output: list[str] = []
    for value in values:
        cleaned = str(value).strip()
        key = cleaned.casefold()
        if cleaned and key not in seen:
            seen.add(key)
            output.append(cleaned)
    return output


__all__ = [
    "ConversationMemory",
    "ConversationSnapshot",
    "ConversationTurn",
    "DEFAULT_MEMORY_TURNS",
    "MemoryError",
    "MemoryManager",
    "SUPPORTED_PERSONAS",
    "SUPPORTED_ROLES",
    "SessionPreferences",
    "extract_preferences",
    "format_preferences",
    "is_follow_up",
]
