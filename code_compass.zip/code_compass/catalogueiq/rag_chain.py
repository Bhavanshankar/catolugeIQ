"""End-to-end Retrieval-Augmented Generation chain for CatalogueIQ.

The chain coordinates conversation memory, retrieval, prompt construction,
LLM generation, citation checks, and response tracing. It is framework
independent and supports any chat model implementing ``ChatProvider``.

Previous assistant messages are conversational context only. Product and
policy facts must always come from freshly retrieved ShopSmart India evidence.
"""

from __future__ import annotations

import os
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Iterable, Iterator, Mapping, Sequence

try:
    from .memory import ConversationMemory
    from .prompts import (
        INSUFFICIENT_EVIDENCE_MESSAGE,
        PromptBundle,
        build_prompt_from_retrieval,
    )
    from .retriever import CatalogueRetriever, RetrievalResponse
except ImportError:  # Direct execution during development.
    from memory import ConversationMemory
    from prompts import INSUFFICIENT_EVIDENCE_MESSAGE, PromptBundle, build_prompt_from_retrieval
    from retriever import CatalogueRetriever, RetrievalResponse

DEFAULT_CHAT_MODEL = "gpt-4.1-mini"
CITATION_PATTERN = re.compile(r"\[Source:\s*[^\]]+\]")


class RAGChainError(RuntimeError):
    """Raised when retrieval or answer generation cannot be completed."""


class ChatProvider(ABC):
    """Provider-independent chat model interface."""

    provider_name: str = "custom"
    model_name: str = "custom"

    @abstractmethod
    def generate(
        self,
        messages: Sequence[Mapping[str, str]],
        *,
        temperature: float = 0.0,
        max_tokens: int | None = None,
    ) -> str:
        """Generate one complete answer."""

    def stream(
        self,
        messages: Sequence[Mapping[str, str]],
        *,
        temperature: float = 0.0,
        max_tokens: int | None = None,
    ) -> Iterator[str]:
        """Stream answer fragments, falling back to one complete fragment."""
        yield self.generate(messages, temperature=temperature, max_tokens=max_tokens)


class OpenAIChatProvider(ChatProvider):
    """OpenAI chat-completions provider with optional streaming."""

    provider_name = "openai"

    def __init__(
        self,
        model_name: str = DEFAULT_CHAT_MODEL,
        *,
        api_key: str | None = None,
        client: Any | None = None,
    ) -> None:
        try:
            from openai import OpenAI
        except ImportError as exc:
            raise RAGChainError("OpenAI is not installed. Run: pip install openai") from exc
        self.model_name = model_name
        self._client = client or OpenAI(api_key=api_key or os.getenv("OPENAI_API_KEY"))

    def generate(
        self,
        messages: Sequence[Mapping[str, str]],
        *,
        temperature: float = 0.0,
        max_tokens: int | None = None,
    ) -> str:
        request: dict[str, Any] = {
            "model": self.model_name,
            "messages": [dict(message) for message in messages],
            "temperature": temperature,
        }
        if max_tokens is not None:
            request["max_tokens"] = max_tokens
        try:
            response = self._client.chat.completions.create(**request)
            answer = response.choices[0].message.content or ""
        except Exception as exc:
            raise RAGChainError(f"OpenAI generation failed: {exc}") from exc
        if not answer.strip():
            raise RAGChainError("Chat provider returned an empty answer")
        return answer.strip()

    def stream(
        self,
        messages: Sequence[Mapping[str, str]],
        *,
        temperature: float = 0.0,
        max_tokens: int | None = None,
    ) -> Iterator[str]:
        request: dict[str, Any] = {
            "model": self.model_name,
            "messages": [dict(message) for message in messages],
            "temperature": temperature,
            "stream": True,
        }
        if max_tokens is not None:
            request["max_tokens"] = max_tokens
        try:
            response = self._client.chat.completions.create(**request)
            for event in response:
                content = event.choices[0].delta.content
                if content:
                    yield content
        except Exception as exc:
            raise RAGChainError(f"OpenAI streaming failed: {exc}") from exc


@dataclass(frozen=True, slots=True)
class RAGConfig:
    """Generation and grounding configuration."""

    temperature: float = 0.0
    max_tokens: int | None = 700
    max_context_characters: int = 12000
    require_citations: bool = True
    minimum_results: int = 1
    use_memory: bool = True
    include_conversation_history: bool = True
    history_max_characters: int = 5000

    def __post_init__(self) -> None:
        if not 0.0 <= self.temperature <= 2.0:
            raise ValueError("temperature must be between 0 and 2")
        if self.max_tokens is not None and self.max_tokens <= 0:
            raise ValueError("max_tokens must be greater than zero")
        if self.max_context_characters <= 0:
            raise ValueError("max_context_characters must be greater than zero")
        if self.minimum_results < 1:
            raise ValueError("minimum_results must be at least 1")


@dataclass(slots=True)
class GroundingReport:
    """Deterministic citation and evidence checks for a generated answer."""

    evidence_count: int
    citations_found: list[str]
    valid_citations: list[str]
    invalid_citations: list[str]
    citations_required: bool
    passed: bool

    def as_dict(self) -> dict[str, Any]:
        return {
            "evidence_count": self.evidence_count,
            "citations_found": list(self.citations_found),
            "valid_citations": list(self.valid_citations),
            "invalid_citations": list(self.invalid_citations),
            "citations_required": self.citations_required,
            "passed": self.passed,
        }


@dataclass(slots=True)
class RAGResponse:
    """Complete answer plus evidence, prompts, and diagnostics."""

    answer: str
    user_question: str
    retrieval_query: str
    persona: str
    query_type: str
    citations: list[str]
    retrieval: RetrievalResponse | None
    prompt_bundle: PromptBundle | None
    grounding: GroundingReport
    used_memory: bool
    metadata: dict[str, Any] = field(default_factory=dict)

    def as_dict(self, *, include_prompts: bool = False) -> dict[str, Any]:
        payload = {
            "answer": self.answer,
            "user_question": self.user_question,
            "retrieval_query": self.retrieval_query,
            "persona": self.persona,
            "query_type": self.query_type,
            "citations": list(self.citations),
            "grounding": self.grounding.as_dict(),
            "used_memory": self.used_memory,
            "metadata": dict(self.metadata),
            "retrieval_trace": self.retrieval.trace.as_dict() if self.retrieval else None,
        }
        if include_prompts and self.prompt_bundle:
            payload["prompts"] = self.prompt_bundle.as_dict()
        return payload


class CatalogueRAGChain:
    """Orchestrate memory, retrieval, prompting, generation, and validation."""

    def __init__(
        self,
        retriever: CatalogueRetriever,
        chat_provider: ChatProvider,
        *,
        memory: ConversationMemory | None = None,
        config: RAGConfig | None = None,
    ) -> None:
        self.retriever = retriever
        self.chat_provider = chat_provider
        self.memory = memory
        self.config = config or RAGConfig()

    def ask(
        self,
        question: str,
        *,
        persona: str | None = None,
        limit: int | None = None,
        search_type: str | None = None,
        additional_rules: Iterable[str] = (),
    ) -> RAGResponse:
        """Run one complete grounded RAG turn."""
        user_question = _validate_question(question)
        effective_persona = persona or (self.memory.persona if self.memory else "shopper")
        retrieval_query = self._retrieval_query(user_question)

        try:
            retrieval = self.retriever.retrieve(
                retrieval_query,
                persona=effective_persona,
                limit=limit,
                search_type=search_type,
            )
        except Exception as exc:
            raise RAGChainError(f"Retrieval failed: {exc}") from exc

        if len(retrieval.results) < self.config.minimum_results:
            return self._insufficient_response(
                user_question,
                retrieval_query,
                effective_persona,
                retrieval,
            )

        rules = list(additional_rules)
        history = self._history_for_prompt()
        if history:
            rules.append(
                "Conversation history is supplied only for continuity. It is not evidence and must not be cited."
            )

        prompt = build_prompt_from_retrieval(
            user_question,
            retrieval,
            persona=effective_persona,
            max_context_characters=self.config.max_context_characters,
            additional_rules=rules,
        )
        messages = prompt.as_messages()
        if history:
            messages[1]["content"] += f"\n\nCONVERSATION HISTORY FOR CONTINUITY ONLY\n<history>\n{history}\n</history>"

        answer = self.chat_provider.generate(
            messages,
            temperature=self.config.temperature,
            max_tokens=self.config.max_tokens,
        ).strip()
        grounding = validate_grounding(
            answer,
            retrieval,
            require_citations=self.config.require_citations,
        )
        if self.config.require_citations and not grounding.passed:
            answer = INSUFFICIENT_EVIDENCE_MESSAGE
            grounding = validate_grounding(
                answer,
                retrieval,
                require_citations=False,
            )

        response = RAGResponse(
            answer=answer,
            user_question=user_question,
            retrieval_query=retrieval_query,
            persona=prompt.persona,
            query_type=prompt.query_type,
            citations=_unique(CITATION_PATTERN.findall(answer)),
            retrieval=retrieval,
            prompt_bundle=prompt,
            grounding=grounding,
            used_memory=bool(self.memory and self.config.use_memory),
            metadata={
                "chat_provider": self.chat_provider.provider_name,
                "chat_model": self.chat_provider.model_name,
            },
        )
        self._remember(response)
        return response

    def stream(
        self,
        question: str,
        *,
        persona: str | None = None,
        limit: int | None = None,
        search_type: str | None = None,
        additional_rules: Iterable[str] = (),
    ) -> Iterator[str]:
        """Stream answer text and save the completed exchange to memory.

        Grounding is checked after the provider finishes. For strict server-side
        validation before displaying text, use ``ask`` instead of ``stream``.
        """
        user_question = _validate_question(question)
        effective_persona = persona or (self.memory.persona if self.memory else "shopper")
        retrieval_query = self._retrieval_query(user_question)
        retrieval = self.retriever.retrieve(
            retrieval_query,
            persona=effective_persona,
            limit=limit,
            search_type=search_type,
        )
        if len(retrieval.results) < self.config.minimum_results:
            yield INSUFFICIENT_EVIDENCE_MESSAGE
            self._remember_text(user_question, INSUFFICIENT_EVIDENCE_MESSAGE, retrieval)
            return

        history = self._history_for_prompt()
        rules = list(additional_rules)
        if history:
            rules.append("Conversation history is not evidence and must not be cited.")
        prompt = build_prompt_from_retrieval(
            user_question,
            retrieval,
            persona=effective_persona,
            max_context_characters=self.config.max_context_characters,
            additional_rules=rules,
        )
        messages = prompt.as_messages()
        if history:
            messages[1]["content"] += f"\n\nCONVERSATION HISTORY FOR CONTINUITY ONLY\n<history>\n{history}\n</history>"

        fragments: list[str] = []
        for fragment in self.chat_provider.stream(
            messages,
            temperature=self.config.temperature,
            max_tokens=self.config.max_tokens,
        ):
            fragments.append(fragment)
            yield fragment
        answer = "".join(fragments).strip()
        self._remember_text(user_question, answer or INSUFFICIENT_EVIDENCE_MESSAGE, retrieval)

    def _retrieval_query(self, question: str) -> str:
        if self.memory and self.config.use_memory:
            return self.memory.retrieval_query(question)
        return question

    def _history_for_prompt(self) -> str:
        if not (
            self.memory
            and self.config.use_memory
            and self.config.include_conversation_history
        ):
            return ""
        history = self.memory.prompt_history()
        return history[-self.config.history_max_characters :]

    def _remember(self, response: RAGResponse) -> None:
        if not (self.memory and self.config.use_memory):
            return
        self.memory.add_exchange(
            response.user_question,
            response.answer,
            assistant_metadata={
                "citations": response.citations,
                "query_type": response.query_type,
                "retrieval_query": response.retrieval_query,
            },
        )

    def _remember_text(
        self,
        question: str,
        answer: str,
        retrieval: RetrievalResponse,
    ) -> None:
        if self.memory and self.config.use_memory:
            self.memory.add_exchange(
                question,
                answer,
                assistant_metadata={
                    "citations": _unique(CITATION_PATTERN.findall(answer)),
                    "query_type": retrieval.expanded_query.query_type,
                },
            )

    def _insufficient_response(
        self,
        question: str,
        retrieval_query: str,
        persona: str,
        retrieval: RetrievalResponse,
    ) -> RAGResponse:
        grounding = GroundingReport(
            evidence_count=len(retrieval.results),
            citations_found=[],
            valid_citations=[],
            invalid_citations=[],
            citations_required=False,
            passed=True,
        )
        response = RAGResponse(
            answer=INSUFFICIENT_EVIDENCE_MESSAGE,
            user_question=question,
            retrieval_query=retrieval_query,
            persona=persona,
            query_type=retrieval.expanded_query.query_type,
            citations=[],
            retrieval=retrieval,
            prompt_bundle=None,
            grounding=grounding,
            used_memory=bool(self.memory and self.config.use_memory),
            metadata={"reason": "insufficient_retrieved_evidence"},
        )
        self._remember(response)
        return response


def validate_grounding(
    answer: str,
    retrieval: RetrievalResponse,
    *,
    require_citations: bool = True,
) -> GroundingReport:
    """Check that answer citations were actually present in retrieved evidence."""
    found = _unique(CITATION_PATTERN.findall(answer or ""))
    available = set(retrieval.citations)
    valid = [citation for citation in found if citation in available]
    invalid = [citation for citation in found if citation not in available]
    sufficient_answer = (answer or "").strip() == INSUFFICIENT_EVIDENCE_MESSAGE
    passed = not invalid and (
        sufficient_answer or not require_citations or bool(valid)
    )
    return GroundingReport(
        evidence_count=len(retrieval.results),
        citations_found=found,
        valid_citations=valid,
        invalid_citations=invalid,
        citations_required=require_citations,
        passed=passed,
    )


def _validate_question(question: str) -> str:
    if not isinstance(question, str) or not question.strip():
        raise RAGChainError("question must be a non-empty string")
    return question.strip()


def _unique(values: Iterable[str]) -> list[str]:
    output: list[str] = []
    seen: set[str] = set()
    for value in values:
        if value not in seen:
            seen.add(value)
            output.append(value)
    return output


__all__ = [
    "CITATION_PATTERN",
    "CatalogueRAGChain",
    "ChatProvider",
    "DEFAULT_CHAT_MODEL",
    "GroundingReport",
    "OpenAIChatProvider",
    "RAGChainError",
    "RAGConfig",
    "RAGResponse",
    "validate_grounding",
]
