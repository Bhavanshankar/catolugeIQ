# ShopSmart India Seller Onboarding and Marketplace Compliance Guide

**Document ID:** SSI-SELLER-ONB-001  
**Version:** 1.0  
**Effective date:** 26 June 2026  
**Last reviewed:** 26 June 2026  
**Applies to:** New and existing ShopSmart India marketplace sellers  
**Document owner:** Marketplace Seller Operations  

> **Training dataset notice:** ShopSmart India is a fictional company. This guide is synthetic and was created for the CatalogueIQ capstone project. It must not be treated as the policy of a real marketplace.

---

## 1. Purpose

This guide explains how a seller registers, verifies an account, creates compliant product listings, configures pricing and inventory, fulfils orders, manages returns, follows category-specific rules, and maintains account performance on ShopSmart India.

The guide is intended for:

- Individual proprietors
- Registered businesses
- Manufacturers and authorised distributors
- Brand owners
- Marketplace resellers
- Seller operations and support teams

---

## 2. Seller Onboarding Overview

A new seller completes the following stages:

1. Create a seller account.
2. Verify the registered email address and mobile number.
3. Submit business, tax, identity, and bank information.
4. Complete seller and beneficial-owner verification.
5. Accept the marketplace seller agreement.
6. Configure pickup and return addresses.
7. Select product categories.
8. Complete category approval when required.
9. Create compliant product listings.
10. Configure inventory, pricing, tax, and shipping settings.
11. Complete the seller-readiness checklist.
12. Publish products and begin accepting orders.

A seller account may remain in `Draft`, `Verification Pending`, `Action Required`, `Approved`, `Restricted`, or `Suspended` status.

---

## 3. Eligibility

A seller must:

- Be at least 18 years old when registering as an individual proprietor.
- Be authorised to represent the registered business.
- Maintain a valid Indian bank account capable of receiving settlements.
- Provide valid tax registration information when required for the seller's products and business type.
- Have the legal right to sell every listed product.
- Comply with applicable product safety, labelling, packaging, intellectual-property, and consumer-protection requirements.
- Maintain a valid pickup address and return address.
- Supply accurate contact and beneficial-owner information.

Approval of an account does not automatically approve every product or category.

---

## 4. Account Registration

### 4.1 Create the Account

Open the ShopSmart India Seller Portal and select **Register as a Seller**. Enter:

- Legal name or registered business name
- Primary contact name
- Business email address
- Indian mobile number
- Password
- Business type
- Registered state or union territory

The email address and mobile number must be verified using one-time verification codes.

### 4.2 Account Security

Sellers must:

- Use a unique password.
- Enable multi-factor authentication.
- Restrict portal access to authorised staff.
- Create separate sub-user accounts instead of sharing the primary login.
- Remove access promptly when a staff member changes roles or leaves the organisation.
- Review account activity and payout changes regularly.

ShopSmart India support will not ask a seller to disclose a password, one-time verification code, or complete bank credential.

---

## 5. Required Documents and Information

The exact documents depend on business type and category. A typical seller must submit:

### 5.1 Identity and Business Verification

- Permanent Account Number or applicable tax identifier
- Government-issued identity document for the proprietor or authorised representative
- Business registration or incorporation document, when applicable
- Registered office or business-address proof
- Authorisation letter when the account operator is not the proprietor or director
- Beneficial-owner details when required

### 5.2 Tax Information

- Goods and Services Tax registration number when required
- Tax registration certificate
- State registration details, where applicable
- Product tax classification and tax rate

The seller is responsible for selecting accurate product tax classifications. ShopSmart India may request correction when the submitted classification conflicts with product information.

### 5.3 Bank Verification

Provide:

- Account-holder name
- Bank account number
- IFSC
- Bank name and branch
- Cancelled cheque, bank statement, or verification document

The account-holder name should match the verified seller entity or an approved business relationship. Settlement may remain disabled until bank verification is complete.

### 5.4 Brand and Authorisation Documents

A seller may be asked to provide:

- Trademark registration
- Brand-owner authorisation letter
- Distributor or purchase invoices
- Import documentation
- Manufacturer details
- Product test reports or compliance certificates

Documents must be readable, current, unaltered, and consistent with account information.

---

## 6. Verification and Approval

ShopSmart India reviews submitted information for identity, business legitimacy, bank ownership, tax validity, restricted-product risk, and account duplication.

Possible results are:

- **Approved:** The seller may proceed to eligible categories.
- **Action Required:** Information is incomplete, inconsistent, or unreadable.
- **Category Approval Required:** The account is approved, but a selected category requires additional documents.
- **Rejected:** The application does not meet onboarding requirements.

A standard verification may take up to 3 business days after all required information is submitted. Complex ownership, brand, or compliance reviews may require additional time.

A seller must not create duplicate accounts to avoid verification or enforcement action.

---

## 7. Seller Profile Setup

After approval, configure:

- Public display name
- Customer-service contact details
- Pickup address
- Return address
- Business hours
- Default handling time
- Shipping preferences
- Tax settings
- Settlement preferences
- Notification recipients

The public seller name must not impersonate another brand, marketplace, government authority, or authorised service centre.

---

## 8. Category Selection and Approval

Some categories are open after account verification. Others require additional evidence because of safety, authenticity, legal, or quality requirements.

Categories that may require additional approval include:

- Selected Electronics
- Beauty and Personal Care
- Food and consumables
- Medical or wellness products
- Jewellery and precious materials
- Children's products
- Automotive safety products
- Imported products
- Branded or luxury products

A category application may require product images, invoices, brand authorisation, lab reports, safety certificates, manufacturing licences, expiry information, or packaging labels.

The seller must wait for approval before publishing products in a restricted category.

---

## 9. Product Listing Requirements

Every listing must clearly identify the product and give the buyer enough information to make an informed decision.

### 9.1 Mandatory Core Fields

Provide:

- Product title
- Brand or `Unbranded`, when genuinely applicable
- Category and subcategory
- Product description
- Key features
- Model name or number
- Manufacturer or publisher
- Country of origin
- Package contents
- Price and maximum retail price, when applicable
- Stock quantity
- Seller SKU
- Product identifier such as GTIN, ISBN, UPC, EAN, or approved exemption
- Warranty details
- Return eligibility information
- Product dimensions or size
- Shipping weight
- Required safety, usage, and care information

### 9.2 Product Title Standard

Use the following order where applicable:

```text
Brand + Product Type + Model + Primary Attribute + Size or Quantity + Colour
```

Example:

```text
Auralite Wireless Earbuds X200 with ANC, 30-Hour Battery, Black
```

Do not use:

- Promotional phrases such as `Best`, `No. 1`, or `Cheapest`
- Repeated keywords
- Excessive capital letters
- Misleading compatibility claims
- Contact information
- Website addresses
- Emoji or decorative symbols
- Competitor names unless required for accurate compatibility information

### 9.3 Product Description

The description must:

- Match the supplied product.
- Use complete, readable sentences.
- Explain important features and limitations.
- State package contents.
- Include material, dimensions, capacity, or technical specifications where relevant.
- Explain installation or compatibility requirements.
- Avoid unsupported health, safety, performance, or environmental claims.
- Avoid seller contact details and external purchase links.

### 9.4 Key Features

Use concise bullet points. Each point should describe one useful attribute, such as material, capacity, battery life, compatibility, care instructions, warranty, or package contents.

Do not repeat the product title or use unrelated search terms.

---

## 10. Product Image Requirements

Images are required to be accurate, clear, and representative of the product delivered to the buyer.

### 10.1 Primary Image

The primary image must:

- Show the exact product being sold.
- Use a pure white or near-white background.
- Display the complete product without cropped edges.
- Occupy approximately 75% to 90% of the image frame.
- Use a square image with a minimum resolution of **1000 by 1000 pixels**.
- Use JPEG or PNG format.
- Use the sRGB colour profile where possible.
- Be sharp, well lit, and free from excessive reflection.
- Show only items included in the offer.

### 10.2 Additional Images

Additional images may show:

- Alternate angles
- Product dimensions
- Important controls and ports
- Texture or material details
- Product packaging
- Scale or usage context
- Included accessories
- Size chart
- Approved feature callouts

At least three images are recommended for most products. Electronics and Home and Kitchen products should include an image of ports, controls, or important functional parts when applicable.

### 10.3 Prohibited Image Content

Images must not contain:

- Seller or marketplace watermarks
- Phone numbers, email addresses, QR codes, or website addresses
- Misleading badges such as `Guaranteed Best` or `Official` without authorisation
- Prices, discounts, coupons, or delivery promises
- Borders or decorative frames on the primary image
- Products or accessories not included in the package
- Offensive, unsafe, or unlawful material
- Images copied without permission
- Placeholder text such as `Image Coming Soon`

### 10.4 Electronics Image Requirements

Electronics listings should include:

- Front and rear views where relevant
- Ports and connector details
- Control layout
- Included charger, cable, case, or adaptor
- Model-number label when it helps distinguish variants
- Screen display shown only as a reasonable illustration

The seller must not digitally add a feature, port, accessory, or certification mark that is absent from the supplied product.

### 10.5 Fashion Image Requirements

Fashion listings should include:

- Front and back views
- Fabric or texture close-up
- Size chart
- Fit or silhouette view
- Accurate colour representation

Mannequin or model images may be used as additional images. The primary image should still make the product easy to identify.

---

## 11. Category-Specific Listing Attributes

### 11.1 Electronics

Include, where applicable:

- Model number
- Connectivity type
- Battery capacity and claimed battery life
- Charging time and charging interface
- Power requirements
- Compatibility
- Operating system
- Display size and resolution
- Memory and storage
- Ports and included accessories
- Water or dust resistance rating
- Warranty provider and period
- Required regulatory or safety identifiers

Battery-life claims must state the test conditions or use qualifying language such as `up to` when performance depends on usage.

### 11.2 Fashion

Include:

- Size
- Size chart and measurement unit
- Material composition
- Fit
- Pattern
- Colour
- Sleeve, neckline, rise, or length where relevant
- Wash and care instructions
- Country of origin

Do not describe a product as pure cotton, leather, silk, or another premium material unless the claim is accurate and supportable.

### 11.3 Home and Kitchen

Include:

- Material
- Dimensions
- Capacity
- Weight
- Power rating, when applicable
- Installation requirement
- Included components
- Care and cleaning instructions
- Food-contact or safety information where relevant
- Warranty details

### 11.4 Beauty and Personal Care

Include:

- Net quantity
- Ingredient list
- Usage instructions
- Warnings and patch-test guidance
- Skin or hair type
- Manufacturer and marketer details
- Batch and expiry information where applicable
- Required licence or registration information

Do not claim that a product diagnoses, treats, cures, or prevents a medical condition without the required authorisation and evidence.

### 11.5 Books

Include:

- Title
- Author
- Publisher
- ISBN
- Language
- Binding or format
- Publication date or edition
- Number of pages
- Subject or genre

Do not combine different editions, languages, or bindings in one product record unless variations are correctly configured.

---

## 12. Variations and Duplicate Listings

Use a variation family only when products differ by a valid attribute such as:

- Size
- Colour
- Storage capacity
- Pack quantity
- Style
- Flavour

Do not use variations to group unrelated products, different models, or products from different brands.

Before creating a new listing, search the catalogue for an existing product. When the exact product already exists, add the seller offer to that product record instead of creating a duplicate.

Duplicate listings may be merged, suppressed, or removed.

---

## 13. Pricing Rules

A seller must enter an accurate selling price and maximum retail price where applicable.

### 13.1 Pricing Requirements

- The selling price must include applicable item-level taxes unless the interface specifically states otherwise.
- The displayed maximum retail price must match the product or packaging and must not be inflated.
- Discounts must be calculated from a genuine reference price.
- The checkout price must not exceed the displayed price except for separately disclosed delivery or service charges.
- A seller must not coordinate prices with competing sellers.
- Automated repricing must remain within configured minimum and maximum limits.

### 13.2 Promotional Pricing

For a promotion, enter:

- Promotional price
- Start date and time
- End date and time
- Eligible SKU
- Available promotional inventory

A promotion may be rejected when the reference price is misleading, the discount is not genuine, or stock is insufficient.

### 13.3 Pricing Errors

If an incorrect price is published, pause the listing and correct it immediately. Sellers must not routinely cancel accepted orders to avoid honouring correctly published offers. Repeated seller-caused pricing cancellations may affect account performance.

---

## 14. Inventory and SKU Management

Each seller SKU must be unique within the seller account.

Sellers must:

- Update stock before accepting orders.
- Avoid listing unavailable inventory.
- Reserve stock for confirmed orders.
- Account for damaged or quarantined units.
- Keep variation-level stock accurate.
- Use inventory feeds or APIs for high-volume catalogues.
- Review overselling and cancellation reports.

Inventory should be updated at least daily. High-volume sellers should use near-real-time updates.

A listing becomes unavailable when stock reaches zero, but its product record may remain in the catalogue.

---

## 15. Shipping and Fulfilment

A seller may use seller fulfilment or an available ShopSmart Fulfilled service.

### 15.1 Seller-Fulfilled Orders

The seller must:

- Confirm the order within the stated handling time.
- Pack the correct product and quantity.
- Use protective, tamper-evident packaging where appropriate.
- Print the correct shipping label and invoice.
- Hand the shipment to the assigned carrier on time.
- Upload valid tracking when required.
- Avoid placing promotional material or external purchase requests in the package.

### 15.2 Packaging Standards

Packaging must:

- Protect the product during normal transport.
- Match product size and weight.
- Prevent leakage and contamination.
- Separate fragile components.
- Cover or protect sharp edges.
- Follow battery and hazardous-material requirements.
- Avoid excessive empty space.
- Include handling labels when needed.

### 15.3 Delivery Promises

Sellers must not display unsupported delivery promises in the title, description, or images. Delivery estimates are calculated by the marketplace using handling time, carrier service, origin, destination, and operational conditions.

---

## 16. Order Processing

For each new order:

1. Review the SKU, quantity, and promised dispatch date.
2. Confirm inventory.
3. Pick the exact product and variation.
4. Perform a quality and completeness check.
5. Pack according to category requirements.
6. Attach the correct label and documentation.
7. Hand over the shipment within the dispatch deadline.
8. Retain dispatch and serial-number records when applicable.

The seller must not contact the buyer to request cancellation because of stock or pricing problems.

---

## 17. Returns, Replacements and Refund Responsibilities

Sellers must follow the ShopSmart India Returns, Refunds and Replacement Policy and the return eligibility displayed at checkout.

Sellers are responsible for:

- Responding to return evidence requests within the portal deadline
- Accepting approved eligible returns
- Verifying serial numbers and completeness fairly
- Providing a valid rejection reason with evidence
- Supporting promised warranties
- Paying applicable costs when the return results from seller error
- Not imposing a shorter return window after purchase

A seller must not ask a buyer to close a marketplace case, communicate outside approved channels, or accept an unauthorised partial refund.

A product that is outside the marketplace return window may still qualify for manufacturer or seller warranty support.

---

## 18. Product Authenticity and Intellectual Property

Every product must be genuine, lawfully sourced, and accurately branded.

Sellers must retain invoices and supply-chain records. ShopSmart India may request records for selected SKUs, orders, or brands.

Prohibited conduct includes:

- Selling counterfeit or replica products
- Misusing trademarks
- Copying protected images or descriptions without permission
- Listing an unbranded item under a recognised brand
- Altering serial numbers
- Using another seller's warranty or authorisation document
- Making false `authorised seller` claims

A rights-owner complaint may result in listing removal while the claim is reviewed.

---

## 19. Restricted and Prohibited Products

Sellers must not list unlawful, unsafe, recalled, stolen, counterfeit, or prohibited products.

Products that may be prohibited or restricted include:

- Weapons and dangerous items
- Illegal drugs and controlled substances
- Unsafe chemicals
- Recalled products
- Counterfeit goods
- Products violating intellectual-property rights
- Products lacking required safety or regulatory approvals
- Certain medical, financial, gambling, adult, or surveillance products
- Products whose sale or shipping is restricted by location

This list is not exhaustive. A seller must review category restrictions before listing and before introducing a new product type.

---

## 20. Customer Communication

Use the ShopSmart messaging system for order-related communication.

Messages must be:

- Relevant to the order or support request
- Professional and respectful
- Free from harassment or pressure
- Free from external payment requests
- Free from marketing unrelated to the order

Do not request unnecessary personal information. Do not move the buyer to an external messaging platform to avoid marketplace monitoring or buyer protection.

---

## 21. Ratings and Reviews

Sellers must not:

- Buy, sell, or exchange reviews
- Offer a refund, gift, or discount in return for a positive review
- Ask family, employees, or associated parties to post undisclosed reviews
- Pressure a buyer to remove a negative review
- Create orders for the purpose of generating ratings

A seller may politely request an honest review using approved marketplace features.

---

## 22. Seller Performance Standards

ShopSmart India may monitor:

- Order cancellation rate
- Late dispatch rate
- Valid tracking rate
- Delivery defect rate
- Return rate by reason
- Wrong-item and missing-item rate
- Counterfeit or authenticity complaints
- Customer response time
- Policy-violation rate
- Warranty-support compliance

Illustrative operational targets for the fictional marketplace are:

- Seller-caused cancellation rate below 2%
- Late dispatch rate below 4%
- Valid tracking rate at or above 95%
- Customer-message response within 24 hours

Targets may vary by category, fulfilment type, or programme. Sellers should rely on the current Seller Performance dashboard for account-specific requirements.

---

## 23. Policy Enforcement

When a listing or account violates a requirement, ShopSmart India may:

- Request information or corrective action
- Suppress a listing
- Remove an image or claim
- Block a category
- Hold affected inventory
- Delay settlement during an investigation
- Restrict account capabilities
- Suspend or terminate the account

Enforcement considers severity, buyer harm, recurrence, cooperation, and evidence. Serious safety, fraud, or counterfeit concerns may result in immediate action.

---

## 24. Corrective Action and Appeals

A seller may appeal an eligible enforcement decision through the Seller Portal.

A useful corrective-action response includes:

1. The root cause of the issue.
2. Immediate action taken for affected buyers and products.
3. Process changes that prevent recurrence.
4. Evidence that the corrective action is implemented.
5. The person or team responsible for ongoing monitoring.

Do not submit copied, generic, or unsupported corrective-action statements.

An appeal should be submitted within the period stated in the enforcement notice.

---

## 25. Settlement and Fees

Seller proceeds are calculated from the buyer payment after applicable marketplace fees, fulfilment charges, taxes, refunds, adjustments, and other disclosed amounts.

Before listing, the seller should review:

- Referral or commission fee
- Closing fee
- Shipping or fulfilment fee
- Storage fee, when applicable
- Return-related charges
- Advertising charges
- Tax deductions or collections

Settlement is transferred only to the verified bank account. Changes to bank details may trigger a security review or temporary settlement hold.

---

## 26. Data Protection and Confidentiality

Buyer information may be used only to fulfil the order, provide approved support, meet legal obligations, or handle a marketplace dispute.

Sellers must:

- Limit buyer-data access to authorised staff.
- Protect downloaded reports.
- Avoid storing payment credentials.
- Delete buyer data when no longer required.
- Report suspected data exposure promptly.
- Avoid using buyer information for unrelated marketing.

Seller account, sales, buyer, and marketplace operational information must be protected from unauthorised disclosure.

---

## 27. Adding Products in Bulk

High-volume sellers may use a CSV template, feed, or approved API.

Before uploading:

- Use the latest category template.
- Keep seller SKUs unique.
- Use valid controlled-vocabulary values.
- Format dates, numbers, and Boolean fields consistently.
- Verify image URLs.
- Validate category-specific mandatory fields.
- Test a small batch before a full upload.

Review the processing report after upload. Correct rejected rows rather than repeatedly uploading unchanged data.

---

## 28. Catalogue Quality Checklist

Before publishing a listing, confirm:

- [ ] The selected category is correct.
- [ ] The product matches an existing listing or legitimately requires a new record.
- [ ] Product title follows the naming standard.
- [ ] Brand and model are accurate.
- [ ] Description and features match the supplied item.
- [ ] Mandatory attributes are complete.
- [ ] Price and maximum retail price are accurate.
- [ ] Inventory is available.
- [ ] Primary image has a white background.
- [ ] Image resolution is at least 1000 by 1000 pixels.
- [ ] Images contain no watermark or contact information.
- [ ] Package contents are disclosed.
- [ ] Warranty information is accurate.
- [ ] Return status matches product and category rules.
- [ ] Required regulatory and safety information is present.
- [ ] No unsupported claims are included.

---

## 29. Seller Launch Checklist

A seller is ready to launch when:

- [ ] Identity and business verification are approved.
- [ ] Tax information is complete.
- [ ] Bank account is verified.
- [ ] Pickup and return addresses are active.
- [ ] Multi-factor authentication is enabled.
- [ ] Required category approvals are complete.
- [ ] At least one compliant listing is active.
- [ ] Inventory and SKU data are accurate.
- [ ] Pricing has been reviewed.
- [ ] Packaging material is available.
- [ ] Order-processing responsibilities are assigned.
- [ ] Return and warranty procedures are documented.
- [ ] Customer messages are monitored.
- [ ] Seller Performance dashboard alerts are enabled.

---

## 30. Common Listing Rejection Reasons

A listing may be rejected because:

- Mandatory attributes are missing.
- The selected category is incorrect.
- A duplicate product already exists.
- The image is too small, unclear, or contains a watermark.
- The brand does not match the submitted authorisation.
- The title contains promotional or misleading text.
- Warranty details are inconsistent.
- A restricted category has not been approved.
- A required safety or regulatory document is missing.
- Product identifiers are invalid.
- The maximum retail price appears inaccurate.
- The description contains external contact or purchase information.

Correct the stated issue and resubmit. Do not create another listing to bypass rejection.

---

## 31. Support and Escalation

For assistance, open the Seller Portal and select the most relevant support topic:

- Account verification
- Bank and settlement
- Category approval
- Product listing
- Image rejection
- Inventory and feed processing
- Order fulfilment
- Returns and disputes
- Performance notification
- Policy enforcement

Include the seller ID, SKU, product ID, order ID, or case ID when relevant. Do not include passwords or one-time verification codes.

For an urgent product-safety concern, pause the listing and open a safety escalation immediately.

---

## 32. Quick Reference: Electronics Image Requirements

For an Electronics listing on ShopSmart India:

- Use a square primary image of at least 1000 by 1000 pixels.
- Use JPEG or PNG.
- Use a white or near-white primary-image background.
- Show the complete product without cropped edges.
- Keep the product at approximately 75% to 90% of the frame.
- Do not add prices, promotional badges, contact details, QR codes, or watermarks.
- Include additional images showing ports, controls, accessories, and important model details.
- Show only accessories included in the offer.
- Do not digitally add features that the product does not contain.

---

## 33. Guidance for CatalogueIQ Retrieval

This document should be chunked by heading. Long sections may be divided with a small overlap while preserving the complete heading path.

Each chunk should retain:

```text
source: seller_onboarding.md
source_type: seller_guide
document_id: SSI-SELLER-ONB-001
version: 1.0
effective_date: 2026-06-26
section: <current heading>
persona_scope: seller,support_agent
```

Recommended citation format:

```text
[Source: seller_onboarding.md | Section: <section heading>]
```

For seller questions, retrieve this guide before general buyer FAQs unless the query specifically concerns a buyer-facing policy.

---

## 34. Document Control

| Version | Date | Change | Owner |
|---|---|---|---|
| 1.0 | 26 June 2026 | Initial fictional seller onboarding and compliance guide | Marketplace Seller Operations |

---

**End of ShopSmart India Seller Onboarding and Marketplace Compliance Guide**
