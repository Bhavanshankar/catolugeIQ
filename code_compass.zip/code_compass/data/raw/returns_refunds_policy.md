# ShopSmart India Returns, Refunds and Replacement Policy

**Document ID:** SSI-POL-RR-001  
**Version:** 1.0  
**Effective date:** 26 June 2026  
**Last reviewed:** 26 June 2026  
**Applies to:** ShopSmart India marketplace orders  
**Document owner:** Customer Experience and Marketplace Operations  

> **Training dataset notice:** ShopSmart India is a fictional company. This policy is synthetic and was created for the CatalogueIQ capstone project. It is not legal advice and must not be used as a real marketplace policy.

---

## 1. Purpose

This policy explains when a product purchased through ShopSmart India may be returned, replaced, cancelled, or refunded. It also explains category-specific exceptions, evidence requirements, seller responsibilities, refund timelines, promotional-order rules, and the process for raising a dispute.

The policy applies to shoppers, third-party sellers, ShopSmart Fulfilled sellers, and customer-support agents using the ShopSmart India marketplace.

---

## 2. Definitions

- **Buyer:** The customer who placed the order using a ShopSmart India account.
- **Seller:** The marketplace seller responsible for listing and supplying the product.
- **ShopSmart Fulfilled:** An order stored, packed, or shipped through a ShopSmart-operated fulfilment facility.
- **Delivery date:** The date on which the order is marked as delivered to the buyer or an authorised recipient.
- **Return window:** The number of calendar days during which an eligible return request may be submitted.
- **Replacement:** Exchange of an eligible product for the same model, size, colour, or variant, subject to availability.
- **Refund:** Reversal of the eligible amount to the original payment method or, when selected and permitted, ShopSmart Wallet.
- **Defective product:** A product that does not operate according to its documented specifications under normal use.
- **Damaged product:** A product that arrives physically damaged, broken, leaking, or otherwise unusable.
- **Wrong product:** A product whose model, size, colour, quantity, or category differs from the item ordered.
- **Missing item:** A listed product, accessory, component, or quantity that was not included in the delivered package.
- **Change-of-mind return:** A return requested because the buyer no longer wants the product, even though it is correct and functional.
- **Final-sale item:** A product explicitly marked as non-returnable or final sale on the product page before purchase.

---

## 3. General Eligibility Rules

A return or replacement request is eligible only when all applicable conditions below are met:

1. The request is submitted within the return window measured from the delivery date.
2. The order was placed through ShopSmart India and can be verified using the order ID.
3. The product is returned with its original packaging, manuals, warranty card, accessories, freebies, labels, and serial-number tags, when applicable.
4. The product and package serial numbers match the delivered order.
5. The product has not been altered, repaired by an unauthorised party, misused, or damaged after delivery.
6. Personal data and accounts have been removed from electronic devices before pickup or handover.
7. The buyer provides requested evidence for damaged, defective, wrong, empty, or missing-item claims.
8. The product is not excluded under the non-returnable-items section.

Opening packaging only to inspect an eligible product does not automatically make it non-returnable. However, hygiene seals, activation locks, tamper seals, software keys, and consumable seals must remain intact unless the claim concerns a verified defect or delivery issue.

---

## 4. Standard Category Return Windows

### 4.1 Electronics

- **Standard return window:** 7 calendar days.
- **Primary remedy for a verified defect:** Replacement when stock is available.
- **Refund eligibility:** Available when replacement stock is unavailable, the replacement also fails inspection, or the delivered item is wrong, damaged, counterfeit, or materially different from the listing.
- **After the return window:** The buyer should use the manufacturer or seller warranty where applicable.

Electronics may require technical verification before approval. The verification may be completed remotely, during pickup, at an authorised service centre, or by a ShopSmart inspection partner.

### 4.2 Fashion

- **Standard return window:** 30 calendar days.
- **Eligible reasons:** Wrong product, wrong size, fit issue, colour mismatch, damaged product, quality issue, or change of mind.
- **Condition:** Products must be unused, unwashed, unaltered, and returned with tags attached.

Innerwear, lingerie, swimwear, socks, and opened hygiene-sensitive apparel are non-returnable unless the wrong or damaged product was delivered and the issue is reported within 48 hours.

### 4.3 Home and Kitchen

- **Standard return window:** 10 calendar days.
- **Eligible reasons:** Damaged, defective, wrong, incomplete, or materially different product.
- **Change-of-mind returns:** Allowed only when the product page displays the `Change-of-mind eligible` label.

Installed appliances may require an authorised technician's report. Products damaged during unauthorised self-installation are not eligible.

### 4.4 Beauty and Personal Care

- **Standard return window:** 7 calendar days for unopened eligible products.
- **Opened products:** Non-returnable for hygiene reasons unless they are damaged, leaking, expired, counterfeit, or different from the order.
- **Reporting deadline for leakage, breakage, wrong item, or missing quantity:** 48 hours after delivery.

Shade preference, fragrance preference, or a reaction caused by individual sensitivity does not qualify for a return unless the product listing or applicable guarantee states otherwise.

### 4.5 Books

- **Standard return window:** 10 calendar days.
- **Eligible reasons:** Damaged pages, misprint, wrong title, missing pages, counterfeit edition, or materially different edition.
- **Change-of-mind returns:** Allowed only if the book is unused and its shrink wrap remains intact, where supplied.

Digital books, downloaded content, and revealed access codes are non-returnable.

---

## 5. Non-Returnable Items

The following products are generally non-returnable unless they arrive damaged, defective, wrong, expired, counterfeit, or incomplete:

- Personalised, engraved, monogrammed, or made-to-order products
- Gift cards and prepaid vouchers
- Downloaded software, activated licences, and revealed digital codes
- Opened cosmetics, fragrances, grooming products, and personal-care products
- Innerwear, lingerie, swimwear, socks, and hygiene-sensitive apparel
- Perishable food, flowers, and products with a short shelf life
- Products marked `Final Sale` or `Non-returnable` before purchase
- Products with removed serial-number labels or tampered warranty seals
- Products damaged through misuse, liquid exposure, mishandling, or unauthorised repair
- Items supplied free as part of a promotion, unless the complete promotional bundle is returned

A non-returnable label does not remove the buyer's right to report an item that was damaged, defective, wrong, expired, counterfeit, or not delivered.

---

## 6. Damaged, Defective, Wrong, Empty or Missing Orders

### 6.1 Reporting Deadline

The buyer should report visible damage, an empty package, a wrong product, a missing item, leakage, or tampered packaging within **48 hours of delivery**. A functional defect in an eligible product may be reported within the applicable category return window.

### 6.2 Evidence

ShopSmart India may request:

- Clear photographs of the outer packaging and shipping label
- Photographs or video showing the damage, defect, wrong item, or missing component
- Product and package serial numbers
- An unboxing video, when available
- A diagnostic report for selected electronics or appliances
- Identity verification for high-value claims

The absence of an unboxing video does not automatically invalidate a claim. ShopSmart India evaluates available evidence, shipment weight, warehouse scans, seller records, delivery information, and account history.

### 6.3 Available Remedies

Depending on the verification result, ShopSmart India may offer:

- Replacement with the same item
- Replacement with an equivalent item after buyer approval
- Missing-accessory shipment
- Partial refund for an accepted minor issue
- Full refund
- Manufacturer or authorised-service-centre support

The buyer does not have to accept a partial refund when the approved remedy is a full replacement or full refund.

---

## 7. Return Request Process

1. Sign in to the ShopSmart India account used for the purchase.
2. Open **My Orders** and select the relevant order.
3. Choose **Return or Replace**.
4. Select the reason and preferred remedy.
5. Add an explanation and upload requested evidence.
6. Select pickup or self-ship, when available.
7. Submit the request and save the return request ID.

A return request acknowledgement is normally generated immediately. Review or technical verification may take up to 2 business days. Complex, high-value, or suspected-fraud cases may require additional time.

---

## 8. Pickup, Self-Ship and Inspection

### 8.1 Pickup

Pickup is offered for eligible pin codes. The buyer must pack the product securely and include all accessories, freebies, manuals, and original packaging. The pickup agent may perform a basic condition, serial-number, and completeness check.

A successful pickup does not by itself guarantee a refund. Final approval may depend on warehouse or technical inspection.

### 8.2 Self-Ship

When pickup is unavailable, ShopSmart India may authorise self-shipping. The buyer must use a trackable courier and retain the receipt. Reasonable return-shipping charges may be reimbursed up to the limit stated in the authorisation message after the return is approved.

Returns sent without authorisation may be refused.

### 8.3 Failed Pickup

If pickup fails because of a logistics issue, ShopSmart India will reschedule it without reducing the approved return period. If the buyer is unavailable or the item is not ready, the buyer may reschedule through the order page. Repeated buyer-caused failures may result in closure after advance notice.

### 8.4 Inspection Outcomes

An inspection may produce one of the following outcomes:

- Approved
- Approved with deduction for a disclosed missing non-essential component
- Replacement approved
- Additional evidence required
- Rejected with a stated reason

A return must not be rejected merely because the outer shipping box was opened.

---

## 9. Refund Methods and Timelines

Refund processing begins after cancellation approval, return approval, or successful inspection, depending on the claim type.

### 9.1 Refund Timelines

- **ShopSmart Wallet:** Usually within 24 hours after refund initiation
- **UPI:** 2 to 4 business days
- **Credit or debit card:** 5 to 7 business days
- **Net banking:** 5 to 7 business days
- **Eligible bank EMI:** 7 to 10 business days, subject to the issuing bank
- **Cash on Delivery:** 3 to 5 business days after valid bank or UPI details are provided

Bank processing time begins when ShopSmart India issues the refund reference. Weekends, bank holidays, incorrect bank details, or bank-side delays may extend settlement.

### 9.2 Refund Amount

An approved full refund normally includes:

- Amount paid for the returned product
- Product-level tax paid
- Shipping fee when the entire order is returned because of seller or fulfilment error

The following may not be refunded unless required by the approved resolution:

- Gift wrapping already completed
- Expedited-delivery fee when delivery occurred within the promised expedited window
- Installation or service already completed
- Convenience charges explicitly marked non-refundable before payment

### 9.3 Discounts, Coupons and Wallet Credits

- A product refund is based on the net amount paid after item-level and proportionately allocated order-level discounts.
- A single-use coupon is normally not reissued after a voluntary return.
- If the return occurred because the item was damaged, defective, wrong, counterfeit, or not delivered, ShopSmart India may restore an eligible coupon or issue an equivalent promotional credit.
- Promotional wallet credits are restored only according to their original terms and expiry date.

### 9.4 Refund Delays

If a refund does not appear after the stated timeline, the buyer should provide the order ID and refund reference to support. ShopSmart India will investigate with the payment processor or bank. The buyer should not be instructed to contact the seller for a payment refund already initiated by ShopSmart India.

---

## 10. Replacement Rules

- A replacement is normally for the same product and variant.
- Replacement depends on stock availability and delivery-serviceability.
- If the same item is unavailable, the buyer may choose a refund or, when offered, approve an equivalent alternative.
- A replacement product receives the remaining original return window or 7 calendar days from replacement delivery, whichever is longer.
- If the replacement is also damaged, defective, wrong, or incomplete, the buyer may request a refund within the applicable replacement window.
- ShopSmart India will not require repeated replacements when a refund is the appropriate approved remedy.

---

## 11. Cancellation Policy

### 11.1 Buyer Cancellation

A buyer may cancel an order before it enters the non-cancellable shipping stage shown in **My Orders**. If cancellation is unavailable because the shipment is already in transit, the buyer may refuse delivery where supported or submit a return request after delivery, subject to product eligibility.

### 11.2 Seller or ShopSmart Cancellation

An order may be cancelled because of stock unavailability, incorrect pricing, payment verification failure, delivery restrictions, listing errors, or suspected fraud. Any captured payment will be refunded to the original payment method.

### 11.3 Prepaid Cancellation Refund

A prepaid cancellation refund is normally initiated within 24 hours after cancellation approval. The issuing bank's settlement timeline then applies.

---

## 12. Sale Events and Promotional Orders

Products bought during ShopSmart India sale events remain subject to their displayed category return window unless the product page clearly showed a specific exception before purchase.

A discounted price alone does not make a product non-returnable. For example, an eligible fashion item purchased during a sale may be returned within the standard 30-day window if it satisfies the fashion return conditions.

For bundle or `Buy One Get One` promotions:

- The complete bundle must normally be returned for a full refund.
- If only one bundle item is defective, ShopSmart India may replace that item or provide a proportionate remedy.
- Free gifts must be returned with the qualifying product unless support explicitly waives the requirement.
- If a free gift is not returned, its disclosed value may be deducted from the refund.

---

## 13. Third-Party Sellers and Seller Accountability

Third-party marketplace sellers must honour the return eligibility and product information displayed at checkout. A seller cannot impose a shorter return window after purchase.

Sellers are responsible for:

- Accurate product descriptions and specifications
- Authentic and legally saleable products
- Correct model, size, colour, quantity, and included accessories
- Valid warranty information
- Safe and appropriate packaging
- Timely response to return and dispute requests

ShopSmart India may approve a buyer remedy when a seller does not respond within the required service window or when available evidence supports the buyer's claim.

For a product that stops working after the return window, the buyer may use the manufacturer or seller warranty. If the warranty was promised on the product page but the seller refuses valid support, the buyer may raise a buyer-protection dispute.

---

## 14. Warranty and Post-Return-Window Support

The ShopSmart return window and the product warranty are different protections.

- The **return window** covers eligible marketplace returns shortly after delivery.
- The **warranty period** covers qualifying defects for the duration stated by the manufacturer or seller.

Example: If an eligible smartwatch purchased from a third-party seller stops working after 45 days, the standard 7-day Electronics return window has expired. The buyer should check the product's warranty and contact the authorised service centre or seller. If a listed warranty is denied without a valid reason, the buyer may raise a ShopSmart buyer-protection dispute with the invoice, warranty details, and service-centre response.

A warranty does not normally cover accidental damage, misuse, unauthorised repair, normal wear and tear, or damage excluded by the warranty terms.

---

## 15. Counterfeit or Authenticity Claims

ShopSmart India prohibits counterfeit products. A buyer who suspects a product is not genuine should:

1. Stop using the product when continued use may create a safety risk.
2. Open the order and select **Report authenticity concern**.
3. Upload packaging, serial-number, invoice, and product photographs.
4. Include any verification result from the brand or authorised service centre.

ShopSmart India may temporarily restrict the listing and seller while the claim is investigated. A substantiated claim may result in a full refund, replacement, seller action, and reimbursement of reasonable verification costs when pre-authorised.

---

## 16. Delivery Refusal and Undeliverable Orders

A buyer may refuse a visibly damaged or tampered package. The delivery agent should record the refusal reason. For prepaid orders, the refund begins after the returned shipment is confirmed in the logistics network.

If an order is undeliverable because of an incorrect address, repeated unavailability, or refusal unrelated to damage, the order may be returned to the seller. Applicable non-refundable charges, if any, must have been disclosed before checkout.

---

## 17. Partial Orders and Split Shipments

When an order contains multiple products or split shipments:

- Each delivered product has its own return window based on its delivery date.
- A buyer may return one eligible product without returning unrelated products.
- Order-level discounts are allocated proportionately when calculating a partial refund.
- Shipping charges are refunded only when required by the approved resolution or when the entire affected shipment failed because of seller or fulfilment error.

---

## 18. Return Abuse and Fraud Prevention

ShopSmart India may review accounts for unusual return patterns, substituted products, serial-number mismatch, false missing-item claims, altered evidence, or repeated misuse.

Protective action may include additional verification, restricted return methods, account review, or refusal of a fraudulent claim. Legitimate claims must not be rejected solely because a buyer has previously submitted returns. Every decision should be based on the current order and available evidence.

---

## 19. Disputes and Escalation

If a buyer disagrees with a return or refund decision:

1. Open **Help Centre > Returns and Refunds > Appeal a decision**.
2. Enter the order ID and return request ID.
3. Explain the reason for appeal and attach supporting evidence.
4. Submit the appeal within 7 calendar days of the decision.

A support specialist normally reviews an appeal within 3 business days. Complex authenticity, technical, or logistics cases may take up to 7 business days.

If the issue remains unresolved, the buyer may request escalation to the Marketplace Resolution Team. The escalation response should identify the evidence reviewed, the policy section applied, and the final remedy or rejection reason.

---

## 20. Support-Agent Guidance

Support agents must:

- Verify the order, delivery date, category, product-level return label, and request date.
- Identify whether the question concerns return eligibility, replacement, warranty, delivery damage, authenticity, or payment settlement.
- Apply the most specific category rule and then check exceptions.
- Never promise a refund before required inspection or verification is complete.
- Never invent a return period, warranty term, or refund status.
- Cite the relevant policy section in customer-facing case notes.
- Clearly distinguish marketplace return coverage from manufacturer warranty coverage.
- Escalate conflicting product-page and policy information rather than choosing the less favourable rule without review.

When retrieved information is insufficient, the agent or assistant should state that the answer cannot be confirmed from the available knowledge base and request the relevant order or product details.

---

## 21. Quick Reference

### Standard Return Windows

- Electronics: 7 calendar days
- Fashion: 30 calendar days
- Home and Kitchen: 10 calendar days
- Beauty and Personal Care: 7 calendar days for unopened eligible products
- Books: 10 calendar days

### Important Reporting Deadlines

- Visible damage, wrong item, empty package, leakage, or missing item: 48 hours
- Appeal of a return decision: 7 calendar days after the decision

### Typical Refund Settlement

- ShopSmart Wallet: within 24 hours after initiation
- UPI: 2 to 4 business days
- Credit or debit card: 5 to 7 business days
- Net banking: 5 to 7 business days
- Eligible EMI: 7 to 10 business days
- Cash on Delivery refund: 3 to 5 business days after valid details are provided

---

## 22. Citation Metadata for CatalogueIQ

When this document is chunked for retrieval, each chunk should retain:

```text
source: returns_refunds_policy.md
source_type: policy
policy_id: SSI-POL-RR-001
version: 1.0
effective_date: 2026-06-26
section: <current heading>
persona_scope: shopper,support_agent,seller
```

Recommended citation format:

```text
[Source: returns_refunds_policy.md | Section: <section heading>]
```

---

## 23. Document Control

| Version | Date | Change | Owner |
|---|---|---|---|
| 1.0 | 26 June 2026 | Initial fictional policy for the CatalogueIQ capstone | Customer Experience and Marketplace Operations |

---

**End of ShopSmart India Returns, Refunds and Replacement Policy**
