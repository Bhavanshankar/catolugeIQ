# ShopSmart India Electronics Category Taxonomy and Attribute Guide

**Document ID:** SSI-CAT-ELEC-001  
**Version:** 1.0  
**Effective date:** 26 June 2026  
**Applies to:** Electronics products listed on ShopSmart India  
**Document owner:** Catalogue Quality and Electronics Category Operations

> **Training dataset notice:** ShopSmart India is a fictional company. This synthetic guide was created for the CatalogueIQ capstone project and is not a real marketplace policy.

---

## 1. Purpose

This guide defines the Electronics category hierarchy, mandatory product attributes, naming rules, controlled values, validation requirements, and recommendation fields used by ShopSmart India.

It helps sellers, catalogue specialists, support agents, and CatalogueIQ correctly classify and compare Electronics products.

---

## 2. Electronics Category Hierarchy

```text
Electronics
├── Audio
│   ├── Wireless Earbuds
│   ├── Wired Earphones
│   ├── Headphones
│   ├── Bluetooth Speakers
│   └── Soundbars
├── Wearable Technology
│   ├── Smartwatches
│   ├── Fitness Bands
│   └── Smart Rings
├── Mobile Devices
│   ├── Smartphones
│   ├── Feature Phones
│   └── Tablets
├── Mobile Accessories
│   ├── Power Banks
│   ├── Chargers
│   ├── Charging Cables
│   ├── Cases and Covers
│   └── Screen Protectors
├── Computer Accessories
│   ├── Keyboards
│   ├── Mice
│   ├── Webcams
│   ├── USB Hubs
│   └── External Storage
└── Smart Home
    ├── Smart Bulbs
    ├── Smart Plugs
    ├── Security Cameras
    └── Streaming Devices
```

A product must be assigned to the most specific available subcategory. Do not place Wireless Earbuds directly under Electronics when the Audio > Wireless Earbuds path is available.

---

## 3. Common Electronics Attributes

The following attributes apply to most Electronics products:

- Product ID
- Product title
- Brand
- Model name
- Model number
- Category
- Subcategory
- Colour
- Country of origin
- Manufacturer
- Importer, when applicable
- Release year
- Warranty period
- Warranty provider
- In-the-box contents
- Product dimensions
- Product weight
- Power requirement
- Connectivity type
- Compatible devices or operating systems
- Return eligibility
- Seller ID
- Seller-verification status
- Regulatory or safety identifiers, when required

Values must describe the exact model and variant being offered.

---

## 4. Product Title Convention

Use this title structure when relevant:

```text
Brand + Product Type + Model + Primary Feature + Capacity or Size + Colour
```

Examples:

```text
Auralite Wireless Earbuds X200 with ANC, 30-Hour Battery, Black
NovaTech Smartwatch S4 with GPS, 1.78-inch Display, Blue
VoltEdge Power Bank P20, 20000 mAh, 22.5 W Fast Charging, Black
```

Do not include:

- Best, cheapest, premium, or No. 1
- Prices or discounts
- Delivery promises
- Seller contact details
- Repeated search keywords
- Features not supported by the product
- Unauthorised certification claims

---

## 5. Wireless Earbuds Attributes

### 5.1 Mandatory Attributes

- Brand
- Model name or number
- Wearing style
- Bluetooth version
- Total battery life in hours
- Earbud battery life in hours
- Charging-case battery contribution
- Charging connector
- Charging time
- Microphone availability
- Active Noise Cancellation status
- Environmental Noise Cancellation status
- Water-resistance rating
- Driver size in millimetres, when declared
- Low-latency or gaming mode status
- Supported codecs, when declared
- Voice-assistant compatibility
- In-the-box contents
- Warranty period

### 5.2 Controlled Values

```text
wearing_style: in-ear | semi-in-ear | open-ear
anc: true | false
enc: true | false
microphone: true | false
charging_connector: USB-C | Micro-USB | Lightning | Wireless
water_resistance: None | IPX4 | IPX5 | IPX6 | IPX7
```

### 5.3 Battery-Life Rules

- Store battery values as numeric hours.
- Keep earbud-only and total-with-case battery life in separate fields.
- Use `up to` in buyer-facing text when battery life depends on volume, ANC, codec, or calling usage.
- Do not store a combined value such as `30 to 40 hours` in a numeric field.
- Explain test conditions when supplied by the manufacturer.

### 5.4 Noise-Cancellation Rules

Active Noise Cancellation and Environmental Noise Cancellation are different attributes.

- **ANC** reduces external sound heard by the listener.
- **ENC** or call-noise reduction improves microphone clarity during calls.

A product with ENC must not be tagged as ANC unless it independently supports ANC.

### 5.5 Recommendation Fields

For comparative recommendation queries, use:

- Price
- Rating
- Total battery life
- ANC
- Water resistance
- Bluetooth version
- Warranty
- Review themes
- Seller verification
- Stock availability

Example constraint interpretation:

```text
Query: wireless earbuds under ₹3,000 with ANC and at least 20 hours battery
subcategory = Wireless Earbuds
price_inr <= 3000
anc = true
total_battery_life_hours >= 20
availability = In Stock
```

---

## 6. Smartwatch Attributes

### 6.1 Mandatory Attributes

- Brand
- Model
- Display type
- Display size in inches
- Display resolution
- Touchscreen status
- Bluetooth version
- Compatible operating systems
- Battery life in days
- Charging method
- GPS availability
- Calling capability
- Microphone and speaker availability
- Water or dust resistance
- Sensors
- Supported sports modes
- Strap material and size
- Warranty period

### 6.2 Controlled Values

```text
display_type: LCD | TFT | AMOLED | OLED | E-Ink
calling_capability: none | Bluetooth calling | cellular
built_in_gps: true | false
microphone: true | false
speaker: true | false
```

### 6.3 Health-Feature Claims

Fitness and wellness readings must not be presented as clinical diagnosis unless the product has the required authorisation. Use wording such as `wellness tracking` where appropriate.

### 6.4 Compatibility

Compatibility fields must specify the supported operating-system family and minimum version when known. A general claim such as `works with all phones` is not acceptable.

---

## 7. Bluetooth Speaker Attributes

Required fields include:

- Output power in watts
- Channel configuration
- Bluetooth version
- Wireless range
- Battery capacity or playback time
- Charging connector
- Charging time
- Water-resistance rating
- Built-in microphone
- Supported input methods
- Stereo-pairing support
- Dimensions and weight
- Warranty

Do not compare sound quality using wattage alone. Review themes, driver design, codec, enclosure, and use environment may also affect buyer suitability.

---

## 8. Power Bank Attributes

Required fields include:

- Rated battery capacity in mAh
- Usable or rated output capacity when declared
- Battery chemistry
- Number and type of input ports
- Number and type of output ports
- Maximum charging output in watts
- Fast-charging protocols
- Pass-through charging status
- Cable included
- Device compatibility
- Safety protections
- Product weight
- Warranty

Do not label a power bank as fast charging without a declared supported output wattage or protocol.

---

## 9. Smartphone Attributes

Required fields include:

- Model and variant
- RAM
- Internal storage
- Expandable-storage support
- Display size, type, and resolution
- Processor
- Operating system and version
- Rear and front camera specifications
- Battery capacity
- Charging power
- SIM configuration
- Network support
- Connectivity
- Security features
- Dimensions and weight
- In-the-box contents
- Warranty

RAM and storage variants must be represented as separate variants. Do not combine materially different models into one variation family.

---

## 10. Tablet Attributes

Required fields include:

- Display size and resolution
- Processor
- RAM
- Storage
- Expandable storage
- Operating system
- Wi-Fi or cellular configuration
- Camera specifications
- Battery capacity
- Charging interface and power
- Stylus support
- Keyboard support
- Speakers
- Dimensions and weight
- Warranty

A Wi-Fi-only tablet must not be tagged as supporting cellular connectivity.

---

## 11. Keyboard Attributes

Required fields include:

- Keyboard type
- Layout
- Number of keys
- Connectivity
- Compatible operating systems
- Switch type
- Backlight
- Battery or power source
- Wireless range, when applicable
- Included receiver or cable
- Dimensions and weight
- Warranty

Controlled values:

```text
keyboard_type: membrane | mechanical | scissor | optical
connectivity: wired | Bluetooth | 2.4 GHz wireless | multi-mode
layout: full-size | tenkeyless | 75 percent | 65 percent | compact
backlight: none | single-colour | RGB
```

---

## 12. Mouse Attributes

Required fields include:

- Connectivity
- Sensor type
- Maximum DPI
- Number of buttons
- Hand orientation
- Battery type or cable
- Polling rate, when declared
- Wireless range
- Compatible operating systems
- Dimensions and weight
- Warranty

A high-DPI value alone must not be interpreted as superior accuracy without supporting product and review evidence.

---

## 13. Product Image Requirements

### 13.1 Primary Image

- Minimum 1000 by 1000 pixels
- Square aspect ratio
- JPEG or PNG
- White or near-white background
- Complete product visible
- Product occupies approximately 75% to 90% of the frame
- No watermark, price, discount, contact detail, QR code, or border
- Only included items shown

### 13.2 Additional Electronics Images

Include, where relevant:

- Front, rear, and side views
- Ports and connectors
- Buttons and controls
- Charging case or adaptor
- Included accessories
- Model-number label
- Dimensions
- Compatible-device illustration
- Package contents

Images must not digitally add ports, accessories, certification marks, or capabilities absent from the supplied product.

---

## 14. Pricing and Numeric Attribute Standards

Store filterable numeric values in dedicated numeric fields.

Correct:

```text
price_inr: 1999
rating: 4.3
battery_life_hours: 30
warranty_months: 12
capacity_mah: 20000
```

Avoid:

```text
price_inr: below two thousand
battery_life_hours: long-lasting
warranty_months: one year manufacturer warranty
```

Buyer-facing text may contain units, but metadata used for filtering must remain numeric.

---

## 15. Boolean Attribute Standards

Use explicit Boolean values for filterable capabilities:

```text
anc: true
built_in_gps: false
seller_verified: true
returnable: true
in_stock: true
```

Do not mix `Yes`, `Available`, `Supported`, `1`, and `true` in the same field.

---

## 16. Units and Normalisation

Use these canonical units:

- Price: Indian rupees
- Battery capacity: mAh
- Battery life: hours or days in separate fields
- Display size: inches
- Weight: grams
- Dimensions: millimetres
- Output power: watts
- Charging power: watts
- Storage: GB or TB using a separate unit field if required
- Wireless range: metres

Convert seller-provided values into the canonical unit while preserving the original value in audit data when necessary.

---

## 17. Synonyms and Search Terms

CatalogueIQ may expand common Electronics terms as follows:

```text
earphones -> earbuds, wired earphones, in-ear headphones
wireless earphones -> wireless earbuds, TWS, Bluetooth earbuds
TWS -> true wireless stereo, wireless earbuds
noise cancellation -> ANC, active noise cancellation
call noise reduction -> ENC, microphone noise reduction
mobile -> smartphone, phone, handset
smart band -> fitness band, activity tracker
charger -> power adaptor, charging adaptor
power bank -> portable charger, battery pack
```

Query expansion must not change a mandatory user constraint. For example, a query specifically requesting wired earphones must not be expanded into wireless earbuds.

---

## 18. Validation Rules

A listing should be flagged when:

- Price is zero or negative.
- Maximum retail price is lower than selling price.
- Rating is outside 0 to 5.
- Stock quantity is negative.
- Warranty period is negative.
- ANC is present only in free text and missing from the Boolean field.
- Battery life is non-numeric in the filterable field.
- Product title and subcategory conflict.
- A smartphone has no storage or RAM value.
- A power bank has no capacity value.
- A wireless product has no connectivity version where required.
- A model number conflicts across variants.
- Included accessories differ between text and images.
- Return metadata conflicts with the active return policy.

Critical errors prevent publication. Non-critical warnings require review but may not always block the listing.

---

## 19. Duplicate Detection

Potential duplicate Electronics products should be compared using:

- Brand
- Model number
- GTIN or other product identifier
- Primary specifications
- Colour and capacity variant
- Manufacturer

Two products with the same brand and model but different colour or storage may belong to one variation family. Products with different model numbers should not be merged merely because their titles are similar.

---

## 20. Warranty Attributes

Store the following separately:

- Warranty period in months
- Warranty provider
- Warranty type
- Covered components
- Major exclusions
- Service mode
- Service-centre requirement

Controlled warranty types:

```text
manufacturer
seller
international
no warranty
```

The return window is not a warranty period. A product may be outside its return window but remain covered by warranty.

---

## 21. Return-Policy Mapping

Electronics normally use the Electronics return rule from the returns and refunds policy.

Recommended metadata:

```text
returnable: true or false
return_window_days: 7
replacement_first: true or false
warranty_months: numeric value
```

The product-level non-returnable label and policy exceptions must be considered before giving a final eligibility answer.

---

## 22. Recommendation and Comparison Logic

A comparative answer should follow this sequence:

1. Identify the product subcategory.
2. Extract hard constraints such as maximum price, ANC, battery life, rating, or brand exclusions.
3. Apply structured filters.
4. Retrieve multiple eligible product records.
5. Join review summaries when available.
6. Rank products using evidence relevant to the query.
7. Explain trade-offs rather than declaring one product universally best.
8. Cite every product using its product ID.

Example ranking factors for earbuds:

```text
constraint_match
price
battery_life_hours
anc
rating
positive_sentiment_pct
warranty_months
seller_verified
stock_availability
```

A product failing a mandatory constraint must not be recommended merely because its semantic similarity score is high.

---

## 23. Missing and Unknown Values

Use null or an explicit unknown state when an attribute is not supplied or verified.

Do not convert missing information into:

- false
- zero
- not supported
- no warranty

unless the source explicitly states that value.

CatalogueIQ should state that an attribute was not found when the retrieved product record does not contain it.

---

## 24. Example Product Chunk

```text
Product ID: P0101
Name: Auralite Wireless Earbuds X200
Brand: Auralite
Category: Electronics
Subcategory: Wireless Earbuds
Price: ₹1,999
Rating: 4.4
Total battery life: 30 hours
ANC: Yes
Bluetooth: 5.3
Water resistance: IPX5
Warranty: 12 months
Seller verified: Yes
Availability: In Stock
```

Recommended metadata:

```text
source: product_catalog.csv
source_type: catalogue
chunk_type: product
product_id: P0101
category: Electronics
subcategory: Wireless Earbuds
price_inr: 1999
rating: 4.4
anc: true
battery_life_hours: 30
```

---

## 25. Example Questions Supported by This Guide

- Which attributes are mandatory for wireless earbuds?
- What is the difference between ANC and ENC?
- What image requirements apply to Electronics listings?
- Which fields should be used to compare power banks?
- How should smartphone RAM and storage variants be represented?
- What metadata filter should be applied for earbuds under ₹3,000?
- Can a product with ENC be described as supporting ANC?
- Which units should be used for battery capacity and charging power?

---

## 26. Guidance for CatalogueIQ Retrieval

Chunk this document by heading. Preserve the parent heading when a subsection is split.

Each chunk should retain:

```text
source: category_electronics.md
source_type: category_guide
document_id: SSI-CAT-ELEC-001
version: 1.0
effective_date: 2026-06-26
category: Electronics
section: <current heading>
persona_scope: shopper,seller,support_agent
```

Recommended citation format:

```text
[Source: category_electronics.md | Section: <section heading>]
```

Use product catalogue records for actual product facts. Use this guide for attribute definitions, classification, validation, and comparison logic.

---

## 27. Document Control

| Version | Date | Change | Owner |
|---|---|---|---|
| 1.0 | 26 June 2026 | Initial fictional Electronics taxonomy and attribute guide | Catalogue Quality and Electronics Category Operations |

---

**End of ShopSmart India Electronics Category Taxonomy and Attribute Guide**
