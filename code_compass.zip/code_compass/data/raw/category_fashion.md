# ShopSmart India Fashion Category Taxonomy and Attribute Guide

**Document ID:** SSI-CAT-FASH-001  
**Version:** 1.0  
**Effective date:** 26 June 2026  
**Applies to:** Fashion products listed on ShopSmart India  
**Document owner:** Catalogue Quality and Fashion Category Operations

> **Training dataset notice:** ShopSmart India is a fictional company. This synthetic guide was created for the CatalogueIQ capstone project and is not a real marketplace policy.

---

## 1. Purpose

This guide defines the Fashion category hierarchy, mandatory attributes, controlled values, size and fit standards, image rules, validation checks, and recommendation fields used by ShopSmart India.

It helps sellers, catalogue specialists, support agents, shoppers, and CatalogueIQ classify, retrieve, filter, and compare Fashion products accurately.

---

## 2. Fashion Category Hierarchy

```text
Fashion
├── Men's Clothing
│   ├── T-Shirts
│   ├── Shirts
│   ├── Jeans
│   ├── Trousers
│   ├── Kurtas
│   ├── Jackets
│   └── Activewear
├── Women's Clothing
│   ├── Dresses
│   ├── Tops
│   ├── Kurtas and Kurtis
│   ├── Sarees
│   ├── Jeans
│   ├── Jackets
│   └── Activewear
├── Kids' Clothing
│   ├── Boys' Clothing
│   ├── Girls' Clothing
│   └── Infant Clothing
├── Footwear
│   ├── Sneakers
│   ├── Formal Shoes
│   ├── Sandals
│   ├── Slippers
│   └── Sports Shoes
├── Bags and Luggage
│   ├── Handbags
│   ├── Backpacks
│   ├── Wallets
│   └── Travel Bags
└── Fashion Accessories
    ├── Watches
    ├── Belts
    ├── Sunglasses
    ├── Caps and Hats
    ├── Scarves
    └── Fashion Jewellery
```

Assign each product to the most specific applicable subcategory. Do not classify sneakers directly under Fashion when the Footwear > Sneakers path is available.

---

## 3. Common Fashion Attributes

The following attributes apply to most Fashion products:

- Product ID
- Product title
- Brand
- Category
- Subcategory
- Department or target group
- Product type
- Colour
- Colour family
- Material composition
- Pattern
- Style
- Occasion
- Size
- Fit
- Country of origin
- Manufacturer
- Care instructions
- Package contents
- Seller ID
- Seller-verification status
- Price
- Rating
- Stock availability
- Return eligibility

Values must describe the exact product and variant supplied to the buyer.

---

## 4. Product Title Convention

Use this structure where applicable:

```text
Brand + Target Group + Product Type + Material or Style + Colour + Size
```

Examples:

```text
UrbanWeave Men's Regular-Fit Cotton T-Shirt, Navy, Size L
IndiThread Women's Printed Cotton Kurta, Blue, Size M
ModeCraft Women's Casual Sneakers, White, UK Size 6
```

Do not include:

- Best, premium, trending, or No. 1
- Price or discount
- Delivery promises
- Unverified material claims
- Contact details
- Repeated keywords
- Unrelated brand names
- Misleading occasion or body-shape claims

---

## 5. Clothing Attributes

### 5.1 Mandatory Attributes

- Department or target group
- Product type
- Size
- Size system
- Fit
- Colour
- Material composition
- Pattern
- Sleeve type, when applicable
- Neck or collar type, when applicable
- Length, when applicable
- Closure type, when applicable
- Number of pockets, when applicable
- Occasion
- Wash and care instructions
- Package quantity
- Country of origin

### 5.2 Controlled Department Values

```text
men
women
boys
girls
infants
unisex adults
unisex kids
```

Do not infer the target group solely from colour or image style. Use the seller-provided classification and product construction.

### 5.3 Controlled Fit Values

```text
slim
regular
relaxed
oversized
tailored
straight
skinny
bootcut
wide leg
athletic
```

Fit and size are separate attributes. A regular-fit product may be available in multiple sizes.

### 5.4 Controlled Pattern Values

```text
solid
striped
checked
printed
floral
geometric
embroidered
tie-dye
colour-blocked
textured
```

Use the dominant pattern. Additional design details may be stored separately.

---

## 6. Size Standards

### 6.1 Required Size Metadata

Store:

- Display size
- Size system
- Numeric measurements
- Measurement unit
- Brand size, when different
- Recommended body measurements
- Garment measurements, when available

Example:

```text
size_display: L
size_system: India Alpha
chest_body_cm_min: 102
chest_body_cm_max: 107
garment_chest_cm: 112
```

### 6.2 Size Systems

Supported size systems may include:

```text
India Alpha
India Numeric
UK
US
EU
International
Age-based Kids
Foot Length CM
Waist Inches
```

The size system must accompany a numeric size. A value such as `8` is ambiguous without UK, US, or another defined system.

### 6.3 Size Chart Requirements

A size chart must:

- Identify whether values are body or garment measurements.
- State the unit of measurement.
- Cover every available size.
- Use consistent measurement points.
- Match the listed variant.
- Avoid unsupported universal-fit claims.

### 6.4 Free Size

Use `Free Size` only when the product genuinely accommodates the stated measurement range. Include the minimum and maximum supported measurements.

---

## 7. Material Composition

Material claims must be accurate and expressed using composition percentages when available.

Correct:

```text
material_primary: Cotton
cotton_pct: 95
elastane_pct: 5
```

Avoid:

```text
material: premium fabric
material: cotton feel
```

Do not describe blended fabric as pure cotton, pure silk, genuine leather, or another single material unless supported by the actual composition.

Common controlled materials include:

```text
Cotton
Linen
Denim
Polyester
Viscose
Rayon
Nylon
Wool
Silk
Elastane
Leather
Synthetic Leather
Canvas
Rubber
EVA
```

---

## 8. Colour Attributes

Store the seller's display colour and a normalized colour family.

Example:

```text
colour_display: Midnight Navy
colour_family: Blue
```

Recommended colour families:

```text
Black
White
Grey
Blue
Green
Red
Pink
Purple
Yellow
Orange
Brown
Beige
Gold
Silver
Multi
```

Product images and colour metadata must be reasonably consistent. Minor differences caused by lighting or display settings should be disclosed in descriptive text where appropriate.

---

## 9. Men's and Women's T-Shirt Attributes

Required fields include:

- Target group
- Size
- Fit
- Material composition
- Sleeve type
- Neck type
- Pattern
- Length
- Occasion
- Care instructions

Controlled neck values:

```text
round neck
V-neck
polo collar
crew neck
henley
high neck
```

Controlled sleeve values:

```text
sleeveless
short sleeve
half sleeve
three-quarter sleeve
long sleeve
```

---

## 10. Shirt Attributes

Required fields include:

- Target group
- Size
- Fit
- Material
- Collar type
- Sleeve type
- Pattern
- Closure
- Cuff type
- Hem style
- Pocket count
- Occasion
- Care instructions

Shirt and T-shirt must remain separate product types. A polo T-shirt should not be classified as a formal shirt.

---

## 11. Jeans and Trousers Attributes

Required fields include:

- Waist size
- Inseam or length
- Rise
- Fit
- Leg style
- Material composition
- Stretch status
- Closure
- Number of pockets
- Wash or finish
- Care instructions

Controlled values:

```text
rise: low | mid | high
leg_style: skinny | slim | straight | tapered | bootcut | wide leg | flared
stretch: non-stretch | low stretch | stretch | high stretch
```

Store waist and inseam as numeric values with units for filtering.

---

## 12. Kurta and Kurti Attributes

Required fields include:

- Target group
- Size
- Fit
- Fabric
- Pattern
- Neck style
- Sleeve type
- Length type
- Hemline
- Ornamentation or embroidery
- Occasion
- Number of pieces
- Included bottom or dupatta status
- Care instructions

Do not show a complete set in the primary image if only the kurta is included unless the additional products are clearly identified as styling props.

---

## 13. Dress Attributes

Required fields include:

- Size
- Fit
- Dress length
- Sleeve type
- Neckline
- Fabric
- Pattern
- Closure
- Lining status
- Occasion
- Care instructions

Controlled dress-length values:

```text
mini
above knee
knee length
midi
maxi
floor length
```

---

## 14. Jacket Attributes

Required fields include:

- Target group
- Size
- Fit
- Outer material
- Lining material
- Insulation, when applicable
- Closure
- Sleeve type
- Hood status
- Pocket count
- Water-resistance claim
- Suitable season
- Care instructions

Water-resistant and waterproof are different claims. Use `waterproof` only when supported by applicable product evidence.

---

## 15. Footwear Attributes

### 15.1 Mandatory Attributes

- Target group
- Footwear type
- UK, US, EU, or India size
- Foot length in centimetres when available
- Colour
- Upper material
- Lining material
- Sole material
- Closure type
- Heel height, when applicable
- Toe shape
- Occasion or activity
- Care instructions

### 15.2 Controlled Closure Values

```text
lace-up
slip-on
hook-and-loop
zip
buckle
elastic
```

### 15.3 Footwear Size Guidance

Do not assume that a UK size equals a US or EU size. Store each supplied system separately or provide a verified conversion chart.

For recommendations, use the user's stated size system and do not silently convert unless the source contains a conversion.

### 15.4 Sports Footwear

Sports-shoe listings should also include:

- Intended activity
- Cushioning type
- Support level
- Surface or terrain
- Shoe weight, when available
- Breathability details

Do not claim medical or injury-prevention benefits without appropriate evidence.

---

## 16. Handbag and Backpack Attributes

Required fields include:

- Bag type
- Material
- Colour
- Dimensions
- Capacity in litres, when applicable
- Number of compartments
- Closure
- Strap type
- Laptop compatibility, when applicable
- Water-resistance status
- Included accessories
- Care instructions

A laptop-compatible claim should include the supported screen size or internal compartment dimensions.

---

## 17. Fashion Watch Attributes

Required fields include:

- Display type
- Movement type
- Dial shape and colour
- Case material
- Strap material and colour
- Case diameter
- Water-resistance rating
- Clasp type
- Warranty

A fashion watch without smart connectivity belongs in Fashion Accessories. A smartwatch belongs in Electronics > Wearable Technology.

---

## 18. Fashion Jewellery Attributes

Required fields include:

- Jewellery type
- Base material
- Plating
- Stone type, when applicable
- Colour
- Dimensions
- Closure
- Number of pieces
- Care instructions
- Skin-sensitivity or nickel information when declared

Do not use `gold`, `silver`, `diamond`, or another precious-material claim when the item is plated, simulated, or fashion jewellery unless the title clearly qualifies the claim.

---

## 19. Product Image Requirements

### 19.1 Primary Image

The primary image must:

- Show the exact product.
- Use a white or near-white background.
- Have a minimum resolution of 1000 by 1000 pixels.
- Use JPEG or PNG.
- Display the complete product without cropped edges.
- Show only included items.
- Avoid watermarks, contact information, QR codes, prices, borders, and promotional badges.
- Represent colour and design accurately.

### 19.2 Clothing Images

Recommended images include:

- Front view
- Back view
- Side or fit view
- Fabric or texture close-up
- Detail of pattern, closure, pocket, or embroidery
- Size chart
- Styling image as an additional image

### 19.3 Footwear Images

Recommended images include:

- Outer side
- Inner side
- Top view
- Sole
- Heel
- Closure and material close-up
- Size chart

### 19.4 Bags and Accessories Images

Recommended images include:

- Front and rear views
- Interior compartments
- Closure
- Strap
- Dimensions
- Scale or usage view

Models and styling props may appear in additional images, but the buyer must be able to identify exactly what is included.

---

## 20. Care Instruction Standards

Use clear care instructions such as:

```text
machine wash cold
gentle cycle
hand wash separately
do not bleach
tumble dry low
line dry in shade
warm iron
dry clean only
wipe with a clean dry cloth
```

Avoid vague values such as `wash carefully`. Care instructions must match the fabric and product construction.

---

## 21. Occasion and Style Tags

Controlled occasion values may include:

```text
casual
formal
business casual
party
festive
wedding
ethnic
evening
sports
travel
workwear
loungewear
```

Controlled style tags may include:

```text
classic
minimal
streetwear
bohemian
traditional
contemporary
vintage-inspired
sporty
smart casual
```

Use tags that are supported by the product design. Do not add unrelated popular tags merely to improve search visibility.

---

## 22. Variation Rules

Valid Fashion variation attributes include:

- Size
- Colour
- Pack quantity
- Pattern when the base design is otherwise the same

Do not group products into one variation family when they differ by:

- Brand
- Product type
- Material category
- Target group
- Major design or construction
- Included components

Each variation must have independent price, stock, SKU, image, and availability data where applicable.

---

## 23. Numeric Attribute Standards

Store filterable measurements as numbers with normalized units.

Correct:

```text
price_inr: 1299
waist_in: 32
foot_length_cm: 25.5
heel_height_cm: 4.0
bag_capacity_l: 18
rating: 4.2
```

Avoid:

```text
waist: medium
heel_height: comfortable
capacity: spacious
```

Descriptive values may supplement, but must not replace, numeric metadata.

---

## 24. Boolean Attribute Standards

Use consistent Boolean values for capabilities or status:

```text
stretch: true
lined: false
hooded: true
water_resistant: false
seller_verified: true
returnable: true
in_stock: true
```

Unknown values must remain null rather than being automatically converted to false.

---

## 25. Search Synonyms

CatalogueIQ may expand common Fashion terms as follows:

```text
tee -> T-shirt, crew-neck T-shirt
kurti -> kurta, women's ethnic top
trainers -> sneakers, sports shoes
hand purse -> handbag, shoulder bag
denims -> jeans, denim trousers
coat -> jacket, outerwear
rucksack -> backpack, daypack
flip-flops -> slippers, casual sandals
```

Query expansion must preserve user constraints. A request for formal shoes must not be expanded into casual sneakers.

---

## 26. Validation Rules

Flag a product when:

- Category and product type conflict.
- Size is missing.
- A numeric size has no size system.
- The advertised size is absent from the size chart.
- Material claims conflict across title, attributes, and description.
- Composition percentages exceed or fall short of 100 when complete composition is claimed.
- Colour metadata conflicts with the primary image.
- Required care instructions are missing.
- Selling price is zero or negative.
- Maximum retail price is lower than selling price.
- Stock quantity is negative.
- Rating is outside 0 to 5.
- The same SKU is reused for different variants.
- Accessories shown as included are absent from package contents.
- Return metadata conflicts with the returns policy.
- A hygiene-sensitive product lacks the required return classification.

Critical errors prevent publication. Warnings require seller or catalogue review.

---

## 27. Duplicate Detection

Potential Fashion duplicates should be compared using:

- Brand
- Product type
- Style or model number
- Material
- Pattern
- Target group
- Primary design
- Product identifier

Colour and size differences usually represent variations, not separate base products. Products with materially different designs should not be merged merely because their titles are similar.

---

## 28. Return-Policy Mapping

Fashion products generally have a 30-calendar-day return window when they remain unused, unwashed, unaltered, and have their original tags.

Recommended product metadata:

```text
returnable: true or false
return_window_days: 30
hygiene_sensitive: true or false
final_sale: true or false
tags_required: true
```

Innerwear, lingerie, swimwear, socks, and opened hygiene-sensitive apparel follow specific exceptions. A discounted sale price alone does not make an otherwise eligible Fashion product non-returnable.

Use the returns and refunds policy for final eligibility decisions.

---

## 29. Recommendation and Comparison Logic

A Fashion recommendation should:

1. Identify product type and target group.
2. Extract mandatory constraints such as budget, size, fit, colour, material, and occasion.
3. Filter out unavailable variants.
4. Retrieve multiple eligible products.
5. Join product review summaries when available.
6. Compare price, rating, fit feedback, material, care, and return eligibility.
7. Explain trade-offs and sizing uncertainty.
8. Cite each recommendation using its product ID.

Example constraint interpretation:

```text
Query: women's cotton kurtas under ₹1,500 in size M for office wear
category = Fashion
subcategory = Kurta
Target_group = women
material includes Cotton
price_inr <= 1500
size = M
occasion includes workwear or business casual
availability = In Stock
```

A semantically similar product that does not offer the requested size must not be recommended as an eligible option.

---

## 30. Fit and Review Interpretation

Fit feedback in review summaries may support recommendations but must not replace the official size chart.

Examples of useful review themes:

- Runs small
- Runs large
- True to size
- Comfortable fit
- Fabric thinner than expected
- Colour differs slightly
- Good stitching
- Requires careful washing

CatalogueIQ should distinguish catalogue facts from aggregated customer opinions.

---

## 31. Missing and Unknown Values

Use null or `unknown` when an attribute is unavailable.

Do not infer:

- Material from appearance
- Size from model body type
- Fit from a product image
- Colour from a title alone when data conflicts
- Return eligibility from category alone when a product-level exception exists

The assistant should state that an attribute is not available rather than inventing it.

---

## 32. Example Product Chunk

```text
Product ID: P0201
Name: UrbanWeave Women's Printed Cotton Kurta 301
Brand: UrbanWeave
Category: Fashion
Subcategory: Kurta
Price: ₹1,299
Rating: 4.4
Size: M
Fit: Regular
Material: 100% Cotton
Colour: Blue
Occasion: Workwear, Casual
Return window: 30 days
Seller verified: Yes
Availability: In Stock
```

Recommended metadata:

```text
source: product_catalog.csv
source_type: catalogue
chunk_type: product
product_id: P0201
category: Fashion
subcategory: Kurta
price_inr: 1299
rating: 4.4
size: M
fit: Regular
material_primary: Cotton
return_window_days: 30
```

---

## 33. Example Questions Supported by This Guide

- What attributes are mandatory for a Fashion listing?
- What image requirements apply to footwear?
- How should a seller represent UK and EU shoe sizes?
- Can a polyester-and-cotton blend be described as pure cotton?
- Which fields should be used to compare kurtas?
- Can a fashion product bought during a sale be returned?
- How should size-chart measurements be stored?
- Which metadata filters should be applied for women's sneakers in UK size 6?

---

## 34. Guidance for CatalogueIQ Retrieval

Chunk this document by heading and preserve the complete heading path when splitting long sections.

Each chunk should retain:

```text
source: category_fashion.md
source_type: category_guide
document_id: SSI-CAT-FASH-001
version: 1.0
effective_date: 2026-06-26
category: Fashion
section: <current heading>
persona_scope: shopper,seller,support_agent
```

Recommended citation format:

```text
[Source: category_fashion.md | Section: <section heading>]
```

Use catalogue records for actual product facts. Use this guide for classification, attribute definitions, size interpretation, metadata filtering, validation, and comparison logic.

---

## 35. Document Control

| Version | Date | Change | Owner |
|---|---|---|---|
| 1.0 | 26 June 2026 | Initial fictional Fashion taxonomy and attribute guide | Catalogue Quality and Fashion Category Operations |

---

**End of ShopSmart India Fashion Category Taxonomy and Attribute Guide**
