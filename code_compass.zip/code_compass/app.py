"""Streamlit application for the CatalogueIQ RAG assistant.

Run from the project root with::

    streamlit run app.py

Before starting the application:

1. Install dependencies with ``pip install -r requirements.txt``.
2. Set ``OPENAI_API_KEY`` in the environment or ``.env`` file.
3. Run ``python scripts/ingest.py`` to create the LanceDB table.

The application supports Shopper, Seller, and Support Agent personas,
conversation memory, vector/full-text/hybrid retrieval, grounding diagnostics,
and citation-aware answers.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Iterable
from uuid import uuid4

import streamlit as st
from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from catalogueiq.embeddings import EmbeddingConfig, create_embedding_provider
from catalogueiq.lancedb_store import LanceDBConfig, LanceDBStore
from catalogueiq.memory import ConversationMemory
from catalogueiq.rag_chain import (
    CatalogueRAGChain,
    OpenAIChatProvider,
    RAGConfig,
    RAGResponse,
)
from catalogueiq.retriever import CatalogueRetriever, RetrieverConfig

load_dotenv(PROJECT_ROOT / ".env")

APP_TITLE = "CatalogueIQ"
APP_SUBTITLE = "Grounded product intelligence for ShopSmart India"
DEFAULT_LANCEDB_URI = str(PROJECT_ROOT / "storage" / "lancedb")
DEFAULT_TABLE_NAME = "knowledge_chunks"
DEFAULT_EMBEDDING_MODEL = "all-MiniLM-L6-v2"
DEFAULT_CHAT_MODEL = "gpt-4.1-mini"

PERSONA_LABELS = {
    "Shopper": "shopper",
    "Seller": "seller",
    "Support Agent": "support_agent",
}

PERSONA_DESCRIPTIONS = {
    "shopper": "Discover products, compare options, and understand returns or warranty.",
    "seller": "Get listing, onboarding, image, catalogue, and compliance guidance.",
    "support_agent": "Investigate customer cases using traceable policy evidence.",
}

EXAMPLE_QUESTIONS = {
    "shopper": [
        "Which wireless earbuds under ₹3000 support ANC and have at least 20 hours of battery life?",
        "Can a Fashion item bought during a sale be returned?",
        "What is the warranty of product P0101?",
    ],
    "seller": [
        "What are the image requirements for an Electronics listing?",
        "Which attributes are mandatory for wireless earbuds?",
        "Give me a seller onboarding checklist.",
    ],
    "support_agent": [
        "A product stopped working after the return window. What options should I verify?",
        "What evidence is needed for a damaged Electronics return?",
        "How should I handle a delayed refund case?",
    ],
}


def configure_page() -> None:
    st.set_page_config(
        page_title=APP_TITLE,
        page_icon="🛍️",
        layout="wide",
        initial_sidebar_state="expanded",
    )
    st.markdown(
        """
        <style>
        .block-container {max-width: 1180px; padding-top: 1.5rem;}
        .app-subtitle {color: #64748b; margin-top: -0.75rem; margin-bottom: 1.25rem;}
        .status-card {
            padding: 0.75rem 1rem;
            border: 1px solid #e2e8f0;
            border-radius: 0.75rem;
            background: #f8fafc;
            margin-bottom: 0.75rem;
        }
        .citation-chip {
            display: inline-block;
            padding: 0.25rem 0.55rem;
            margin: 0.15rem 0.2rem 0.15rem 0;
            border-radius: 0.5rem;
            background: #eff6ff;
            color: #1e40af;
            font-size: 0.82rem;
            border: 1px solid #bfdbfe;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def initialize_session_state() -> None:
    defaults: dict[str, Any] = {
        "session_id": str(uuid4()),
        "messages": [],
        "memory": None,
        "chain": None,
        "chain_signature": None,
        "last_response": None,
        "pending_question": None,
        "show_diagnostics": False,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def render_sidebar() -> dict[str, Any]:
    with st.sidebar:
        st.header("Configuration")

        persona_label = st.selectbox(
            "Persona",
            options=list(PERSONA_LABELS),
            help="Controls retrieval priorities and answer style.",
        )
        persona = PERSONA_LABELS[persona_label]
        st.caption(PERSONA_DESCRIPTIONS[persona])

        search_type = st.selectbox(
            "Retrieval mode",
            options=("vector", "fts", "hybrid"),
            format_func={
                "vector": "Vector search",
                "fts": "Full-text search",
                "hybrid": "Hybrid search",
            }.get,
        )

        with st.expander("Model settings", expanded=False):
            embedding_provider = st.selectbox(
                "Embedding provider",
                options=("sentence_transformers", "openai"),
                format_func=lambda value: (
                    "Sentence Transformers" if value == "sentence_transformers" else "OpenAI"
                ),
                disabled=search_type == "fts",
            )
            default_embedding = (
                "text-embedding-3-small"
                if embedding_provider == "openai"
                else DEFAULT_EMBEDDING_MODEL
            )
            embedding_model = st.text_input(
                "Embedding model",
                value=default_embedding,
                disabled=search_type == "fts",
            )
            chat_model = st.text_input("Chat model", value=DEFAULT_CHAT_MODEL)
            temperature = st.slider(
                "Temperature",
                min_value=0.0,
                max_value=1.0,
                value=0.0,
                step=0.1,
            )
            max_tokens = st.number_input(
                "Maximum answer tokens",
                min_value=100,
                max_value=2000,
                value=700,
                step=50,
            )

        with st.expander("Retrieval settings", expanded=False):
            max_variants = st.slider("Query variants", 2, 6, 4)
            candidate_multiplier = st.slider("Candidate multiplier", 1, 6, 3)
            result_limit = st.slider("Final result limit", 1, 15, 6)
            lancedb_uri = st.text_input("LanceDB URI", value=DEFAULT_LANCEDB_URI)
            table_name = st.text_input("Table name", value=DEFAULT_TABLE_NAME)
            known_brands_text = st.text_area(
                "Known brands",
                value="Auralite, NovaTech, Sony, boAt, Noise",
                help="Used for preferred-brand and excluded-brand detection.",
            )

        st.session_state.show_diagnostics = st.toggle(
            "Show retrieval diagnostics",
            value=st.session_state.show_diagnostics,
        )

        col1, col2 = st.columns(2)
        with col1:
            if st.button("Clear chat", use_container_width=True):
                clear_conversation(persona)
                st.rerun()
        with col2:
            if st.button("Reset chain", use_container_width=True):
                st.session_state.chain = None
                st.session_state.chain_signature = None
                st.rerun()

        render_environment_status(lancedb_uri, table_name)

    return {
        "persona": persona,
        "search_type": search_type,
        "embedding_provider": embedding_provider,
        "embedding_model": embedding_model.strip(),
        "chat_model": chat_model.strip(),
        "temperature": float(temperature),
        "max_tokens": int(max_tokens),
        "max_variants": int(max_variants),
        "candidate_multiplier": int(candidate_multiplier),
        "result_limit": int(result_limit),
        "lancedb_uri": lancedb_uri.strip(),
        "table_name": table_name.strip(),
        "known_brands": parse_known_brands(known_brands_text),
    }


def render_environment_status(lancedb_uri: str, table_name: str) -> None:
    st.divider()
    st.subheader("Environment")
    api_key_ready = bool(os.getenv("OPENAI_API_KEY"))
    database_path = Path(lancedb_uri)
    database_ready = database_path.exists() if not lancedb_uri.startswith("db://") else True

    st.markdown(
        f"""
        <div class="status-card">
        <strong>OpenAI API key:</strong> {"✅ Available" if api_key_ready else "❌ Missing"}<br>
        <strong>LanceDB location:</strong> {"✅ Found" if database_ready else "❌ Not found"}<br>
        <strong>Table:</strong> {escape_html(table_name)}
        </div>
        """,
        unsafe_allow_html=True,
    )
    if not api_key_ready:
        st.caption("Add OPENAI_API_KEY to the environment or .env file.")
    if not database_ready:
        st.caption("Run: python scripts/ingest.py")


def build_chain(settings: dict[str, Any]) -> CatalogueRAGChain:
    signature = (
        settings["persona"],
        settings["search_type"],
        settings["embedding_provider"],
        settings["embedding_model"],
        settings["chat_model"],
        settings["temperature"],
        settings["max_tokens"],
        settings["max_variants"],
        settings["candidate_multiplier"],
        settings["lancedb_uri"],
        settings["table_name"],
        tuple(settings["known_brands"]),
    )
    if st.session_state.chain is not None and st.session_state.chain_signature == signature:
        return st.session_state.chain

    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError(
            "OPENAI_API_KEY is missing. Add it to your environment or .env file."
        )

    embedding_provider = None
    if settings["search_type"] in {"vector", "hybrid"}:
        embedding_provider = create_embedding_provider(
            EmbeddingConfig(
                provider=settings["embedding_provider"],
                model=settings["embedding_model"],
                normalize=True,
                cache_enabled=False,
                show_progress=False,
            )
        )

    store = LanceDBStore(
        LanceDBConfig(
            uri=settings["lancedb_uri"],
            table_name=settings["table_name"],
            distance_type="cosine",
        )
    )
    if not store.table_exists():
        raise RuntimeError(
            f"LanceDB table {settings['table_name']!r} was not found. "
            "Run python scripts/ingest.py first."
        )

    memory = get_or_create_memory(settings["persona"], settings["known_brands"])
    retriever = CatalogueRetriever(
        store,
        embedding_provider,
        config=RetrieverConfig(
            search_type=settings["search_type"],
            max_query_variants=settings["max_variants"],
            candidate_multiplier=settings["candidate_multiplier"],
            source_diversity=True,
            strict_product_constraints=True,
            fallback_without_filters=False,
        ),
        known_brands=settings["known_brands"],
    )
    chain = CatalogueRAGChain(
        retriever,
        OpenAIChatProvider(model_name=settings["chat_model"]),
        memory=memory,
        config=RAGConfig(
            temperature=settings["temperature"],
            max_tokens=settings["max_tokens"],
            max_context_characters=12000,
            require_citations=True,
            minimum_results=1,
            use_memory=True,
            include_conversation_history=True,
        ),
    )
    st.session_state.chain = chain
    st.session_state.chain_signature = signature
    return chain


def get_or_create_memory(
    persona: str,
    known_brands: Iterable[str],
) -> ConversationMemory:
    memory = st.session_state.memory
    if memory is None or memory.persona != persona:
        memory = ConversationMemory(
            session_id=st.session_state.session_id,
            persona=persona,
            max_turns=5,
            known_brands=known_brands,
        )
        st.session_state.memory = memory
    return memory


def clear_conversation(persona: str) -> None:
    st.session_state.messages = []
    st.session_state.last_response = None
    st.session_state.pending_question = None
    st.session_state.memory = ConversationMemory(
        session_id=str(uuid4()),
        persona=persona,
        max_turns=5,
    )
    st.session_state.session_id = st.session_state.memory.session_id
    st.session_state.chain = None
    st.session_state.chain_signature = None


def render_header(settings: dict[str, Any]) -> None:
    st.title(f"🛍️ {APP_TITLE}")
    st.markdown(f'<p class="app-subtitle">{APP_SUBTITLE}</p>', unsafe_allow_html=True)
    col1, col2, col3 = st.columns(3)
    col1.metric("Persona", settings["persona"].replace("_", " ").title())
    col2.metric("Retrieval", settings["search_type"].title())
    col3.metric("Memory", "5 turns")


def render_examples(persona: str) -> None:
    if st.session_state.messages:
        return
    st.subheader("Try an example")
    columns = st.columns(3)
    for column, question in zip(columns, EXAMPLE_QUESTIONS[persona]):
        with column:
            if st.button(question, use_container_width=True, key=f"example-{question}"):
                st.session_state.pending_question = question
                st.rerun()


def render_chat_history() -> None:
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
            if message["role"] == "assistant":
                render_citation_chips(message.get("citations", []))
                if st.session_state.show_diagnostics and message.get("diagnostics"):
                    render_diagnostics(message["diagnostics"])


def process_question(question: str, settings: dict[str, Any]) -> None:
    st.session_state.messages.append({"role": "user", "content": question})
    with st.chat_message("user"):
        st.markdown(question)

    with st.chat_message("assistant"):
        try:
            with st.spinner("Retrieving evidence and generating a grounded answer..."):
                chain = build_chain(settings)
                response = chain.ask(
                    question,
                    persona=settings["persona"],
                    limit=settings["result_limit"],
                    search_type=settings["search_type"],
                )
            st.markdown(response.answer)
            render_citation_chips(response.citations)
            diagnostics = response.as_dict(include_prompts=False)
            if st.session_state.show_diagnostics:
                render_diagnostics(diagnostics)
            st.session_state.messages.append(
                {
                    "role": "assistant",
                    "content": response.answer,
                    "citations": response.citations,
                    "diagnostics": diagnostics,
                }
            )
            st.session_state.last_response = response
        except Exception as exc:
            error_text = friendly_error(exc)
            st.error(error_text)
            st.session_state.messages.append(
                {
                    "role": "assistant",
                    "content": f"⚠️ {error_text}",
                    "citations": [],
                    "diagnostics": {"error": str(exc)},
                }
            )


def render_citation_chips(citations: Sequence[str]) -> None:
    if not citations:
        return
    st.markdown("**Evidence citations**")
    chips = "".join(
        f'<span class="citation-chip">{escape_html(citation)}</span>'
        for citation in citations
    )
    st.markdown(chips, unsafe_allow_html=True)


def render_diagnostics(diagnostics: dict[str, Any]) -> None:
    with st.expander("Retrieval diagnostics", expanded=False):
        trace = diagnostics.get("retrieval_trace") or diagnostics.get("trace") or {}
        grounding = diagnostics.get("grounding") or {}
        if trace:
            col1, col2, col3, col4 = st.columns(4)
            col1.metric("Searches", trace.get("searches_executed", 0))
            col2.metric("Raw results", trace.get("raw_result_count", 0))
            col3.metric("Fused results", trace.get("fused_result_count", 0))
            col4.metric("Accepted", trace.get("accepted_result_count", 0))
            st.write("**Query type:**", trace.get("query_type", "unknown"))
            st.write("**Pre-filter:**", trace.get("pre_filter_sql") or "None")
            variants = trace.get("query_variants") or []
            if variants:
                st.write("**Query variants:**")
                for item in variants:
                    st.markdown(f"- {item}")
            if trace.get("errors"):
                st.warning("\n".join(trace["errors"]))
        if grounding:
            st.write("**Grounding validation:**")
            st.json(grounding, expanded=False)


def render_downloads() -> None:
    if not st.session_state.messages:
        return
    transcript = json.dumps(
        {
            "session_id": st.session_state.session_id,
            "messages": st.session_state.messages,
        },
        indent=2,
        ensure_ascii=False,
    )
    st.sidebar.download_button(
        "Download conversation",
        data=transcript,
        file_name=f"catalogueiq-{st.session_state.session_id}.json",
        mime="application/json",
        use_container_width=True,
    )


def friendly_error(exc: Exception) -> str:
    message = str(exc)
    lowered = message.casefold()
    if "openai_api_key" in lowered or "api key" in lowered:
        return "The OpenAI API key is missing or invalid. Check your .env file."
    if "does not exist" in lowered or "not found" in lowered:
        return "The knowledge index is unavailable. Run `python scripts/ingest.py` first."
    if "sentence transformers is not installed" in lowered:
        return "Sentence Transformers is not installed. Run `pip install -r requirements.txt`."
    return f"CatalogueIQ could not complete the request: {message}"


def parse_known_brands(value: str) -> list[str]:
    return unique_items(item.strip() for item in value.split(",") if item.strip())


def unique_items(values: Iterable[str]) -> list[str]:
    output: list[str] = []
    seen: set[str] = set()
    for value in values:
        key = value.casefold()
        if key not in seen:
            seen.add(key)
            output.append(value)
    return output


def escape_html(value: Any) -> str:
    return (
        str(value)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#39;")
    )


def main() -> None:
    configure_page()
    initialize_session_state()
    settings = render_sidebar()
    render_header(settings)
    render_examples(settings["persona"])
    render_chat_history()

    question = st.chat_input(
        "Ask about products, policies, seller requirements, or support cases..."
    )
    if st.session_state.pending_question:
        question = st.session_state.pending_question
        st.session_state.pending_question = None
    if question:
        process_question(question.strip(), settings)

    render_downloads()


if __name__ == "__main__":
    main()
