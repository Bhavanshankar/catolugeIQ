# CatalogueIQ Demonstration Script

**Document ID:** CATALOGUEIQ-DEMO-001  
**Version:** 1.0  
**Demo duration:** 12 to 15 minutes  
**Project:** CatalogueIQ  
**Marketplace:** ShopSmart India, fictional  
**Audience:** Evaluators, trainers, technical reviewers, and project stakeholders

> **Demo notice:** ShopSmart India, its products, sellers, policies, reviews, and evaluation results are synthetic and intended only for learning and demonstration.

---

## 1. Demo Objective

This script demonstrates how CatalogueIQ uses retrieval-augmented generation to answer product, policy, seller, recommendation, and multi-hop questions using the fictional ShopSmart India knowledge base.

The demonstration should show that CatalogueIQ can:

1. Load multiple source formats.
2. Split content using source-aware chunking.
3. Generate and cache embeddings.
4. Store and search chunks in LanceDB.
5. Expand user queries and extract hard constraints.
6. Filter products before recommending them.
7. Retrieve evidence from multiple source types.
8. Produce grounded answers with citations.
9. Maintain preferences across at least five conversation turns.
10. Compare a vector-only baseline with the improved pipeline.

---

## 2. Demo Preparation Checklist

Complete these steps before presenting.

### 2.1 Project structure

Confirm that the project contains:

```text
CatalogueIQ/
├── catalogueiq/
│   ├── __init__.py
│   ├── loaders.py
│   ├── chunking.py
│   ├── embeddings.py
│   ├── lancedb_store.py
│   ├── query_expansion.py
│   ├── filters.py
│   ├── retriever.py
│   ├── prompts.py
│   ├── memory.py
│   ├── rag_chain.py
│   └── citations.py
├── data/
│   ├── raw/
│   │   ├── product_catalog.csv
│   │   ├── product_review_summaries.csv
│   │   ├── returns_refunds_policy.md
│   │   ├── seller_onboarding.md
│   │   ├── category_electronics.md
│   │   ├── category_fashion.md
│   │   └── buyer_faq.html
│   └── processed/
│       ├── ingestion_manifest.json
│       └── ingestion_report.json
├── evaluation/
│   ├── test_set.json
│   ├── baseline_results.json
│   ├── improved_results.json
│   ├── Evaluation_Report.md
│   └── Demo_Script.md
├── scripts/
│   ├── generate_sample_data.py
│   └── ingest.py
└── storage/
    ├── embedding_cache.sqlite3
    └── lancedb/
```

### 2.2 Environment

Confirm that the required packages are installed and that the selected chat-model credentials are configured.

Example environment variable:

```env
OPENAI_API_KEY=replace_with_your_api_key
```

Do not display the actual API key during the demonstration.

### 2.3 Data and index

Run the ingestion pipeline before the session:

```bash
python scripts/ingest.py --mode overwrite --quiet
```

Confirm that the ingestion report shows:

- Seven discovered source files
- 654 loaded source documents
- Approximately 865 chunks with the current source files and default chunk settings
- A valid LanceDB table
- A full-text index
- No empty chunks or duplicate chunk IDs

Actual chunk counts may change if the source documents or chunking configuration change.

### 2.4 Application readiness

Before the audience joins:

- Start the user interface or command-line application.
- Open the project structure in the editor.
- Keep `ingestion_report.json` ready.
- Keep `Evaluation_Report.md` ready.
- Clear any previous demo conversation.
- Select the Shopper persona for the first scenario.
- Test one query to confirm that retrieval and generation are working.

---

## 3. Presentation Flow

| Segment | Topic | Suggested time |
|---|---|---:|
| 1 | Problem and solution overview | 1 minute |
| 2 | Knowledge base and ingestion | 2 minutes |
| 3 | Product factual lookup | 1 minute |
| 4 | Comparative recommendation | 3 minutes |
| 5 | Policy and seller guidance | 2 minutes |
| 6 | Multi-turn memory | 2 minutes |
| 7 | Multi-hop support case | 2 minutes |
| 8 | Evaluation and conclusion | 2 minutes |

If the available time is only 10 minutes, omit the detailed code walkthrough and use one policy scenario instead of two.

---

## 4. Opening Narrative

### Presenter says

> CatalogueIQ is a retrieval-augmented product intelligence assistant for the fictional ShopSmart India marketplace. It supports three personas: Shopper, Seller, and Support Agent. Instead of asking a language model to answer from memory, CatalogueIQ retrieves evidence from product records, review summaries, policies, category guides, seller guidance, and buyer FAQs. It then produces an answer using only the retrieved context and validates the citations before displaying the result.

### Show

- Project title
- Three personas
- Supported source formats
- High-level architecture

### Architecture summary

```text
User question
    ↓
Conversation memory
    ↓
Query expansion and classification
    ↓
Constraint extraction
    ↓
LanceDB retrieval
    ↓
Metadata and specification filtering
    ↓
Reciprocal Rank Fusion
    ↓
Grounded persona prompt
    ↓
LLM answer
    ↓
Citation validation
```

### Key point

> The model is not the source of truth. The retrieved ShopSmart India knowledge base is the source of truth.

---

## 5. Knowledge Base and Ingestion Demo

### Presenter says

> CatalogueIQ uses heterogeneous data because a marketplace question can require both structured product facts and unstructured policy guidance.

### Show the raw files

Explain each source briefly:

- `product_catalog.csv`: structured products, prices, ratings, sellers, stock, specifications, warranties, and return metadata.
- `product_review_summaries.csv`: aggregated positive and negative review themes.
- `returns_refunds_policy.md`: category windows, exceptions, evidence, refunds, warranty, and escalation.
- `seller_onboarding.md`: seller setup and listing requirements.
- `category_electronics.md`: Electronics taxonomy and attribute rules.
- `category_fashion.md`: Fashion taxonomy, size, fit, image, and return guidance.
- `buyer_faq.html`: 50 buyer questions and answers.

### Show source-aware loading

Open `loaders.py` and explain:

- One product row becomes one document.
- One review-summary row becomes one document.
- Each FAQ becomes one document.
- Markdown files remain complete documents until heading-aware chunking.

### Show source-aware chunking

Open `chunking.py` and explain:

- Products, review summaries, and FAQs remain intact.
- Markdown is separated by heading.
- Long sections use recursive character splitting.
- Default chunk size is 800 characters.
- Default overlap is 120 characters.
- Every chunk receives a stable content-based ID.

### Show ingestion command

```bash
python scripts/ingest.py --mode overwrite --json
```

If running ingestion live would take too long, display the previously generated `data/processed/ingestion_report.json`.

### Presenter says

> Embeddings are normalized and cached. Unchanged text is not re-embedded during the next ingestion. The final chunks are stored in the `knowledge_chunks` LanceDB table, where the retriever can combine vector similarity, full-text search, and metadata filters.

### Expected talking points

- Product and FAQ records are natural chunks.
- Headings are preserved in policy chunks.
- Metadata supports category, subcategory, price, rating, seller, and source filters.
- Content hashes support incremental processing.

---

## 6. Scenario 1: Product Factual Lookup

### Persona

Shopper

### Enter this question

```text
What is the price, rating, warranty period, and availability of product P0001?
```

### Expected system behavior

1. Classify the query as `product_factual_lookup`.
2. Detect the exact product ID.
3. Retrieve the matching product record.
4. Avoid mixing attributes from similarly named products.
5. Cite the product record.

### Presenter says

> This scenario tests exact factual retrieval. The answer should contain only values found in product P0001 and should cite that product ID.

### Verify on screen

- Exact price
- Exact rating
- Warranty period
- Availability
- Citation in this form:

```text
[Source: product_catalog.csv | Product ID: P0001]
```

### Failure to highlight if it occurs

- A value from another product appears.
- The assistant invents a missing attribute.
- No citation is shown.

---

## 7. Scenario 2: Comparative Recommendation with Hard Constraints

### Persona

Shopper

### Enter this question

```text
Compare up to three in-stock Wireless Earbuds under ₹10,000 that support ANC and provide at least 20 hours of battery life.
```

### Presenter says

> This is more difficult than a semantic search. Every recommended product must satisfy category, subcategory, price, stock, ANC, and battery constraints before ranking.

### Show the expansion trace

Possible variants include:

```text
wireless earbuds under ₹10,000 with ANC and at least 20 hours battery
wireless earphones under ₹10,000 with active noise cancellation and at least 20 hours battery
TWS under ₹10,000 with ANC and at least 20 hours battery
```

### Show the metadata pre-filter

The exact SQL depends on extracted fields, but it should resemble:

```text
category = 'Electronics'
AND subcategory = 'Wireless Earbuds'
AND source_type = 'catalogue'
AND availability = 'In Stock'
AND price_inr <= 10000.0
```

### Explain post-filtering

> ANC and battery life may be inside nested product specifications. CatalogueIQ checks these values after retrieval. A product without ANC or with fewer than 20 battery hours is rejected even if its vector score is high.

### Expected answer structure

- Up to three eligible products
- Compact comparison
- Price
- Rating
- Battery life
- ANC
- Warranty or seller verification when available
- One product-specific citation per product
- Clear statement if fewer than three products match

### Show the filter audit

Point out:

- Candidate count
- Accepted count
- Rejected count
- Reasons for rejection

Example rejection reasons:

```text
price is above maximum
ANC requirement not met
battery life is below 20 hours
product is not confirmed in stock
```

### Key point

> Semantic similarity proposes candidates. Deterministic constraints decide eligibility.

---

## 8. Scenario 3: Policy Eligibility

### Persona

Shopper

### Enter this question

```text
Can I return an opened perfume because I do not like its fragrance?
```

### Expected system behavior

1. Classify as `policy_eligibility`.
2. Retrieve Beauty return rules and relevant buyer FAQ guidance.
3. Explain that opened Beauty items are generally non-returnable for hygiene reasons.
4. Distinguish fragrance preference from delivery exceptions.
5. Mention the 48-hour reporting rule for damage, leakage, expiry, counterfeit, wrong item, or missing quantity when supported by the retrieved evidence.
6. Cite the policy and FAQ evidence used.

### Presenter says

> CatalogueIQ does not provide a generic return answer. It identifies the category rule, the condition of the product, the reason for return, and the applicable exceptions.

### Verify on screen

- Direct eligibility answer
- Hygiene rule
- Delivery-issue exceptions
- No promise of automatic approval
- Policy and FAQ citations

---

## 9. Scenario 4: Seller Guidance

### Switch persona

Seller

### Enter this question

```text
What are the primary-image requirements for an Electronics listing?
```

### Expected answer

The answer should provide an actionable checklist based on the seller and Electronics guides, including the retrieved requirements for:

- Exact product representation
- White or near-white background
- Square image
- Minimum 1000 by 1000 pixels
- JPEG or PNG format
- Complete product visibility
- No watermark
- No price or discount text
- No contact information or QR code
- No misleading accessories

### Presenter says

> The Seller persona changes the response style. The underlying grounding rule remains the same, but the answer is presented as an operational checklist.

### Verify citations

Expected source styles:

```text
[Source: seller_onboarding.md | Section: <retrieved heading>]
[Source: category_electronics.md | Section: <retrieved heading>]
```

---

## 10. Scenario 5: Five-Turn Conversation Memory

### Switch persona

Shopper

### Clear the previous conversation

Run these turns sequentially.

#### Turn 1

```text
Show me Wireless Earbuds under ₹10,000.
```

#### Turn 2

```text
Only include products with ANC.
```

#### Turn 3

```text
Which have at least 20 hours of battery life?
```

#### Turn 4

```text
Only show verified sellers.
```

#### Turn 5

```text
Compare the top three.
```

### Presenter says after Turn 5

> The final question is not self-contained. CatalogueIQ converts it into a retrieval query using preferences explicitly stated by the user during this session.

### Show remembered preferences

The session should contain applicable values such as:

```text
category: Electronics
subcategory: Wireless Earbuds
maximum price INR: 10000
ANC required: True
minimum battery hours: 20
verified seller required: True
```

### Important explanation

> Conversation memory preserves user intent and preferences. It does not make previous assistant answers authoritative. CatalogueIQ still performs fresh retrieval for every turn.

### Verify

- The final answer respects all earlier constraints.
- Old assistant text is not used as a citation.
- New citations come from freshly retrieved evidence.
- The memory window supports at least five exchanges.

---

## 11. Scenario 6: Multi-Hop Support Case

### Switch persona

Support Agent

### Enter this question

```text
A third-party smartwatch stopped working 45 days after delivery. What options should the buyer check?
```

### Expected reasoning path

1. Identify the Electronics return window.
2. Determine that 45 days is outside the standard return window.
3. Check manufacturer or seller warranty guidance.
4. Advise contacting the authorised service provider or seller.
5. Explain the buyer-protection dispute option if a promised warranty is refused without a valid reason.
6. Identify supporting evidence that may be needed.

### Presenter says

> This question cannot be answered from one product record or one policy sentence. CatalogueIQ retrieves complementary evidence and keeps return eligibility, warranty coverage, seller responsibility, and buyer protection as separate steps.

### Verify

- No automatic refund promise
- Clear distinction between return window and warranty
- Ordered next actions
- Multiple relevant citations
- Neutral Support Agent tone

---

## 12. Citation Validation Demo

### Presenter says

> CatalogueIQ validates citation markers after generation. A citation is valid only when it matches evidence retrieved for the current question.

### Show a valid marker

```text
[Source: product_catalog.csv | Product ID: P0001]
```

### Explain invalid-citation behavior

If a generated answer contains an invented citation such as:

```text
[Source: unknown_policy.md | Section: Refunds]
```

and that citation was not present in retrieved evidence, grounding validation fails. In strict non-streaming mode, the answer is replaced with:

```text
I could not find enough information in the ShopSmart India knowledge base to answer that confidently.
```

### Key point

> Citation formatting alone is not enough. The marker must correspond to evidence actually retrieved for that answer.

---

## 13. Evaluation Demo

### Open these files

```text
evaluation/test_set.json
evaluation/baseline_results.json
evaluation/improved_results.json
evaluation/Evaluation_Report.md
```

### Presenter says

> The evaluation set contains 20 questions across five query types. The baseline represents vector-only retrieval. The improved configuration adds query expansion, filtering, Reciprocal Rank Fusion, source diversification, grounded prompts, memory, and citation validation.

### Show the illustrative comparison

```text
Metric                    Baseline    Improved
Faithfulness              0.8030      0.9375
Answer relevancy          0.8325      0.9280
Context precision         0.7285      0.8945
Citation validity         0.8550      1.0000
Context-recall proxy      0.5425      0.8555
Composite score           0.8047      0.9400
Average latency           756.85 ms   895.30 ms
```

### State this disclaimer clearly

> These scores are deterministic illustrative values for pipeline development. They are not results from a completed live RAGAS execution. A final performance claim requires running the actual test set, saving generated answers and retrieved contexts, and replacing these values with measured scores.

### Explain the trade-off

- Accuracy and grounding improve.
- Comparative and multi-hop performance improve most.
- Latency increases because the improved retriever executes multiple searches and validates more candidates.

---

## 14. Optional Technical Deep Dive

Use this section only when evaluators ask for implementation details.

### 14.1 Loader interface

```python
from catalogueiq.loaders import load_documents

documents = load_documents("data/raw")
```

### 14.2 Chunking

```python
from catalogueiq.chunking import chunk_documents

chunks = chunk_documents(
    documents,
    chunk_size=800,
    chunk_overlap=120,
)
```

### 14.3 Embeddings

```python
from catalogueiq.embeddings import EmbeddingConfig, embed_chunks_from_config

embedded_chunks, statistics = embed_chunks_from_config(
    chunks,
    EmbeddingConfig(
        provider="sentence_transformers",
        model="all-MiniLM-L6-v2",
        normalize=True,
        cache_enabled=True,
    ),
)
```

### 14.4 LanceDB storage

```python
from catalogueiq.lancedb_store import LanceDBConfig, LanceDBStore

store = LanceDBStore(
    LanceDBConfig(
        uri="./storage/lancedb",
        table_name="knowledge_chunks",
    )
)

store.create_or_replace(embedded_chunks)
store.create_fts_index()
```

### 14.5 Retrieval

```python
response = retriever.retrieve(
    "best earbuds under ₹10,000 with ANC and at least 20 hours battery",
    persona="shopper",
)
```

### 14.6 RAG generation

```python
response = rag_chain.ask(
    "Compare the top matching earbuds",
    persona="shopper",
)

print(response.answer)
print(response.grounding.as_dict())
```

---

## 15. Expected Questions from Evaluators

### Why use source-aware chunking?

Products and FAQs are already self-contained entities. Splitting them can separate an ID from its attributes or a question from its answer. Long policy documents benefit from heading-aware splitting because headings preserve the rule's context.

### Why normalize embeddings?

Normalized vectors make cosine-oriented similarity comparison consistent and allow the embedding cache and vector store to use one stable configuration.

### Why are filters needed if vector search already finds similar products?

Similarity does not enforce numeric or Boolean constraints. A semantically relevant product can still exceed the budget, be out of stock, lack ANC, have insufficient battery life, or omit the requested size.

### Why retrieve several candidates?

Post-filtering may reject some candidates. Retrieving a larger pool increases the chance of retaining enough valid products for comparison.

### Why use Reciprocal Rank Fusion?

It combines rankings from the original query and expanded variants without requiring raw similarity scores to be directly comparable. Products found consistently across variants receive stronger rankings.

### How is hallucination reduced?

CatalogueIQ uses grounded prompts, fresh retrieval, strict product filters, insufficient-evidence handling, and citation validation. These controls reduce risk but do not eliminate the need for evaluation and human review in important cases.

### Why not treat conversation memory as evidence?

Previous assistant answers may contain errors. Memory is used only for continuity and user-stated preferences. Product and policy claims require fresh retrieved evidence.

### Are the evaluation scores real RAGAS results?

No. The included values are illustrative synthetic results. The project contains a documented process for replacing them with live RAGAS outputs.

---

## 16. Troubleshooting During the Demo

### No results are returned

- Confirm that ingestion completed.
- Confirm that the LanceDB table exists.
- Verify the embedding model matches the stored vectors.
- Inspect the pre-filter SQL for an overly restrictive condition.
- Confirm that the requested product variant exists in the catalogue.

### Full-text search fails

Recreate the full-text index:

```bash
python scripts/ingest.py --mode overwrite
```

### Embedding model cannot load

- Confirm `sentence-transformers` is installed.
- Confirm the model is available locally or the environment can retrieve it.
- Use the configured device, such as `cpu`.

### OpenAI generation fails

- Confirm that `OPENAI_API_KEY` is configured.
- Do not display the key.
- Confirm that the selected model is available to the account.

### Citation validation fails

- Check whether the generated citation exactly matches a retrieved evidence marker.
- Confirm that the answer did not alter the product ID, filename, FAQ ID, or section heading.
- Inspect the retrieval response's available citations.

### The final recommendation has fewer products than requested

Explain that strict filtering removed ineligible candidates. Returning fewer valid products is preferable to recommending products that violate mandatory constraints.

---

## 17. Closing Narrative

### Presenter says

> CatalogueIQ demonstrates that a useful e-commerce assistant needs more than semantic search. It needs structured constraints, source-aware retrieval, grounded generation, citation validation, and conversation continuity. The improved architecture is designed to recommend only eligible products, explain policy decisions with evidence, support different marketplace personas, and expose a trace that can be evaluated and audited.

### Final points to show

- Multi-format source coverage
- Approximately 865 indexed chunks with the current default dataset
- Three supported personas
- Five supported query types
- Five-turn session memory
- Product-level and document-section citations
- Baseline and improved evaluation artifacts
- Clear synthetic-data and illustrative-results disclaimers

---

## 18. Short Five-Minute Demo Variant

When only five minutes are available, use this sequence:

1. Give the 30-second project overview.
2. Show the seven raw source files.
3. Run the constrained Wireless Earbuds comparison.
4. Show one rejected candidate and its rejection reason.
5. Ask the opened-perfume return question.
6. Show citations and grounding validation.
7. Display the baseline and improved composite scores with the synthetic-results disclaimer.

Suggested closing sentence:

> The core value of CatalogueIQ is not merely generating an answer. It is retrieving the right evidence, enforcing the user's constraints, and showing where every important claim came from.

---

## 19. Demo Completion Checklist

After the presentation, confirm that the audience saw:

- [ ] The project problem and architecture
- [ ] Multiple source formats
- [ ] Source-aware loading and chunking
- [ ] Embedding and LanceDB ingestion
- [ ] Product factual retrieval
- [ ] Constraint-aware comparative recommendation
- [ ] Policy eligibility guidance
- [ ] Seller guidance
- [ ] Five-turn memory
- [ ] Multi-hop support reasoning
- [ ] Citation validation
- [ ] Baseline and improved evaluation results
- [ ] The synthetic-data and illustrative-score disclaimers

---

## 20. Document Control

| Version | Date | Change |
|---|---|---|
| 1.0 | 11 September 2026 | Initial CatalogueIQ demonstration script |

**End of CatalogueIQ Demonstration Script**
