# CatalogueIQ Panel Questions and Answers

**Document ID:** CATALOGUEIQ-PANEL-QA-001  
**Version:** 1.0  
**Date:** 11 September 2026  
**Project:** CatalogueIQ  
**Marketplace:** ShopSmart India, fictional  
**Purpose:** Viva, technical panel, project review, and demonstration preparation

> **Important notice:** ShopSmart India, its products, sellers, policies, reviews, and evaluation values are synthetic. The baseline and improved scores are illustrative development data, not measured results from a completed live RAGAS run.

---

## 1. How to Use This Guide

Use each answer as a speaking framework rather than memorising it word for word.

A strong panel response usually follows this structure:

1. Give the direct answer in one sentence.
2. Explain why the design was chosen.
3. Mention the relevant CatalogueIQ component.
4. Give a short example.
5. State a limitation or trade-off when appropriate.

Recommended answer length:

- Simple question: 20 to 40 seconds
- Technical design question: 45 to 90 seconds
- Evaluation or architecture question: 1 to 2 minutes

---

## 2. Project Overview

### Q1. What is CatalogueIQ?

**Suggested answer:**

CatalogueIQ is a retrieval-augmented product intelligence assistant for the fictional ShopSmart India marketplace. It helps Shoppers, Sellers, and Support Agents answer product, policy, listing, recommendation, and support questions using evidence retrieved from the project's knowledge base.

Unlike a normal chatbot, CatalogueIQ does not rely only on the language model's internal knowledge. It retrieves product records, review summaries, policies, category guides, seller guidance, and buyer FAQs before generating an answer.

---

### Q2. What problem does CatalogueIQ solve?

**Suggested answer:**

E-commerce information is distributed across structured and unstructured sources. Product facts may exist in CSV records, return rules in policy documents, listing requirements in seller guides, and common questions in FAQs. A basic keyword search or chatbot may return incomplete, inconsistent, or unsupported answers.

CatalogueIQ combines these sources and provides:

- Product discovery and comparison
- Constraint-aware recommendations
- Return and refund guidance
- Seller onboarding assistance
- Multi-hop support reasoning
- Evidence-based answers with citations

---

### Q3. Why did you choose the e-commerce domain?

**Suggested answer:**

The e-commerce domain is a good RAG use case because it combines exact structured facts with long-form policy content. It also requires several retrieval behaviours, including exact product lookup, semantic search, numeric filtering, Boolean feature validation, policy retrieval, and multi-source reasoning.

This allows the project to demonstrate more than a simple document chatbot.

---

### Q4. Who are the users of the system?

**Suggested answer:**

CatalogueIQ supports three personas:

- **Shopper:** Product facts, comparisons, recommendations, returns, warranty, and authenticity
- **Seller:** Onboarding, catalogue attributes, image requirements, listing standards, and compliance
- **Support Agent:** Eligibility checks, disputes, warranty scenarios, counterfeit concerns, and escalation

The evidence remains the same, but the response structure and operational focus change by persona.

---

### Q5. What are the five supported query types?

**Suggested answer:**

CatalogueIQ classifies questions into:

1. `product_factual_lookup`
2. `policy_eligibility`
3. `comparative_recommendation`
4. `seller_policy_lookup`
5. `multi_hop`

The classification controls source selection, retrieval depth, filtering, and prompt instructions.

---

## 3. RAG Fundamentals

### Q6. What is Retrieval-Augmented Generation?

**Suggested answer:**

Retrieval-Augmented Generation, or RAG, first retrieves relevant external evidence and then supplies that evidence to a language model for answer generation. This reduces dependence on the model's static knowledge and makes answers more traceable.

In CatalogueIQ, the flow is:

```text
Question
→ Query analysis
→ Retrieval
→ Filtering and fusion
→ Grounded prompt
→ LLM answer
→ Citation validation
```

---

### Q7. Why use RAG instead of fine-tuning?

**Suggested answer:**

RAG is more suitable because product prices, stock, ratings, sellers, and policies can change. These values should be updated in the knowledge base without retraining the model.

Fine-tuning is useful for teaching behaviour or style, but it is not ideal for frequently changing factual data. CatalogueIQ uses prompts for persona behaviour and RAG for factual grounding.

---

### Q8. What is the difference between retrieval and generation?

**Suggested answer:**

Retrieval identifies relevant evidence from LanceDB. Generation uses that evidence to formulate a natural-language answer.

The retriever decides which records are available to the model. The generator should not introduce facts that are absent from those records.

---

### Q9. How does CatalogueIQ reduce hallucination?

**Suggested answer:**

CatalogueIQ uses several controls:

- Grounded system prompts
- Fresh retrieval for every turn
- Product metadata filters
- Deterministic specification checks
- Source-aware retrieval
- Fixed insufficient-evidence behaviour
- Citation validation
- Separation of conversation memory from evidence

These controls reduce hallucination risk, but important policy or support answers still require evaluation and, where appropriate, human review.

---

### Q10. What happens when evidence is insufficient?

**Suggested answer:**

The chain returns a fixed response:

```text
I could not find enough information in the ShopSmart India knowledge base to answer that confidently.
```

It is better to acknowledge insufficient evidence than to invent a product specification or policy rule.

---

## 4. Knowledge Base and Data Design

### Q11. Which files are used as knowledge sources?

**Suggested answer:**

The knowledge base contains seven raw source files:

- `product_catalog.csv`
- `product_review_summaries.csv`
- `returns_refunds_policy.md`
- `seller_onboarding.md`
- `category_electronics.md`
- `category_fashion.md`
- `buyer_faq.html`

The sources combine structured product data with unstructured guidance.

---

### Q12. Why use multiple file formats?

**Suggested answer:**

Different business information naturally fits different formats:

- CSV is suitable for filterable product and review records.
- Markdown is suitable for policies and category guides with headings.
- HTML is suitable for structured FAQ entries.

Using multiple formats makes the project closer to a real enterprise knowledge base.

---

### Q13. Is the data real?

**Suggested answer:**

No. ShopSmart India and all project records are fictional. The sample products, sellers, policies, review summaries, and evaluation values are synthetic and intended for learning and demonstration.

This avoids presenting invented data as a real marketplace policy or business result.

---

### Q14. How was the product sample data generated?

**Suggested answer:**

The `generate_sample_data.py` script creates deterministic data using a fixed random seed. It generates balanced products across Electronics, Fashion, Home and Kitchen, Beauty, and Books, together with linked review summaries.

It validates unique IDs, prices, ratings, JSON specifications, category coverage, review joins, and sentiment percentages.

---

### Q15. What is the purpose of the ingestion manifest?

**Suggested answer:**

`ingestion_manifest.json` documents the expected sources, formats, chunking methods, embedding settings, metadata schema, citation templates, validation rules, and content hashes.

It makes the ingestion design explicit and supports reproducibility and incremental processing.

---

## 5. Document Loading

### Q16. How does `loaders.py` work?

**Suggested answer:**

`loaders.py` provides a framework-independent `Document` object containing text and metadata.

Its source-specific behaviour is:

- One CSV row becomes one document.
- One FAQ item becomes one document.
- One Markdown file becomes one complete source document for later heading-aware chunking.
- JSON can be loaded when manifest content is needed.

Each document also receives a SHA-256 content hash.

---

### Q17. Why not load every file as plain text?

**Suggested answer:**

Plain-text loading would discard useful structure. A product row should remain linked to its product ID and attributes. An FAQ question should remain linked to its answer. Markdown headings should become section metadata.

Preserving this structure improves retrieval, filtering, and citations.

---

### Q18. Why avoid mandatory LangChain dependencies in the loaders?

**Suggested answer:**

The custom loaders keep the core data model lightweight and transparent. They can work without a framework, are easier to test, and avoid coupling ingestion to one orchestration library.

The resulting documents can still be adapted to LangChain or another framework later.

---

## 6. Chunking Strategy

### Q19. What chunking strategies are used?

**Suggested answer:**

CatalogueIQ uses source-aware chunking:

- Product row: one natural chunk
- Review summary: one natural chunk
- FAQ: one question-and-answer chunk
- Markdown: heading-aware sections with recursive splitting for long sections
- Generic text: recursive or fixed-size splitting

The default chunk size is 800 characters with 120 characters of overlap.

---

### Q20. Why keep each product row as one chunk?

**Suggested answer:**

A product row is already a complete business entity. Splitting it could separate the product ID from its price, specifications, warranty, or availability. Keeping the row intact reduces attribute mixing and improves product-level citations.

---

### Q21. Why use heading-aware chunking for Markdown?

**Suggested answer:**

Policy meaning often depends on its section. Heading-aware chunking preserves paths such as:

```text
Returns Policy > Standard Category Return Windows > Electronics
```

This makes retrieved context easier to interpret and gives more precise section citations.

---

### Q22. Why is overlap needed?

**Suggested answer:**

Overlap preserves context when a long section is split across boundaries. Without overlap, a condition at the end of one chunk may become separated from an exception at the beginning of the next.

However, too much overlap increases duplicate retrieval and storage cost, so it must be balanced.

---

### Q23. Which two chunking strategies were compared?

**Suggested answer:**

The project supports comparison between:

1. Fixed-size character chunking
2. Heading-aware recursive chunking

The heading-aware strategy is preferred for policies because it preserves section meaning and citation metadata.

---

### Q24. How are chunk IDs generated?

**Suggested answer:**

Chunk IDs are generated from stable inputs such as source, business identity, section, index, and chunk text using SHA-256. This provides deterministic IDs and helps with validation, upsert operations, and incremental ingestion.

---

## 7. Embeddings

### Q25. What embedding model is used?

**Suggested answer:**

The default local embedding model is `all-MiniLM-L6-v2`, which produces 384-dimensional vectors. The module also supports OpenAI embedding models through a provider abstraction.

---

### Q26. What is an embedding?

**Suggested answer:**

An embedding is a numeric vector representing the semantic meaning of text. Similar questions and documents should have vectors positioned close to each other in the embedding space.

CatalogueIQ embeds both stored chunks and incoming search queries using the same model.

---

### Q27. Why normalize embedding vectors?

**Suggested answer:**

L2 normalization scales each vector to unit length. With cosine-oriented retrieval, normalization makes the comparison focus on direction rather than magnitude and keeps stored and query vectors consistent.

The same normalization setting is included in the embedding cache namespace to prevent incompatible vectors from being reused.

---

### Q28. What happens if ingestion and query embeddings use different models?

**Suggested answer:**

The vectors may have different dimensions or different semantic spaces. The search can fail or return meaningless similarity results.

Therefore, CatalogueIQ must use the same embedding provider, model, dimensions, and normalization setting during ingestion and query retrieval.

---

### Q29. How does the embedding cache work?

**Suggested answer:**

The cache uses SQLite. Its key includes the provider, model, dimensions, normalization setting, and content hash.

When text has not changed, its vector is loaded from the cache. Changed content produces a different hash and is embedded again.

---

### Q30. Why use batching?

**Suggested answer:**

Batching improves throughput by embedding multiple chunks in one model or API call. This is more efficient than processing every chunk independently and also allows controlled resource usage.

---

## 8. LanceDB and Vector Storage

### Q31. Why was LanceDB selected?

**Suggested answer:**

LanceDB supports local vector storage, metadata filtering, vector search, full-text search, and hybrid-search workflows. It is suitable for a capstone project because it can run locally while still exposing database-like retrieval operations.

---

### Q32. What is stored in the LanceDB table?

**Suggested answer:**

Each record contains:

- Stable chunk ID
- Chunk text
- Dense vector
- Source and source type
- Chunk type and section
- Product and seller metadata when applicable
- Category, subcategory, price, rating, and availability
- Content hash
- Embedding metadata
- Extra values inside `metadata_json`

---

### Q33. Why use cosine distance?

**Suggested answer:**

Cosine distance is suitable for normalized semantic embeddings because it measures the direction of vectors rather than their raw magnitude. It is a common choice for text similarity.

---

### Q34. What is the difference between vector search and full-text search?

**Suggested answer:**

Vector search finds semantically similar content, even when the wording differs. Full-text search is stronger for exact terms such as product IDs, model numbers, filenames, and specific policy phrases.

CatalogueIQ supports vector, full-text, and hybrid modes.

---

### Q35. What is hybrid search?

**Suggested answer:**

Hybrid search combines semantic vector retrieval with keyword-oriented full-text retrieval. It can improve results when a question contains both meaning-based language and exact identifiers.

The current enhanced retriever mainly demonstrates multi-query vector retrieval with fusion, while the store also exposes hybrid-search support.

---

### Q36. What is the difference between overwrite, append, and upsert?

**Suggested answer:**

- **Overwrite:** Rebuild the table from the current dataset.
- **Append:** Add records without removing existing ones.
- **Upsert:** Replace records with matching chunk IDs and insert the new versions.

Overwrite is safest for a complete rebuild. Upsert is useful for incremental changes.

---

## 9. Query Expansion and Analysis

### Q37. Why is query expansion required?

**Suggested answer:**

Users can express the same intent with different words, such as `earphones`, `earbuds`, `TWS`, and `wireless earphones`. Query expansion increases recall by searching several equivalent formulations.

---

### Q38. How does CatalogueIQ prevent query expansion from changing user intent?

**Suggested answer:**

The expansion module extracts hard constraints before rewriting and checks that variants preserve them. Examples include budget, minimum rating, battery life, ANC, size, and excluded brands.

A query for wired earphones should not be expanded into wireless earbuds because that would change a mandatory constraint.

---

### Q39. What constraints can be extracted?

**Suggested answer:**

The module can extract values such as:

- Category and subcategory
- Maximum and minimum price
- Minimum rating
- Minimum battery hours
- Fashion size
- Brand and excluded brands
- ANC requirement
- Verified seller requirement
- In-stock requirement
- Return-window days

---

### Q40. How is Indian currency handled?

**Suggested answer:**

Expressions such as `Rs 3000`, `INR 3000`, and `₹3000` are normalized into a consistent rupee form. Price values are converted to numeric metadata filters.

---

### Q41. What is a possible limitation of rule-based query extraction?

**Suggested answer:**

Regex-based extraction may miss unusual phrasing, spelling variation, complex negation, or multilingual expressions. A future version could combine deterministic rules with structured LLM output, followed by validation.

---

## 10. Filtering and Recommendation Logic

### Q42. Why are metadata filters necessary?

**Suggested answer:**

Vector similarity does not enforce structured conditions. A product can be semantically relevant but exceed the budget, be out of stock, lack ANC, have insufficient battery life, or omit the requested size.

Metadata filters ensure that mandatory constraints are applied before recommendation.

---

### Q43. What is the difference between pre-filtering and post-filtering?

**Suggested answer:**

Pre-filtering is performed by LanceDB using typed columns such as category, subcategory, price, rating, seller verification, and availability.

Post-filtering is performed in Python for nested or optional attributes such as ANC, battery life, Fashion size, and excluded brands.

---

### Q44. Why not store every specification as a top-level column?

**Suggested answer:**

Different categories have different attributes. A single wide schema would contain many sparse columns. The project keeps common filterable attributes at the top level and preserves category-specific attributes in structured metadata.

For production, frequently queried nested attributes should be promoted to typed columns.

---

### Q45. Why retrieve more candidates than the final result count?

**Suggested answer:**

Some retrieved candidates will fail post-filtering. If the final goal is three products and only three candidates are retrieved, the system may return nothing after validation.

CatalogueIQ uses a candidate multiplier, commonly three times the final limit, before filtering.

---

### Q46. What happens when fewer than three products satisfy the constraints?

**Suggested answer:**

The system should return the smaller number of valid products and state that fewer matches were available. It should not relax mandatory constraints silently or recommend ineligible products.

---

### Q47. How are missing values handled?

**Suggested answer:**

Missing data remains null or unknown. It is not automatically converted to `false`, `zero`, `not supported`, or `no warranty`.

For strict recommendation constraints, a missing mandatory attribute may cause the product to be excluded because eligibility cannot be confirmed.

---

## 11. Retriever Design

### Q48. How does `retriever.py` work?

**Suggested answer:**

The retriever performs these stages:

1. Expand and classify the query.
2. Build a filter plan.
3. Search each query variant.
4. Search preferred source types when needed.
5. Fuse result rankings.
6. Apply post-filters.
7. Diversify sources for policy and multi-hop questions.
8. Return citation-ready evidence and a trace.

---

### Q49. What is Reciprocal Rank Fusion?

**Suggested answer:**

Reciprocal Rank Fusion, or RRF, combines several ranked result lists. A document receives a score based on its rank in every list:

```text
RRF score = Σ 1 / (k + rank)
```

CatalogueIQ uses `k = 60`. Documents found consistently across query variants receive a stronger fused score.

---

### Q50. Why use RRF instead of comparing raw similarity scores?

**Suggested answer:**

Raw scores from different queries or retrieval methods may not be directly comparable. RRF uses rank positions rather than raw score magnitudes, which makes fusion simple and robust.

---

### Q51. What is source diversification?

**Suggested answer:**

Source diversification ensures that one large document does not occupy all result positions. For a policy or multi-hop query, CatalogueIQ can include evidence from policy, FAQ, seller guide, category guide, and catalogue sources.

---

### Q52. What information is included in the retrieval trace?

**Suggested answer:**

The trace includes:

- Original query
- Query variants
- Detected query type and persona
- Pre-filter SQL
- Preferred source types
- Number of searches
- Raw and fused result counts
- Accepted and rejected counts
- Rejection reasons
- Fallback status
- Retrieval errors

This makes the pipeline easier to debug and evaluate.

---

## 12. Prompts and Personas

### Q53. What is the role of `prompts.py`?

**Suggested answer:**

`prompts.py` builds grounded system and user prompts. It combines:

- General grounding rules
- Persona behaviour
- Query-type instructions
- Output rules
- Retrieved citation-marked context

---

### Q54. How do the persona prompts differ?

**Suggested answer:**

The Shopper prompt focuses on discovery, comparison, and trade-offs. The Seller prompt uses actionable listing and compliance checklists. The Support Agent prompt separates confirmed facts from pending verification and provides operational next steps.

All three personas must still answer only from retrieved evidence.

---

### Q55. How does the prompt defend against prompt injection inside retrieved documents?

**Suggested answer:**

The system prompt states that retrieved content is untrusted evidence, not instructions. Any instruction inside the context asking the model to change roles, reveal secrets, or ignore grounding rules must be disregarded.

---

### Q56. Why is generation temperature set to zero?

**Suggested answer:**

A temperature of zero makes generation more deterministic and reduces unnecessary variation. This is useful for factual product and policy answers where consistency is more important than creativity.

---

## 13. Conversation Memory

### Q57. What type of memory is implemented?

**Suggested answer:**

CatalogueIQ uses session-scoped conversational memory with a default window of five user-assistant exchanges. It also extracts explicit user preferences such as budget, category, ANC, battery life, size, verified seller, and brand exclusions.

---

### Q58. Why not use the full conversation forever?

**Suggested answer:**

An unlimited conversation increases prompt size, cost, latency, and the risk of irrelevant context. The project keeps a recent window and summarizes older user requests.

---

### Q59. Why are previous assistant answers not treated as evidence?

**Suggested answer:**

A previous assistant response may contain an error. Treating it as evidence could propagate that error across later turns.

CatalogueIQ uses prior conversation only for continuity. Every product or policy claim still requires fresh retrieval.

---

### Q60. How does memory handle a follow-up such as “Compare the top three”?

**Suggested answer:**

The memory module combines the current follow-up with the previous user request and stored session preferences. It creates a self-contained retrieval query containing the budget, product category, required features, and exclusions.

---

### Q61. Is memory persisted?

**Suggested answer:**

The module can save and restore session state as JSON. It also provides a `MemoryManager` for multiple in-process sessions.

For production, session storage should be placed in a secure external store with retention and privacy controls.

---

## 14. RAG Chain and Generation

### Q62. What does `rag_chain.py` do?

**Suggested answer:**

The RAG chain orchestrates the complete user turn:

1. Use memory to contextualize the question.
2. Retrieve evidence.
3. Return the insufficient-evidence response if retrieval is inadequate.
4. Build a grounded prompt.
5. Call the chat provider.
6. Validate citations.
7. Save the completed exchange to memory.

---

### Q63. Can the project use models other than OpenAI?

**Suggested answer:**

Yes. The `ChatProvider` abstract interface allows another model provider to implement `generate` and optionally `stream`. The RAG orchestration remains unchanged.

---

### Q64. Why validate citations after generation?

**Suggested answer:**

A language model can format a convincing citation that was never retrieved. Post-generation validation checks every marker against the current retrieval response.

A correctly formatted but unsupported citation is still invalid.

---

### Q65. Why is non-streaming generation safer for strict validation?

**Suggested answer:**

In non-streaming mode, the complete answer can be validated before the user sees it. In streaming mode, text may already be displayed before final citation validation is possible.

Therefore, strict high-confidence workflows should use the non-streaming `ask` method.

---

## 15. Citation Design

### Q66. What citation formats are used?

**Suggested answer:**

Examples include:

```text
[Source: product_catalog.csv | Product ID: P0001]
[Source: returns_refunds_policy.md | Section: Refund Timelines]
[Source: buyer_faq.html | Section: Refunds | FAQ: 33]
```

Product citations use a product ID. Documents use a section. FAQs use section and FAQ ID.

---

### Q67. How does `citations.py` help?

**Suggested answer:**

It can:

- Create canonical markers
- Parse markers
- Extract citations from answers
- Deduplicate citations
- Validate citations against evidence
- Remove unsupported markers
- Format evidence context
- Calculate a lightweight citation-coverage diagnostic

---

### Q68. Is citation coverage the same as faithfulness?

**Suggested answer:**

No. Citation coverage checks whether claim-like sentences contain citation markers. Faithfulness checks whether the claims are actually supported by the retrieved context.

An answer can contain many citations and still be unfaithful if the cited evidence does not support the claims.

---

## 16. Evaluation

### Q69. How many questions are in the test set?

**Suggested answer:**

The test set contains 20 questions:

- 4 product factual lookups
- 4 policy eligibility questions
- 3 seller policy questions
- 5 comparative recommendations
- 4 multi-hop questions

---

### Q70. Which evaluation metrics are used?

**Suggested answer:**

The evaluation design includes:

- Faithfulness
- Answer relevancy
- Context precision
- Citation validity
- Context-recall proxy
- Composite score
- Latency

The first three are RAGAS-style metrics. Citation validity is project-specific.

---

### Q71. What does faithfulness measure?

**Suggested answer:**

Faithfulness measures whether the claims made in the generated answer are supported by the retrieved context. It is not a general correctness score against the entire world.

---

### Q72. What does answer relevancy measure?

**Suggested answer:**

Answer relevancy measures how directly the generated answer addresses the user's question. A grounded answer can still score poorly if it is vague, incomplete, or focused on unrelated details.

---

### Q73. What does context precision measure?

**Suggested answer:**

Context precision measures whether relevant retrieved chunks are ranked ahead of irrelevant chunks. It evaluates retrieval quality, not just answer wording.

---

### Q74. What is the baseline configuration?

**Suggested answer:**

The baseline uses vector-only retrieval with top 5 results and no query expansion, filters, RRF, source diversification, or post-filtering.

It represents a simple starting point for comparison.

---

### Q75. What improvements are enabled in the enhanced configuration?

**Suggested answer:**

The enhanced configuration includes:

- Query expansion
- Constraint extraction
- Metadata pre-filtering
- Deterministic post-filtering
- RRF
- Source diversification
- Grounded persona prompts
- Citation validation
- Five-turn memory

---

### Q76. What are the headline evaluation numbers?

**Suggested answer:**

The illustrative composite score is:

```text
Baseline: 0.8047
Improved: 0.9400
Absolute change: +0.1353
Relative change: +16.81%
```

Citation validity improves from `0.8550` to `1.0000`, while illustrative average latency increases from `756.85 ms` to `895.30 ms`.

---

### Q77. Are these actual RAGAS results?

**Suggested answer:**

No. The files clearly label them as deterministic illustrative synthetic results. They demonstrate the reporting structure and expected comparison.

Before presenting final performance claims, the full test set must be run through the live baseline and improved pipelines, with actual answers and retrieved contexts evaluated by RAGAS.

---

### Q78. Why include synthetic evaluation values at all?

**Suggested answer:**

They complete the development workflow, demonstrate aggregation and reporting, and provide expected acceptance thresholds. However, they are explicitly separated from measured results to avoid misleading claims.

---

### Q79. Why does the improved pipeline have higher latency?

**Suggested answer:**

It executes multiple query variants, retrieves more candidates, validates constraints, fuses rankings, and may search several source types. These operations improve retrieval quality but add computation.

The latency-quality trade-off can be tuned by changing query variants, candidate multiplier, top K, cache usage, and model selection.

---

### Q80. How would you run a real evaluation?

**Suggested answer:**

I would:

1. Ingest the final source set.
2. Execute all test questions through the baseline.
3. Save responses and retrieved contexts.
4. Run RAGAS metrics.
5. Run deterministic citation and constraint checks.
6. Repeat with the enhanced pipeline.
7. Compare per-question and aggregate values.
8. Manually review failed or high-risk cases.
9. Record package versions, evaluator model, seed, and environment.

---

## 17. Security, Safety, and Governance

### Q81. How are API keys handled?

**Suggested answer:**

API keys should be stored in environment variables or a secure secret manager. They must never be hardcoded, logged, displayed in the user interface, or included in the knowledge base.

---

### Q82. How does the project handle sensitive payment information?

**Suggested answer:**

The prompts and FAQ guidance state that passwords, card PINs, CVVs, UPI PINs, and one-time verification codes should never be requested or shared.

A production system should also use input redaction, access controls, encryption, audit logging, and retention policies.

---

### Q83. What are the main prompt-injection risks?

**Suggested answer:**

A retrieved document might contain text that attempts to override the system prompt or request secret information. CatalogueIQ explicitly treats retrieved content as untrusted evidence.

Additional production controls could include ingestion-time scanning, source allowlists, content sanitisation, and model-output monitoring.

---

### Q84. What governance metadata is preserved?

**Suggested answer:**

Chunks retain source, source type, document or product identity, section, content hash, chunking strategy, embedding model, and persona scope. This supports traceability, refresh logic, and audits.

---

## 18. Testing and Validation

### Q85. How were the modules tested?

**Suggested answer:**

Each generated module was syntax-checked and tested with focused assertions. Examples include:

- Loader document counts
- Chunk uniqueness and maximum size
- Embedding cache hits
- Filter rejection reasons
- RRF ranking
- Conversation-memory persistence
- Citation validation
- JSON schema consistency
- Deterministic sample-data generation

---

### Q86. What validation occurs during ingestion?

**Suggested answer:**

The ingestion pipeline checks:

- Source directory existence
- Supported source files
- Non-empty loaded documents
- Unique chunk IDs
- Non-empty chunks
- Required source metadata
- Embedding count matching chunk count
- Consistent vector dimensions
- Successful table write
- Final row count

---

### Q87. How can duplicate products be handled?

**Suggested answer:**

The category guides define duplicate detection using brand, model number, product identifiers, primary specifications, and variant attributes. Colour or size differences may belong to one variation family, while different models should not be merged because their titles are similar.

---

## 19. Limitations

### Q88. What are the current project limitations?

**Suggested answer:**

Current limitations include:

- Synthetic marketplace data
- Rule-based query extraction
- Small 20-question test set
- Illustrative, not live, RAGAS values
- Limited category guides
- No production authentication or authorization
- No distributed session store
- No controlled load test
- Streaming mode cannot fully validate before display
- Structured review enrichment is not yet a dedicated second retrieval stage

---

### Q89. What happens if the dataset becomes very large?

**Suggested answer:**

For a larger dataset, I would add approximate nearest-neighbour indexes, optimize table fragments, partition or filter by category and source, monitor query latency, batch updates, and use incremental ingestion.

I would also evaluate whether frequently queried nested fields should become top-level typed columns.

---

### Q90. Can CatalogueIQ support multilingual questions?

**Suggested answer:**

The current rules and default embedding model are primarily designed for English. Limited language preferences can be stored, but robust multilingual retrieval would require a multilingual embedding model, localized synonyms, multilingual evaluation data, and language-aware prompts.

---

## 20. Future Enhancements

### Q91. What would you improve next?

**Suggested answer:**

My next improvements would be:

1. Run a real RAGAS evaluation.
2. Add a Streamlit or web interface.
3. Add structured review enrichment by product ID.
4. Add hybrid search and a dedicated reranker.
5. Improve multilingual support.
6. Promote frequently filtered specifications to typed columns.
7. Add authentication, authorization, and secure session storage.
8. Add monitoring for latency, retrieval quality, and grounding failures.
9. Add adversarial and prompt-injection tests.
10. Add automated CI tests for ingestion and evaluation.

---

### Q92. How would you improve recommendation ranking?

**Suggested answer:**

After mandatory filtering, I would combine:

- Semantic relevance
- Price fit
- Rating
- Review sentiment
- Warranty
- Seller verification
- Availability
- Query-specific priorities

I would train or tune ranking weights using user feedback and offline evaluation rather than declaring one universal ranking formula.

---

### Q93. Would you add a cross-encoder reranker?

**Suggested answer:**

Yes. A cross-encoder can evaluate the query and candidate text together and often improves top-result relevance. It should be applied after initial retrieval because it is more computationally expensive than embedding search.

The benefit should be measured against added latency.

---

### Q94. How would you support real-time stock and price?

**Suggested answer:**

I would not depend only on embedded text for volatile values. The retriever should join semantic search results with a live catalogue or inventory API for current price, stock, seller, and delivery information.

RAG would retrieve descriptive and policy evidence, while the live system would provide transactional facts.

---

## 21. Difficult Panel Questions

### Q95. If the LLM is still capable of hallucinating, why trust the system?

**Suggested answer:**

The design does not ask users to trust the model blindly. It limits the model to retrieved evidence, validates citations, exposes the retrieval trace, and returns insufficient evidence when grounding fails.

The goal is controlled and auditable assistance, not a claim that hallucination is impossible.

---

### Q96. Why not use only SQL for product recommendations?

**Suggested answer:**

SQL is excellent for exact structured filters, and CatalogueIQ uses metadata filtering for that purpose. However, users also ask semantic questions such as “good for travel,” “clear call quality,” or “what do customers dislike.” Those require retrieval over text and review evidence.

The best design combines structured filtering with semantic retrieval.

---

### Q97. Why not use only keyword search?

**Suggested answer:**

Keyword search is strong for IDs and exact terms but may miss paraphrases and synonyms. For example, a user may say `TWS`, while a product record says `Wireless Earbuds`.

CatalogueIQ combines synonym expansion, semantic embeddings, and optional full-text search.

---

### Q98. What if the policy and FAQ conflict?

**Suggested answer:**

The prompt instructs the model to state the conflict and cite both sources rather than silently choosing one. A production system should define source precedence, effective dates, versioning, and policy ownership.

---

### Q99. Is the improved score guaranteed in production?

**Suggested answer:**

No. The current values are illustrative and production performance depends on real data quality, model versions, retrieval settings, user language, traffic, and evaluation design.

The correct approach is continuous evaluation and monitoring.

---

### Q100. What is the single most important design decision in CatalogueIQ?

**Suggested answer:**

The most important decision is to separate semantic relevance from eligibility. Vector search finds potentially relevant evidence, but deterministic filters decide whether a product actually satisfies the user's mandatory constraints.

This prevents a highly similar but ineligible product from being recommended.

---

## 22. Rapid-Fire Answers

### What is the vector dimension?

384 for the default `all-MiniLM-L6-v2` model.

### What is the default distance metric?

Cosine.

### What is the default chunk size?

800 characters.

### What is the default overlap?

120 characters.

### How many raw source files are used?

Seven.

### How many loaded source documents are expected?

654 with the current dataset.

### Approximately how many chunks are expected?

Approximately 865 using the current source files and default chunking configuration.

### How many products are generated?

500 by default.

### How many review summaries are generated?

100 by default.

### How many FAQ entries are present?

50.

### How many evaluation questions are present?

20.

### How many personas are supported?

Three.

### How many query types are supported?

Five.

### How many conversation turns are retained?

Five user-assistant exchanges by default.

### What fusion method is used?

Reciprocal Rank Fusion.

### What is the RRF constant?

60.

### What is the candidate multiplier?

Three by default.

### What is the default generation temperature?

0.0.

### What happens on unsupported citations?

Strict non-streaming generation falls back to the insufficient-evidence response.

---

## 23. One-Minute Project Summary

> CatalogueIQ is a multi-persona RAG assistant for the fictional ShopSmart India marketplace. It loads structured product and review CSV files, Markdown policies and category guides, and an HTML buyer FAQ. It uses source-aware chunking, normalized embeddings, an SQLite embedding cache, and LanceDB for vector and full-text retrieval. The enhanced retriever expands queries, extracts constraints, applies metadata and specification filters, combines rankings with Reciprocal Rank Fusion, and diversifies sources for policy and multi-hop questions. Grounded prompts support Shopper, Seller, and Support Agent personas, while five-turn memory preserves user preferences without treating prior generated answers as evidence. Generated citations are validated against retrieved sources. The project includes a 20-question evaluation set and illustrative baseline and improved reports, with a clear requirement to replace the synthetic metrics using a live RAGAS run before final performance claims.

---

## 24. Two-Minute Architecture Answer

> The system begins with source-aware ingestion. CSV product and review rows remain natural entities, FAQ entries remain question-answer chunks, and Markdown policies are split by heading with recursive fallback. Each chunk receives traceable metadata and a stable hash-based ID. The text is embedded using `all-MiniLM-L6-v2` by default, normalized, cached in SQLite, and stored with metadata in LanceDB.
>
> At query time, CatalogueIQ detects the persona and query type, expands e-commerce synonyms, and extracts mandatory constraints. Typed conditions such as category, price, rating, stock, and seller verification become LanceDB pre-filters. Nested attributes such as ANC, battery life, and Fashion size are checked after retrieval. Results from multiple query variants are combined using Reciprocal Rank Fusion. Policy and multi-hop questions also use source diversification.
>
> The retrieved chunks are formatted with source markers and passed to a persona-specific grounded prompt. The language model generates an answer using only that context. The system validates every citation against the retrieval response and returns an insufficient-evidence message when grounding requirements are not met. Session memory retains user-stated preferences for five turns, but all factual claims still require fresh retrieval.

---

## 25. Final Panel Closing Statement

> CatalogueIQ demonstrates an end-to-end RAG engineering workflow rather than only an LLM call. The project covers data generation, multi-format loading, chunking, embeddings, caching, vector storage, query expansion, filters, retrieval fusion, persona prompts, memory, citations, evaluation artifacts, and a reproducible ingestion script. Its central principle is that semantic similarity finds candidates, deterministic rules enforce eligibility, and retrieved evidence supports every factual answer.

---

## 26. Final Preparation Checklist

Before attending the panel, verify that you can explain:

- [ ] The business problem
- [ ] The three personas
- [ ] The five query types
- [ ] The seven data sources
- [ ] Source-aware chunking
- [ ] Embeddings and normalization
- [ ] Embedding caching
- [ ] LanceDB schema and search modes
- [ ] Query expansion
- [ ] Pre-filtering and post-filtering
- [ ] Reciprocal Rank Fusion
- [ ] Source diversification
- [ ] Prompt grounding
- [ ] Five-turn memory
- [ ] Citation validation
- [ ] Evaluation metrics
- [ ] Synthetic-score disclaimer
- [ ] Current limitations
- [ ] Future improvements
- [ ] One-minute and two-minute project summaries

---

## 27. Document Control

| Version | Date | Change |
|---|---|---|
| 1.0 | 11 September 2026 | Initial CatalogueIQ panel question-and-answer guide |

**End of CatalogueIQ Panel Questions and Answers**
